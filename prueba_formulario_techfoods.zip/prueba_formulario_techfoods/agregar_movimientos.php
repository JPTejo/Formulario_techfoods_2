<?php
session_start();
include("conexion.php");

if (!isset($_SESSION['id_usuario'])) {
    header('Location: index.html');
    exit;
}

$id_usuario = $_SESSION['id_usuario'];
$id_solicitud = $_POST['id_solicitud'];
$nro_op = $_POST['nro_op'];
$accion = $_POST['accion'];
$comentario = $_POST['comentario'];

// Obtener más datos según sea necesario
// (En una implementación completa, se recogerían todos los campos del formulario)

// Insertar el nuevo movimiento
$sql = "INSERT INTO op_movimientos (
    id_usuario,
    nro_op,
    fecha_registro,
    accion_realizada,
    observaciones
) VALUES (?, ?, CURDATE(), ?, ?)";

$stmt = $conexion->prepare($sql);
$stmt->bind_param("isss", $id_usuario, $nro_op, $accion, $comentario);
$stmt->execute();

if ($stmt->affected_rows > 0) {
    header("Location: detalle_op.php?id=$id_solicitud&success=1");
} else {
    header("Location: detalle_op.php?id=$id_solicitud&error=1");
}
exit;
?>