<?php
include("conexion.php");

$response = ['existe' => false];

if(isset($_POST['email'])) {
    $email = $_POST['email'];
    
    $conexion = new mysqli($host_db, $user_db, $pass_db, $db_name);
    
    if ($conexion->connect_error) {
        die("Error de conexión: " . $conexion->connect_error);
    }
    
    $stmt = $conexion->prepare("SELECT COUNT(*) as count FROM usuarios WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    
    if($row['count'] > 0) {
        $response['existe'] = true;
    }
    
    $stmt->close();
    $conexion->close();
}

header('Content-Type: application/json');
echo json_encode($response);
?>