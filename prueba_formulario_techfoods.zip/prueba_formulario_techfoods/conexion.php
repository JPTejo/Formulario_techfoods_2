<?php
	$host_db = "localhost";
	$user_db = "root";
 	$pass_db = "";
 	$db_name = "si";
 	$tbl_name = "usuarios";
	$conexion = new mysqli($host_db, $user_db, $pass_db, $db_name);
	mysqli_query($conexion,"SET NAMES 'utf8'");
?>