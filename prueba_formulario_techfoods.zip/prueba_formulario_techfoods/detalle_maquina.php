<?php
include("conexion.php");

if (isset($_GET['id_maquina'])) {
    $id_maquina = intval($_GET['id_maquina']);
    
    $conexion = new mysqli($host_db, $user_db, $pass_db, $db_name);
    
    // Obtener información de la máquina
    $sql = "SELECT * FROM maquinas WHERE id_maquina = ?";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("i", $id_maquina);
    $stmt->execute();
    $result = $stmt->get_result();
    $maquina = $result->fetch_assoc();
    
    // Verificar si está ocupada
    $sql_ocupada = "SELECT mov.nro_op, mov.fecha_registro, s.Observacion 
                   FROM op_movimientos mov
                   JOIN solicitud s ON mov.nro_op = s.nro_op
                   WHERE mov.id_maquina = ?
                   AND mov.accion_realizada = 'entrada_proceso'
                   AND NOT EXISTS (
                       SELECT 1 
                       FROM op_movimientos mov2
                       WHERE mov2.nro_op = mov.nro_op
                       AND mov2.id_maquina = mov.id_maquina
                       AND mov2.accion_realizada = 'salida_proceso'
                   )";
    $stmt_ocupada = $conexion->prepare($sql_ocupada);
    $stmt_ocupada->bind_param("i", $id_maquina);
    $stmt_ocupada->execute();
    $result_ocupada = $stmt_ocupada->get_result();
    $ocupada = $result_ocupada->fetch_assoc();
    
    // Obtener historial reciente
    $sql_historial = "SELECT mov.accion_realizada, mov.fecha_registro, s.nro_op, s.Observacion 
                     FROM op_movimientos mov
                     JOIN solicitud s ON mov.nro_op = s.nro_op
                     WHERE mov.id_maquina = ?
                     ORDER BY mov.fecha_registro DESC
                     LIMIT 5";
    $stmt_historial = $conexion->prepare($sql_historial);
    $stmt_historial->bind_param("i", $id_maquina);
    $stmt_historial->execute();
    $historial = $stmt_historial->get_result();
    
    echo '<div class="maquina-detalle">';
    echo '<h4>' . htmlspecialchars($maquina['nombre']) . '</h4>';
    echo '<p><strong>ID:</strong> ' . $maquina['id_maquina'] . '</p>';
    
    if ($maquina['descripcion']) {
        echo '<p><strong>Descripción:</strong> ' . htmlspecialchars($maquina['descripcion']) . '</p>';
    }
    
    if ($ocupada) {
        echo '<div class="alert alert-danger">';
        echo '<h5><i class="fa fa-exclamation-triangle"></i> Máquina Ocupada</h5>';
        echo '<p><strong>OP:</strong> ' . htmlspecialchars($ocupada['nro_op']) . '</p>';
        echo '<p><strong>Desde:</strong> ' . date('d/m/Y H:i', strtotime($ocupada['fecha_registro'])) . '</p>';
        echo '<p><strong>Observación:</strong> ' . htmlspecialchars($ocupada['Observacion']) . '</p>';
        echo '</div>';
    } else {
        echo '<div class="alert alert-success">';
        echo '<h5><i class="fa fa-check-circle"></i> Máquina Disponible</h5>';
        echo '<p>Esta máquina está actualmente libre para producción.</p>';
        echo '</div>';
    }
    
    echo '<h5>Historial Reciente</h5>';
    if ($historial->num_rows > 0) {
        echo '<div class="table-responsive">';
        echo '<table class="table table-striped">';
        echo '<thead><tr><th>Acción</th><th>OP</th><th>Fecha</th><th>Observación</th></tr></thead>';
        echo '<tbody>';
        while ($item = $historial->fetch_assoc()) {
            $accion = '';
            switch ($item['accion_realizada']) {
                case 'entrada_proceso': $accion = '<span class="badge badge-primary">Entrada</span>'; break;
                case 'salida_proceso': $accion = '<span class="badge badge-success">Salida</span>'; break;
                default: $accion = ucfirst(str_replace('_', ' ', $item['accion_realizada']));
            }
            
            echo '<tr>';
            echo '<td>' . $accion . '</td>';
            echo '<td>' . htmlspecialchars($item['nro_op']) . '</td>';
            echo '<td>' . date('d/m/Y H:i', strtotime($item['fecha_registro'])) . '</td>';
            echo '<td>' . htmlspecialchars($item['Observacion']) . '</td>';
            echo '</tr>';
        }
        echo '</tbody></table></div>';
    } else {
        echo '<p>No hay registros recientes para esta máquina.</p>';
    }
    
    echo '</div>';
    
    $stmt->close();
    $stmt_ocupada->close();
    $stmt_historial->close();
    $conexion->close();
} else {
    echo '<div class="alert alert-danger">ID de máquina no especificado</div>';
}
?>