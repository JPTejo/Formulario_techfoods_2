<?php
session_start();
include("conexion.php");
include("layout.php");

// Verificar autenticación
if (!isset($_SESSION['id_usuario'])) {
    header('Location: index.html');
    exit;
}

// Obtener ID de la OP
$id_op = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id_op <= 0) {
    header("Location: tabla.php?error=OP no válida");
    exit;
}

// Consulta para datos principales de la OP
$sql_op = "SELECT s.*, 
                   u.nombre as solicitante, 
                   u.cargo,
                   p.nombre as prioridad,
                   st.nombre as estado,
                   st.id_status
            FROM solicitud s
            JOIN usuarios u ON s.id_usuario = u.id_usuario
            JOIN prioridad p ON s.id_prioridad = p.id_prioridad
            JOIN status st ON s.id_status = st.id_status
            WHERE s.id_solicitud = ?";

$stmt_op = $conexion->prepare($sql_op);
$stmt_op->bind_param("i", $id_op);
$stmt_op->execute();
$result_op = $stmt_op->get_result();

if ($result_op->num_rows === 0) {
    header("Location: tabla.php?error=OP no encontrada");
    exit;
}

$op = $result_op->fetch_assoc();

// Manejar OPs sin número
if (empty($op['nro_op'])) {
    $op['nro_op'] = 'TEMP-' . $op['id_solicitud'];
}

// Configurar título de la página
$pagina = "Detalle OP-" . $op['nro_op'];
head($pagina);

// Función auxiliar para obtener el nombre de un insumo por ID
function getNombreInsumo($conexion, $id_insumo) {
    if (!$id_insumo) return "Producto no especificado";
    
    $sql = "SELECT nombre FROM insumos WHERE id_insumo = ?";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("i", $id_insumo);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['nombre'];
    }
    
    return "Producto desconocido";
}

// Consulta optimizada para el historial sin duplicados
$sql_historial = "SELECT 
    h.id_historial,
    h.at_time,
    u.nombre as usuario, 
    u.foto,
    s.nombre as estado,
    c.contenido as comentario,
    e.id_entrega,
    mi.id_mov_inventario,
    mi.tipo as mov_tipo
FROM historial h
JOIN usuarios u ON h.id_usuario = u.id_usuario
JOIN status s ON h.id_status_nuevo = s.id_status
LEFT JOIN comentario c ON h.id_solicitud = c.id_solicitud 
    AND h.id_usuario = c.id_usuario
    AND ABS(TIMESTAMPDIFF(MINUTE, h.at_time, c.at_time)) < 5
LEFT JOIN entregas e ON h.id_solicitud = e.id_solicitud 
    AND h.id_usuario = e.id_usuario
    AND ABS(TIMESTAMPDIFF(MINUTE, h.at_time, e.at_time)) < 5
LEFT JOIN mov_inventario mi ON h.id_solicitud = mi.id_solicitud 
    AND h.id_usuario = mi.id_usuario
    AND ABS(TIMESTAMPDIFF(MINUTE, h.at_time, mi.fecha)) < 5
WHERE h.id_solicitud = ?
GROUP BY h.id_historial
ORDER BY h.at_time DESC";

$stmt_historial = $conexion->prepare($sql_historial);
$stmt_historial->bind_param("i", $id_op);
$stmt_historial->execute();
$historial = $stmt_historial->get_result();

// Función para obtener productos de entrega por ID de entrega
function getProductosEntrega($conexion, $id_entrega) {
    $productos = [];
    
    if ($id_entrega) {
        $sql = "SELECT es.id_insumo, es.cantidad
                FROM entregas_solicitud es
                WHERE es.id_entrega = ?";
        $stmt = $conexion->prepare($sql);
        $stmt->bind_param("i", $id_entrega);
        $stmt->execute();
        $result = $stmt->get_result();
        
        while ($row = $result->fetch_assoc()) {
            $productos[] = [
                'id_insumo' => $row['id_insumo'],
                'cantidad' => $row['cantidad'],
                'nombre' => getNombreInsumo($conexion, $row['id_insumo'])
            ];
        }
    }
    
    return $productos;
}

// Función para obtener productos de movimiento por ID de movimiento
function getProductosMovimiento($conexion, $id_movimiento) {
    $productos = [];
    
    if ($id_movimiento) {
        $sql = "SELECT mid.id_insumo, mid.cantidad
                FROM mov_inventario_detalles mid
                WHERE mid.id_mov_inventario = ?";
        $stmt = $conexion->prepare($sql);
        $stmt->bind_param("i", $id_movimiento);
        $stmt->execute();
        $result = $stmt->get_result();
        
        while ($row = $result->fetch_assoc()) {
            $productos[] = [
                'id_insumo' => $row['id_insumo'],
                'cantidad' => $row['cantidad'],
                'nombre' => getNombreInsumo($conexion, $row['id_insumo'])
            ];
        }
    }
    
    return $productos;
}

// Mapeo de estados a etapas
$etapas = [
    'Planificación' => ['pendiente', 'aprobado', 'rechazado'],
    'Entrega/recepción MP' => ['entregado'],
    'En proceso' => ['en proceso'],
    'Despacho' => ['finalizado']
];

// Determinar la etapa actual
$etapa_actual = '';
foreach ($etapas as $etapa => $estados) {
    if (in_array(strtolower($op['estado']), $estados)) {
        $etapa_actual = $etapa;
        break;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pagina; ?></title>
    <style>
        /* Estilos mejorados para integración con layout */
        .ibox-content .card {
            border: 1px solid #e7eaec;
            border-radius: 3px;
        }
        
        /* NUEVO ESTILO PARA LA LÍNEA DE TIEMPO DE 4 ETAPAS */
        .timeline-etapas {
            display: flex;
            justify-content: space-between;
            margin: 30px 0;
            position: relative;
        }
        
        .timeline-etapas::before {
            content: '';
            position: absolute;
            top: 20px;
            left: 0;
            right: 0;
            height: 4px;
            background-color: #e0e0e0;
            z-index: 1;
        }
        
        .etapa {
            text-align: center;
            position: relative;
            z-index: 2;
            flex: 1;
        }
        
        .etapa .etapa-circulo {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #e0e0e0;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 10px;
            font-weight: bold;
            color: #fff;
            position: relative;
        }
        
        .etapa.activa .etapa-circulo {
            background: #1ab394;
        }
        
        .etapa .etapa-texto {
            font-size: 14px;
            font-weight: 600;
            color: #333;
            padding: 0 5px;
            line-height: 1.4;
        }
        
        .etapa.activa .etapa-texto {
            color: #1ab394;
        }
        
        /* AJUSTES PARA EL HISTORIAL VERTICAL */
        .timeline-container {
            position: relative;
            padding-left: 50px;
            margin-top: 30px;
        }
        
        .timeline-container::before {
            content: '';
            position: absolute;
            left: 15px;
            top: 0;
            bottom: 0;
            width: 2px;
            background-color: #e0e0e0;
        }
        
        .timeline-event {
            position: relative;
            margin-bottom: 25px;
        }
        
        .timeline-time {
            position: absolute;
            left: -50px;
            width: 40px;
            text-align: right;
            color: #6c757d;
            font-size: 0.85em;
            top: 5px; /* Ajuste para alinear con el texto */
        }
        
        .timeline-content {
            background: white;
            padding: 15px;
            border-radius: 6px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            border-left: 3px solid #3498db;
        }
        
        .timeline-comment {
            background: #f8f9fa;
            border-left: 3px solid #17a2b8;
            padding: 8px 12px;
            margin-top: 10px;
            font-size: 0.9em;
            border-radius: 0 4px 4px 0;
        }
        
        .timeline-detail {
            background: rgba(0,0,0,0.03);
            padding: 8px 12px;
            border-radius: 4px;
            font-size: 0.9em;
            margin-top: 5px;
        }
        
        .status-badge {
            padding: 4px 8px;
            border-radius: 3px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .badge-pendiente { background-color: #f8ac59; color: #fff; }
        .badge-aprobado { background-color: #1ab394; color: white; }
        .badge-rechazado { background-color: #ed5565; color: white; }
        .badge-proceso { background-color: #23c6c8; color: white; }
        .badge-completado { background-color: #6c757d; color: white; }
        
        .text-ingreso { color: #1c84c6; }
        .text-egreso { color: #ed5565; }
        
        .collapse-toggle {
            cursor: pointer;
            color: #3498db;
        }
        
        .collapse-content {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.3s ease-out;
        }
        
        .collapse-content.show {
            max-height: 1000px; /* Ajustar según necesidad */
        }
        
        @media (max-width: 768px) {
            .timeline-container {
                padding-left: 30px;
            }
            
            .timeline-time {
                left: -30px;
                width: 25px;
                font-size: 0.75em;
            }
            
            .timeline-etapas {
                flex-wrap: wrap;
            }
            
            .etapa {
                flex: 0 0 50%;
                margin-bottom: 20px;
            }
        }
    </style>
</head>
<body>
    <div id="wrapper">
        <?php menu_lateral($_SESSION['id_usuario']); ?>
        
        <div id="page-wrapper" class="gray-bg">
            <?php barra_superior($_SESSION['id_usuario'], $pagina); ?>
            
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>Detalle de OP-<?php echo htmlspecialchars($op['nro_op']); ?></h2>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="home.php">Inicio</a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="tabla.php">Órdenes de Producción</a>
                        </li>
                        <li class="breadcrumb-item active">
                            <strong>Detalle OP-<?php echo htmlspecialchars($op['nro_op']); ?></strong>
                        </li>
                    </ol>
                </div>
            </div>

            <div class="wrapper wrapper-content animated fadeInRight">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="ibox">
                            <div class="ibox-title">
                                <h5>
                                    OP-<?php echo htmlspecialchars($op['nro_op']); ?>
                                <span class="status-badge badge-<?php echo str_replace(' ', '-', strtolower($op['estado'])); ?> float-right">
                                    <?php echo htmlspecialchars($op['estado']); ?>
                                    <?php if (strtolower($op['estado']) == 'completo'): ?>
                                        <i class="fa fa-check fa-lg ml-1 text-success"></i> <!-- Verde y más grande -->
                                    <?php else: ?>
                                        <i class="fa fa-times fa-lg ml-1 text-danger"></i> <!-- Rojo y más grande -->
                                    <?php endif; ?>
                                </span>
                                </h5>
                            </div>
                            
                            <div class="ibox-content">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="panel panel-info">
                                            <div class="panel-heading">
                                                <i class="fa fa-user"></i> Información del Solicitante
                                            </div>
                                            <div class="panel-body">
                                                <p><strong>Nombre:</strong> <?php echo htmlspecialchars($op['solicitante']); ?></p>
                                                <p><strong>Cargo:</strong> <?php echo htmlspecialchars($op['cargo']); ?></p>
                                                <p><strong>Fecha creación:</strong> <?php echo date('d/m/Y H:i', strtotime($op['at_time'])); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="panel panel-info">
                                            <div class="panel-heading">
                                                <i class="fa fa-info-circle"></i> Detalles de la OP
                                            </div>
                                            <div class="panel-body">
                                            <p><strong>Prioridad:</strong> 
                                                <span class="badge badge-<?php echo getPrioridadClass($op['prioridad']); ?>">
                                                    <?php echo htmlspecialchars($op['prioridad']); ?>
                                                </span>
                                            </p>
                                                <p><strong>Fecha prevista:</strong> <?php echo date('d/m/Y', strtotime($op['fecha_prevista'])); ?></p>
                                                <?php if (!empty($op['Observacion'])): ?>
                                                    <p><strong>Observaciones:</strong> <?php echo htmlspecialchars($op['Observacion']); ?></p>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- NUEVA LÍNEA DE TIEMPO DE 4 ETAPAS -->
                                <div class="hr-line-dashed"></div>
                                <div class="panel panel-primary">
                                    <div class="panel-heading">
                                        <i class="fa fa-tasks"></i> Etapas de la OP
                                    </div>
                                    <div class="panel-body">
                                        <div class="timeline-etapas">
                                            <div class="etapa <?php echo ($etapa_actual == 'Planificación') ? 'activa' : ''; ?>">
                                                <div class="etapa-circulo">1</div>
                                                <div class="etapa-texto">Planificación</div>
                                            </div>
                                            <div class="etapa <?php echo ($etapa_actual == 'Entrega/recepción MP') ? 'activa' : ''; ?>">
                                                <div class="etapa-circulo">2</div>
                                                <div class="etapa-texto">Entrega/recepción MP</div>
                                            </div>
                                            <div class="etapa <?php echo ($etapa_actual == 'En proceso') ? 'activa' : ''; ?>">
                                                <div class="etapa-circulo">3</div>
                                                <div class="etapa-texto">En proceso</div>
                                            </div>
                                            <div class="etapa <?php echo ($etapa_actual == 'Despacho') ? 'activa' : ''; ?>">
                                                <div class="etapa-circulo">4</div>
                                                <div class="etapa-texto">Despacho</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="hr-line-dashed"></div>
                                
                                <div class="panel panel-primary">
                                    <div class="panel-heading">
                                        <i class="fa fa-cubes"></i> Productos Solicitados
                                    </div>
                                    <div class="panel-body">
                                        <div class="table-responsive">
                                            <table class="table table-striped table-hover">
                                                <thead>
                                                    <tr>
                                                        <th>Código</th>
                                                        <th>Insumo</th>
                                                        <th>Cantidad</th>
                                                        <th>Unidad</th>
                                                        <th>Estado</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $sql_productos = "SELECT sd.*, 
                                                                            i.codigo, 
                                                                            i.nombre as insumo,
                                                                            u.abreviatura as unidad
                                                                     FROM solicitudes_detalles sd
                                                                     JOIN insumos i ON sd.id_insumo = i.id_insumo
                                                                     JOIN unidades u ON i.id_unidad = u.id_unidad
                                                                     WHERE sd.id_solicitud = ?";
                                                    $stmt_productos = $conexion->prepare($sql_productos);
                                                    $stmt_productos->bind_param("i", $id_op);
                                                    $stmt_productos->execute();
                                                    $productos = $stmt_productos->get_result();
                                                    
                                                    while($producto = $productos->fetch_assoc()):
                                                        $estado_class = str_replace(' ', '-', strtolower($producto['estado']));
                                                    ?>
                                                    <tr>
                                                        <td><?php echo htmlspecialchars($producto['codigo']); ?></td>
                                                        <td><?php echo htmlspecialchars($producto['insumo']); ?></td>
                                                        <td><?php echo htmlspecialchars($producto['cantidad']); ?></td>
                                                        <td><?php echo htmlspecialchars($producto['unidad']); ?></td>
                                                        <td>
                                                            <span class="status-badge badge-<?= $estado_class ?>">
                                                                <?php echo htmlspecialchars($producto['estado']); ?>
                                                            </span>
                                                        </td>
                                                    </tr>
                                                    <?php endwhile; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="hr-line-dashed"></div>
                                
                                <div class="panel panel-primary">
                                    <div class="panel-heading">
                                        <i class="fa fa-history"></i> Historial de la OP
                                    </div>
                                    <div class="panel-body">
                                        <div class="timeline-container">
                                            <?php while($evento = $historial->fetch_assoc()): 
                                                // Obtener productos solo si es necesario
                                                $productos_entrega = [];
                                                $productos_movimiento = [];
                                                
                                                if ($evento['id_entrega']) {
                                                    $productos_entrega = getProductosEntrega($conexion, $evento['id_entrega']);
                                                }
                                                
                                                if ($evento['id_mov_inventario']) {
                                                    $productos_movimiento = getProductosMovimiento($conexion, $evento['id_mov_inventario']);
                                                }
                                            ?>
                                                <div class="timeline-event">
                                                    <div class="timeline-time">
                                                        <?php echo date('d/m H:i', strtotime($evento['at_time'])); ?>
                                                    </div>
                                                    <div class="timeline-content">
                                                        <div class="d-flex align-items-center">
                                                            <?php if (!empty($evento['foto'])): ?>
                                                                <img src="uploads/<?php echo htmlspecialchars($evento['foto']); ?>" 
                                                                     class="rounded-circle mr-2" width="30" height="30" alt="Usuario">
                                                            <?php else: ?>
                                                                <div class="rounded-circle bg-secondary text-white d-flex align-items-center justify-content-center mr-2" 
                                                                     style="width: 30px; height: 30px;">
                                                                    <?php echo strtoupper(substr($evento['usuario'], 0, 1)); ?>
                                                                </div>
                                                            <?php endif; ?>
                                                            <h5 class="m-0"><?php echo htmlspecialchars($evento['usuario']); ?></h5>
                                                        </div>
                                                        
                                                        <div class="mt-2">
                                                            <strong class="text-<?php echo getEstadoColorClass($evento['estado']); ?>">
                                                                <?php echo htmlspecialchars($evento['estado']); ?>
                                                            </strong>
                                                            
                                                            <?php if (!empty($evento['comentario'])): ?>
                                                                <div class="timeline-comment mt-1">
                                                                    <i class="fa fa-comment"></i> <?php echo htmlspecialchars($evento['comentario']); ?>
                                                                </div>
                                                            <?php endif; ?>
                                                            
                                                            <?php if (!empty($productos_entrega)): ?>
                                                                <div class="timeline-detail mt-2">
                                                                    <div class="d-flex justify-content-between align-items-center">
                                                                        <div>
                                                                            <i class="fa fa-truck text-success"></i> 
                                                                            <strong>Entrega registrada</strong>
                                                                            <span class="badge badge-light"><?= count($productos_entrega) ?> productos</span>
                                                                        </div>
                                                                        <span class="collapse-toggle" data-target="entrega-<?= $evento['id_historial'] ?>">
                                                                            <i class="fa fa-chevron-down"></i> Ver detalles
                                                                        </span>
                                                                    </div>
                                                                    
                                                                    <div class="collapse-content" id="entrega-<?= $evento['id_historial'] ?>">
                                                                        <ul class="mt-2 mb-0 pl-3">
                                                                            <?php foreach($productos_entrega as $entrega): ?>
                                                                                <li>
                                                                                    <?php echo htmlspecialchars($entrega['cantidad']); ?> 
                                                                                    unidades de <?php echo htmlspecialchars($entrega['nombre']); ?>
                                                                                </li>
                                                                            <?php endforeach; ?>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            <?php endif; ?>
                                                            
                                                            <?php if (!empty($productos_movimiento)): ?>
                                                                <div class="timeline-detail mt-2">
                                                                    <div class="d-flex justify-content-between align-items-center">
                                                                        <div>
                                                                            <i class="fa fa-exchange-alt text-info"></i> 
                                                                            <strong>Movimiento de inventario:</strong>
                                                                            <?php
                                                                            $tipo = ($evento['mov_tipo'] == 'E') ? 'ingreso' : 'egreso';
                                                                            $clase = ($evento['mov_tipo'] == 'E') ? 'text-ingreso' : 'text-egreso';
                                                                            ?>
                                                                            <span class="<?= $clase ?>"><?= strtoupper($tipo) ?></span>
                                                                            <span class="badge badge-light"><?= count($productos_movimiento) ?> productos</span>
                                                                        </div>
                                                                        <span class="collapse-toggle" data-target="movimiento-<?= $evento['id_historial'] ?>">
                                                                            <i class="fa fa-chevron-down"></i> Ver detalles
                                                                        </span>
                                                                    </div>
                                                                    
                                                                    <div class="collapse-content" id="movimiento-<?= $evento['id_historial'] ?>">
                                                                        <ul class="mt-2 mb-0 pl-3">
                                                                            <?php foreach($productos_movimiento as $movimiento): ?>
                                                                                <li>
                                                                                    <?php echo htmlspecialchars($movimiento['cantidad']); ?> 
                                                                                    unidades de <?php echo htmlspecialchars($movimiento['nombre']); ?>
                                                                                </li>
                                                                            <?php endforeach; ?>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endwhile; ?>
                                            
                                            <?php if ($historial->num_rows === 0): ?>
                                                <div class="text-center py-4">
                                                    <i class="fa fa-inbox fa-2x text-muted mb-2"></i>
                                                    <p>No hay historial registrado para esta OP</p>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                
                                <?php if ($op['id_status'] != 5): // Si no está finalizada ?>
                                <div class="hr-line-dashed"></div>
                                
                                <div class="panel panel-warning">
                                    <div class="panel-heading">
                                        <i class="fa fa-plus-circle"></i> Agregar Acción
                                    </div>
                                    <div class="panel-body">
                                        <form method="POST" action="accion_op.php">
                                            <input type="hidden" name="id_solicitud" value="<?php echo $id_op; ?>">
                                            
                                            <div class="form-row">
                                                <div class="form-group col-md-4">
                                                    <label>Acción</label>
                                                    <select name="accion" class="form-control" required>
                                                        <option value="">Seleccionar acción...</option>
                                                        <?php if ($_SESSION['is_admin'] || $_SESSION['is_entregador']): ?>
                                                            <option value="aprobar">Aprobar OP</option>
                                                            <option value="rechazar">Rechazar OP</option>
                                                            <option value="entregar">Registrar entrega</option>
                                                            <option value="movimiento">Registrar movimiento</option>
                                                        <?php endif; ?>
                                                        <option value="comentario">Agregar comentario</option>
                                                    </select>
                                                </div>
                                                
                                                <div class="form-group col-md-8">
                                                    <label>Comentario</label>
                                                    <textarea name="comentario" class="form-control" rows="2"></textarea>
                                                </div>
                                            </div>
                                            
                                            <div class="text-right">
                                                <button type="submit" class="btn btn-primary">
                                                    <i class="fa fa-save"></i> Guardar Acción
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <?php footer(); ?>
        </div>
    </div>

    <?php scrips(); ?>

    <script>
        $(document).ready(function() {
            // Inicializar tooltips
            $('[data-toggle="tooltip"]').tooltip();
            
            // Controlar visibilidad de campos según acción seleccionada
            $('select[name="accion"]').change(function() {
                var accion = $(this).val();
                if (accion === 'comentario') {
                    $('textarea[name="comentario"]').attr('required', true);
                } else {
                    $('textarea[name="comentario"]').removeAttr('required');
                }
            });
            
            // Toggle para mostrar/ocultar detalles
            $('.collapse-toggle').click(function() {
                const target = $(this).data('target');
                const $content = $('#' + target);
                const $icon = $(this).find('i');
                
                $content.toggleClass('show');
                
                if ($content.hasClass('show')) {
                    $icon.removeClass('fa-chevron-down').addClass('fa-chevron-up');
                    $(this).html('<i class="fa fa-chevron-up"></i> Ocultar detalles');
                } else {
                    $icon.removeClass('fa-chevron-up').addClass('fa-chevron-down');
                    $(this).html('<i class="fa fa-chevron-down"></i> Ver detalles');
                }
            });
        });
    </script>
</body>
</html>

<?php
// Funciones auxiliares
function getPrioridadClass($prioridad) {
    switch(strtolower($prioridad)) {
        case 'critica': return 'danger'; // Clase de Bootstrap/MDB
        case 'urgente': return 'warning';
        case 'normal': return 'primary';
        case 'tranquilo': return 'success';
        default: return 'secondary';
    }
}

function getEstadoColorClass($estado) {
    switch(strtolower($estado)) {
        case 'pendiente': return 'warning';
        case 'aprobado': return 'success';
        case 'rechazado': return 'danger';
        case 'en proceso': return 'info';
        case 'finalizado': return 'default';
        default: return 'primary';
    }
}
?>