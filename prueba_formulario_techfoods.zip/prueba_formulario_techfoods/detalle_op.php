<?php
session_start();
include("conexion.php");
include("layout.php");

// Verificar autenticación
if (!isset($_SESSION['id_usuario'])) {
    header('Location: index.html');
    exit;
}

// Obtener ID de la OP
$id_op = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id_op <= 0) {
    header("Location: tabla.php?error=OP no válida");
    exit;
}

// Consulta para datos principales de la OP
$sql_op = "SELECT s.*, 
                   u.nombre as solicitante, 
                   u.cargo,
                   p.nombre as prioridad,
                   st.nombre as estado,
                   st.id_status
            FROM solicitud s
            JOIN usuarios u ON s.id_usuario = u.id_usuario
            JOIN prioridad p ON s.id_prioridad = p.id_prioridad
            JOIN status st ON s.id_status = st.id_status
            WHERE s.id_solicitud = ?";

$stmt_op = $conexion->prepare($sql_op);
$stmt_op->bind_param("i", $id_op);
$stmt_op->execute();
$result_op = $stmt_op->get_result();

if ($result_op->num_rows === 0) {
    header("Location: tabla.php?error=OP no encontrada");
    exit;
}

$op = $result_op->fetch_assoc();

// Manejar OPs sin número
if (empty($op['nro_op'])) {
    $op['nro_op'] = 'TEMP-' . $op['id_solicitud'];
}

// Configurar título de la página
$pagina = "Detalle OP-" . $op['nro_op'];
head($pagina);

// Función auxiliar para obtener el nombre de un insumo por ID
function getNombreInsumo($conexion, $id_insumo) {
    if (!$id_insumo) return "Producto no especificado";
    
    $sql = "SELECT nombre FROM insumos WHERE id_insumo = ?";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("i", $id_insumo);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['nombre'];
    }
    
    return "Producto desconocido";
}

// Consulta para movimientos de producción (op_movimientos)
$sql_produccion = "SELECT 
    om.*,
    u.nombre as usuario_nombre,
    u.foto as usuario_foto,
    i.nombre as insumo_nombre,
    i_sust.nombre as insumo_sustituto_nombre,
    p.nombre as producto_nombre,
    m.nombre as maquina_nombre
FROM op_movimientos om
JOIN usuarios u ON om.id_usuario = u.id_usuario
LEFT JOIN insumos i ON om.id_insumo = i.id_insumo
LEFT JOIN insumos i_sust ON om.id_insumo_sustituto = i_sust.id_insumo
LEFT JOIN productos p ON om.id_producto = p.id_producto
LEFT JOIN maquinas m ON om.id_maquina = m.id_maquina
WHERE om.id_solicitud = ?
ORDER BY om.fecha_registro DESC";

$stmt_produccion = $conexion->prepare($sql_produccion);
$stmt_produccion->bind_param("i", $id_op);
$stmt_produccion->execute();
$produccion = $stmt_produccion->get_result();

// Consulta optimizada para el historial sin duplicados
$sql_historial = "SELECT 
    h.id_historial,
    h.at_time,
    u.nombre as usuario, 
    u.foto,
    s.nombre as estado,
    c.contenido as comentario,
    e.id_entrega,
    mi.id_mov_inventario,
    mi.tipo as mov_tipo
FROM historial h
JOIN usuarios u ON h.id_usuario = u.id_usuario
JOIN status s ON h.id_status_nuevo = s.id_status
LEFT JOIN comentario c ON h.id_solicitud = c.id_solicitud 
    AND h.id_usuario = c.id_usuario
    AND ABS(TIMESTAMPDIFF(MINUTE, h.at_time, c.at_time)) < 5
LEFT JOIN entregas e ON h.id_solicitud = e.id_solicitud 
    AND h.id_usuario = e.id_usuario
    AND ABS(TIMESTAMPDIFF(MINUTE, h.at_time, e.at_time)) < 5
LEFT JOIN mov_inventario mi ON h.id_solicitud = mi.id_solicitud 
    AND h.id_usuario = mi.id_usuario
    AND ABS(TIMESTAMPDIFF(MINUTE, h.at_time, mi.fecha)) < 5
WHERE h.id_solicitud = ?
GROUP BY h.id_historial
ORDER BY h.at_time DESC";

$stmt_historial = $conexion->prepare($sql_historial);
$stmt_historial->bind_param("i", $id_op);
$stmt_historial->execute();
$historial = $stmt_historial->get_result();

// Función para obtener productos de entrega por ID de entrega
function getProductosEntrega($conexion, $id_entrega) {
    $productos = [];
    
    if ($id_entrega) {
        $sql = "SELECT es.id_insumo, es.cantidad
                FROM entregas_solicitud es
                WHERE es.id_entrega = ?";
        $stmt = $conexion->prepare($sql);
        $stmt->bind_param("i", $id_entrega);
        $stmt->execute();
        $result = $stmt->get_result();
        
        while ($row = $result->fetch_assoc()) {
            $productos[] = [
                'id_insumo' => $row['id_insumo'],
                'cantidad' => $row['cantidad'],
                'nombre' => getNombreInsumo($conexion, $row['id_insumo'])
            ];
        }
    }
    
    return $productos;
}

// Función para obtener productos de movimiento por ID de movimiento
function getProductosMovimiento($conexion, $id_movimiento) {
    $productos = [];
    
    if ($id_movimiento) {
        $sql = "SELECT mid.id_insumo, mid.cantidad
                FROM mov_inventario_detalles mid
                WHERE mid.id_mov_inventario = ?";
        $stmt = $conexion->prepare($sql);
        $stmt->bind_param("i", $id_movimiento);
        $stmt->execute();
        $result = $stmt->get_result();
        
        while ($row = $result->fetch_assoc()) {
            $productos[] = [
                'id_insumo' => $row['id_insumo'],
                'cantidad' => $row['cantidad'],
                'nombre' => getNombreInsumo($conexion, $row['id_insumo'])
            ];
        }
    }
    
    return $productos;
}

// SOLUCIÓN: Consulta unificada para movimientos usando id_mov_inventario
$sql_movimientos = "SELECT 
    mi.id_mov_inventario,
    mi.fecha as fecha_registro,
    mi.tipo,
    mi.nota,
    u.nombre as usuario_nombre,
    u.foto as usuario_foto,
    mid.id_insumo,
    mid.cantidad
FROM mov_inventario mi
JOIN usuarios u ON mi.id_usuario = u.id_usuario
JOIN mov_inventario_detalles mid ON mi.id_mov_inventario = mid.id_mov_inventario
WHERE mi.id_solicitud = ?
ORDER BY mi.fecha DESC";

$stmt_movimientos = $conexion->prepare($sql_movimientos);
$stmt_movimientos->bind_param("i", $id_op);
$stmt_movimientos->execute();
$movimientos = $stmt_movimientos->get_result();

// Agrupar movimientos por ID
$movimientos_agrupados = [];
while ($mov = $movimientos->fetch_assoc()) {
    $id_mov = $mov['id_mov_inventario'];
    if (!isset($movimientos_agrupados[$id_mov])) {
        $movimientos_agrupados[$id_mov] = [
            'id_mov_inventario' => $id_mov,
            'fecha_registro' => $mov['fecha_registro'],
            'tipo' => $mov['tipo'],
            'nota' => $mov['nota'],
            'usuario_nombre' => $mov['usuario_nombre'],
            'usuario_foto' => $mov['usuario_foto'],
            'productos' => []
        ];
    }
    $movimientos_agrupados[$id_mov]['productos'][] = [
        'id_insumo' => $mov['id_insumo'],
        'cantidad' => $mov['cantidad'],
        'nombre' => getNombreInsumo($conexion, $mov['id_insumo'])
    ];
}

// SOLUCIÓN CORREGIDA: Mapeo de estados a etapas usando IDs
$etapas = [
    'Planificación' => 1, // ID de estados para planificación
    'Entrega/recepción MP' => 2, // ID de estados para entrega
    'En proceso' => 3, // ID de estados para proceso
    'Despacho' => [4, 5] // ID de estados para despacho/completado
];

// Determinar la etapa actual basada en el ID de estado
$etapa_actual = 'Planificación';
$id_estado_actual = $op['id_status'];

if ($id_estado_actual >= $etapas['Despacho'][0]) {
    $etapa_actual = 'Despacho';
} elseif ($id_estado_actual >= $etapas['En proceso']) {
    $etapa_actual = 'En proceso';
} elseif ($id_estado_actual >= $etapas['Entrega/recepción MP']) {
    $etapa_actual = 'Entrega/recepción MP';
}

// Calcular porcentaje de progreso para la línea
$porcentajes = [
    'Planificación' => 0,
    'Entrega/recepción MP' => 33,
    'En proceso' => 66,
    'Despacho' => 100
];

$porcentaje_progreso = $porcentajes[$etapa_actual];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pagina; ?></title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/css/lightbox.min.css" rel="stylesheet">
    <style>
        /* Estilo tipo Excel */
        .excel-table {
            border-collapse: collapse;
            width: 100%;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-size: 14px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        
        .excel-table th {
            background-color: #f2f2f2;
            border: 1px solid #ddd;
            padding: 8px 12px;
            text-align: left;
            font-weight: 600;
            position: sticky;
            top: 0;
            z-index: 10;
        }
        
        .excel-table td {
            border: 1px solid #ddd;
            padding: 8px 12px;
            background-color: white;
        }
        
        .excel-table tr:nth-child(even) td {
            background-color: #f9f9f9;
        }
        
        .excel-table tr:hover td {
            background-color: #f1f7ff;
        }
        
        .excel-header {
            background-color: #2c3e50;
            color: white;
            padding: 8px 15px;
            font-weight: bold;
        }
        
        .frozen-column {
            position: sticky;
            left: 0;
            z-index: 5;
            background-color: white;
            box-shadow: 2px 0 3px rgba(0,0,0,0.1);
        }
        
        .frozen-header {
            z-index: 15 !important;
            background-color: #f2f2f2;
        }
        
        .table-container {
            overflow: auto;
            max-height: 70vh;
            border: 1px solid #ddd;
            background-color: white;
        }
        
        .filter-container {
            background-color: #f8f9fa;
            padding: 15px;
            border: 1px solid #ddd;
            border-bottom: none;
            margin-bottom: 0;
        }
        
        .status-badge {
            padding: 4px 8px;
            border-radius: 3px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .badge-pendiente { background-color: #ffc107; color: #212529; }
        .badge-aprobado { background-color: #28a745; color: white; }
        .badge-rechazado { background-color: #dc3545; color: white; }
        .badge-proceso { background-color: #007bff; color: white; }
        .badge-completado { background-color: #6c757d; color: white; }
        
        /* Paginación */
        .pagination {
            margin: 0;
        }
        
        .page-item.active .page-link {
            background-color: #2c3e50;
            border-color: #2c3e50;
        }
        
        .page-link {
            color: #2c3e50;
            min-width: 36px;
            text-align: center;
        }
        
        .page-item.disabled .page-link {
            color: #6c757d;
        }
        
        .page-link:hover {
            color: #1a252f;
            background-color: #e9ecef;
        }
        
        /* LÍNEA DE TIEMPO DE 4 ETAPAS - CORREGIDA */
        .timeline-etapas {
            display: flex;
            justify-content: space-between;
            margin: 30px 0;
            position: relative;
        }
        
        .timeline-etapas::before {
            content: '';
            position: absolute;
            top: 20px;
            left: 0;
            right: 0;
            height: 4px;
            background-color: #e0e0e0;
            z-index: 1;
        }
        
        .timeline-etapas::after {
            content: '';
            position: absolute;
            top: 20px;
            left: 0;
            height: 4px;
            background-color: #1ab394;
            z-index: 2;
            width: <?= $porcentaje_progreso ?>%;
            transition: width 0.5s ease;
        }
        
        .etapa {
            text-align: center;
            position: relative;
            z-index: 3;
            flex: 1;
        }
        
        .etapa .etapa-circulo {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #e0e0e0;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 10px;
            font-weight: bold;
            color: #fff;
            position: relative;
        }
        
        .etapa.activa .etapa-circulo,
        .etapa.completada .etapa-circulo {
            background: #1ab394;
        }
        
        .etapa .etapa-texto {
            font-size: 14px;
            font-weight: 600;
            color: #333;
            padding: 0 5px;
            line-height: 1.4;
        }
        
        .etapa.activa .etapa-texto,
        .etapa.completada .etapa-texto {
            color: #1ab394;
            font-weight: bold;
        }
        
        /* ESTILOS PARA EL HISTORIAL DE MOVIMIENTOS */
        .timeline-container {
            position: relative;
            padding-left: 50px;
            margin-top: 30px;
        }
        
        .timeline-container::before {
            content: '';
            position: absolute;
            left: 15px;
            top: 0;
            bottom: 0;
            width: 2px;
            background-color: #e0e0e0;
        }
        
        .timeline-event {
            position: relative;
            margin-bottom: 25px;
        }
        
        .timeline-time {
            position: absolute;
            left: -50px;
            width: 40px;
            text-align: right;
            color: #6c757d;
            font-size: 0.85em;
            top: 5px;
        }
        
        .timeline-content {
            background: white;
            padding: 15px;
            border-radius: 6px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            border-left: 3px solid #3498db;
        }
        
        .timeline-comment {
            background: #f8f9fa;
            border-left: 3px solid #17a2b8;
            padding: 8px 12px;
            margin-top: 10px;
            font-size: 0.9em;
            border-radius: 0 4px 4px 0;
        }
        
        .timeline-detail {
            background: rgba(0,0,0,0.03);
            padding: 8px 12px;
            border-radius: 4px;
            font-size: 0.9em;
            margin-top: 5px;
        }
        
        .movimiento-detalle {
            margin-top: 10px;
            border-top: 1px solid #eee;
            padding-top: 10px;
        }
        
        .movimiento-campo {
            display: flex;
            margin-bottom: 5px;
        }
        
        .movimiento-etiqueta {
            font-weight: bold;
            min-width: 160px;
        }
        
        .movimiento-valor {
            flex: 1;
        }
        
        .text-ingreso { color: #1c84c6; }
        .text-egreso { color: #ed5565; }
        
        .collapse-toggle {
            cursor: pointer;
            color: #3498db;
        }
        
        .collapse-content {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.3s ease-out;
        }
        
        .collapse-content.show {
            max-height: 1000px;
        }
        
        .img-thumbnail {
            transition: transform 0.2s;
        }
        
        .img-thumbnail:hover {
            transform: scale(1.05);
        }
        
        @media (max-width: 768px) {
            .table-container {
                max-height: 60vh;
            }
            
            .excel-table th, 
            .excel-table td {
                padding: 6px 8px;
                font-size: 13px;
            }
            
            .timeline-container {
                padding-left: 30px;
            }
            
            .timeline-time {
                left: -30px;
                width: 25px;
                font-size: 0.75em;
            }
            
            .timeline-etapas {
                flex-wrap: wrap;
            }
            
            .etapa {
                flex: 0 0 50%;
                margin-bottom: 20px;
            }
            
            .movimiento-campo {
                flex-direction: column;
            }
            
            .movimiento-etiqueta {
                min-width: 100%;
                margin-bottom: 3px;
            }
        }
    </style>
</head>
<body>
    <div id="wrapper">
        <?php menu_lateral($_SESSION['id_usuario']); ?>
        
        <div id="page-wrapper" class="gray-bg">
            <?php barra_superior($_SESSION['id_usuario'], $pagina); ?>
            
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>Detalle de OP-<?php echo htmlspecialchars($op['nro_op']); ?></h2>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="home.php">Inicio</a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="tabla.php">Órdenes de Producción</a>
                        </li>
                        <li class="breadcrumb-item active">
                            <strong>Detalle OP-<?php echo htmlspecialchars($op['nro_op']); ?></strong>
                        </li>
                    </ol>
                </div>
            </div>

            <div class="wrapper wrapper-content animated fadeInRight">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="ibox">
                            <div class="ibox-title">
                                <h5>
                                    OP-<?php echo htmlspecialchars($op['nro_op']); ?>
                                <span class="status-badge badge-<?php echo str_replace(' ', '-', strtolower($op['estado'])); ?> float-right">
                                    <?php echo htmlspecialchars($op['estado']); ?>
                                    <?php if (strtolower($op['estado']) == 'completo'): ?>
                                        <i class="fa fa-check fa-lg ml-1 text-success"></i>
                                    <?php else: ?>
                                        <i class="fa fa-times fa-lg ml-1 text-danger"></i>
                                    <?php endif; ?>
                                </span>
                                </h5>
                            </div>
                            
                            <div class="ibox-content">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="panel panel-info">
                                            <div class="panel-heading">
                                                <i class="fa fa-user"></i> Información del Solicitante
                                            </div>
                                            <div class="panel-body">
                                                <p><strong>Nombre:</strong> <?php echo htmlspecialchars($op['solicitante']); ?></p>
                                                <p><strong>Cargo:</strong> <?php echo htmlspecialchars($op['cargo']); ?></p>
                                                <p><strong>Fecha creación:</strong> <?php echo date('d/m/Y H:i', strtotime($op['at_time'])); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="panel panel-info">
                                            <div class="panel-heading">
                                                <i class="fa fa-info-circle"></i> Detalles de la OP
                                            </div>
                                            <div class="panel-body">
                                            <p><strong>Prioridad:</strong> 
                                                <span class="badge badge-<?php echo getPrioridadClass($op['prioridad']); ?>">
                                                    <?php echo htmlspecialchars($op['prioridad']); ?>
                                                </span>
                                            </p>
                                                <p><strong>Fecha prevista:</strong> <?php echo date('d/m/Y', strtotime($op['fecha_prevista'])); ?></p>
                                                <?php if (!empty($op['Observacion'])): ?>
                                                    <p><strong>Observaciones:</strong> <?php echo htmlspecialchars($op['Observacion']); ?></p>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- LÍNEA DE TIEMPO DE 4 ETAPAS - CORREGIDA -->
                                <div class="hr-line-dashed"></div>
                                <div class="panel panel-primary">
                                    <div class="panel-heading">
                                        <i class="fa fa-tasks"></i> Etapas de la OP
                                    </div>
                                    <div class="panel-body">
                                        <div class="timeline-etapas">
                                            <?php 
                                            $etapas_orden = ['Planificación', 'Entrega/recepción MP', 'En proceso', 'Despacho'];
                                            $contador = 1;
                                            
                                            foreach ($etapas_orden as $etapa): 
                                                $activa = ($etapa_actual === $etapa) ? 'activa' : '';
                                                // Determinar si la etapa está completada
                                                $completada = ($porcentajes[$etapa] < $porcentaje_progreso) ? 'completada' : '';
                                            ?>
                                                <div class="etapa <?= $activa ?> <?= $completada ?>">
                                                    <div class="etapa-circulo"><?= $contador++ ?></div>
                                                    <div class="etapa-texto"><?= $etapa ?></div>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                        <div class="mt-3 text-center text-muted">
                                            <small>Estado actual: <strong><?= $op['estado'] ?></strong></small>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="hr-line-dashed"></div>
                                
                                <div class="panel panel-primary">
                                    <div class="panel-heading">
                                        <i class="fa fa-cubes"></i> Productos Solicitados
                                    </div>
                                    <div class="panel-body">
                                        <div class="table-responsive">
                                            <table class="table table-striped table-hover">
                                                <thead>
                                                    <tr>
                                                        <th>Código</th>
                                                        <th>Insumo</th>
                                                        <th>Cantidad</th>
                                                        <th>Unidad</th>
                                                        <th>Estado</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $sql_productos = "SELECT sd.*, 
                                                                            i.codigo, 
                                                                            i.nombre as insumo,
                                                                            u.abreviatura as unidad
                                                                     FROM solicitudes_detalles sd
                                                                     JOIN insumos i ON sd.id_insumo = i.id_insumo
                                                                     JOIN unidades u ON i.id_unidad = u.id_unidad
                                                                     WHERE sd.id_solicitud = ?";
                                                    $stmt_productos = $conexion->prepare($sql_productos);
                                                    $stmt_productos->bind_param("i", $id_op);
                                                    $stmt_productos->execute();
                                                    $productos = $stmt_productos->get_result();
                                                    
                                                    while($producto = $productos->fetch_assoc()):
                                                        $estado_class = str_replace(' ', '-', strtolower($producto['estado']));
                                                    ?>
                                                    <tr>
                                                        <td><?php echo htmlspecialchars($producto['codigo']); ?></td>
                                                        <td><?php echo htmlspecialchars($producto['insumo']); ?></td>
                                                        <td><?php echo htmlspecialchars($producto['cantidad']); ?></td>
                                                        <td><?php echo htmlspecialchars($producto['unidad']); ?></td>
                                                        <td>
                                                            <span class="status-badge badge-<?= $estado_class ?>">
                                                                <?php echo htmlspecialchars($producto['estado']); ?>
                                                            </span>
                                                        </td>
                                                    </tr>
                                                    <?php endwhile; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="hr-line-dashed"></div>
                                
                                <div class="panel panel-primary">
                                    <div class="panel-heading">
                                        <i class="fa fa-history"></i> Historial de Movimientos de la OP
                                    </div>
                                    <div class="panel-body">
                                        <div class="timeline-container">
                                            <?php if ($produccion->num_rows > 0 || !empty($movimientos_agrupados) || $historial->num_rows > 0): ?>
                                                <?php while($prod = $produccion->fetch_assoc()): ?>
                                                    <div class="timeline-event">
                                                        <div class="timeline-time">
                                                            <?php echo date('d/m H:i', strtotime($prod['fecha_registro'])); ?>
                                                        </div>
                                                        <div class="timeline-content">
                                                            <div class="d-flex align-items-center">
                                                                <?php if (!empty($prod['usuario_foto'])): ?>
                                                                    <img src="uploads/<?php echo htmlspecialchars($prod['usuario_foto']); ?>" 
                                                                         class="rounded-circle mr-2" width="30" height="30" alt="Usuario">
                                                                <?php else: ?>
                                                                    <div class="rounded-circle bg-secondary text-white d-flex align-items-center justify-content-center mr-2" 
                                                                         style="width: 30px; height: 30px;">
                                                                        <?php echo strtoupper(substr($prod['usuario_nombre'], 0, 1)); ?>
                                                                    </div>
                                                                <?php endif; ?>
                                                                <h5 class="m-0"><?php echo htmlspecialchars($prod['usuario_nombre']); ?></h5>
                                                            </div>
                                                            
                                                            <div class="mt-2">
                                                                <strong>Registro de producción: <?php echo htmlspecialchars($prod['accion_realizada']); ?></strong>
                                                                
                                                                <div class="movimiento-detalle mt-2">
                                                                    <?php if (!empty($prod['insumo_nombre'])): ?>
                                                                    <div class="movimiento-campo">
                                                                        <span class="movimiento-etiqueta">Insumo:</span>
                                                                        <span class="movimiento-valor">
                                                                            <?php echo htmlspecialchars($prod['insumo_nombre']); ?>
                                                                        </span>
                                                                    </div>
                                                                    <?php endif; ?>
                                                                    
                                                                    <?php if (!empty($prod['cantidad_solicitada'])): ?>
                                                                    <div class="movimiento-campo">
                                                                        <span class="movimiento-etiqueta">Cantidad solicitada:</span>
                                                                        <span class="movimiento-valor">
                                                                            <?php echo htmlspecialchars($prod['cantidad_solicitada']); ?>
                                                                        </span>
                                                                    </div>
                                                                    <?php endif; ?>
                                                                    
                                                                    <?php if (!empty($prod['cantidad_realizada'])): ?>
                                                                    <div class="movimiento-campo">
                                                                        <span class="movimiento-etiqueta">Cantidad realizada:</span>
                                                                        <span class="movimiento-valor">
                                                                            <?php echo htmlspecialchars($prod['cantidad_realizada']); ?>
                                                                        </span>
                                                                    </div>
                                                                    <?php endif; ?>
                                                                    
                                                                    <?php if (!empty($prod['maquina_nombre'])): ?>
                                                                    <div class="movimiento-campo">
                                                                        <span class="movimiento-etiqueta">Máquina:</span>
                                                                        <span class="movimiento-valor">
                                                                            <?php echo htmlspecialchars($prod['maquina_nombre']); ?>
                                                                        </span>
                                                                    </div>
                                                                    <?php endif; ?>
                                                                    
                                                                    <?php if (!empty($prod['imagenes'])): 
                                                                        $imagenes = json_decode($prod['imagenes']); ?>
                                                                    <div class="movimiento-campo">
                                                                        <span class="movimiento-etiqueta">Imágenes:</span>
                                                                        <span class="movimiento-valor">
                                                                            <div class="d-flex flex-wrap">
                                                                                <?php foreach($imagenes as $img): ?>
                                                                                    <?php if (!empty($img)): ?>
                                                                                    <a href="uploads/<?= $img ?>" data-lightbox="produccion-<?= $prod['id_movimiento'] ?>" class="mr-2 mb-2">
                                                                                        <img src="uploads/<?= $img ?>" width="50" height="50" class="img-thumbnail">
                                                                                    </a>
                                                                                    <?php endif; ?>
                                                                                <?php endforeach; ?>
                                                                            </div>
                                                                        </span>
                                                                    </div>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php endwhile; ?>
                                                
                                                <?php foreach($movimientos_agrupados as $movimiento): ?>
                                                    <div class="timeline-event">
                                                        <div class="timeline-time">
                                                            <?php echo date('d/m H:i', strtotime($movimiento['fecha_registro'])); ?>
                                                        </div>
                                                        <div class="timeline-content">
                                                            <div class="d-flex align-items-center">
                                                                <?php if (!empty($movimiento['usuario_foto'])): ?>
                                                                    <img src="uploads/<?php echo htmlspecialchars($movimiento['usuario_foto']); ?>" 
                                                                         class="rounded-circle mr-2" width="30" height="30" alt="Usuario">
                                                                <?php else: ?>
                                                                    <div class="rounded-circle bg-secondary text-white d-flex align-items-center justify-content-center mr-2" 
                                                                         style="width: 30px; height: 30px;">
                                                                        <?php echo strtoupper(substr($movimiento['usuario_nombre'], 0, 1)); ?>
                                                                    </div>
                                                                <?php endif; ?>
                                                                <h5 class="m-0"><?php echo htmlspecialchars($movimiento['usuario_nombre']); ?></h5>
                                                            </div>
                                                            
                                                            <div class="mt-2">
                                                                <strong>
                                                                    Movimiento de inventario: 
                                                                    <?php 
                                                                        $tipo = ($movimiento['tipo'] == 'E') ? 'INGRESO' : 'EGRESO';
                                                                        $clase = ($movimiento['tipo'] == 'E') ? 'text-ingreso' : 'text-egreso';
                                                                    ?>
                                                                    <span class="<?= $clase ?>"><?= $tipo ?></span>
                                                                </strong>
                                                                
                                                                <?php if (!empty($movimiento['nota'])): ?>
                                                                    <div class="timeline-comment mt-1">
                                                                        <i class="fa fa-comment"></i> <?php echo htmlspecialchars($movimiento['nota']); ?>
                                                                    </div>
                                                                <?php endif; ?>
                                                                
                                                                <div class="movimiento-detalle">
                                                                    <div class="movimiento-campo">
                                                                        <span class="movimiento-etiqueta">ID Movimiento:</span>
                                                                        <span class="movimiento-valor">
                                                                            <?php echo $movimiento['id_mov_inventario']; ?>
                                                                        </span>
                                                                    </div>
                                                                    
                                                                    <div class="movimiento-campo">
                                                                        <span class="movimiento-etiqueta">Productos:</span>
                                                                        <span class="movimiento-valor">
                                                                            <ul>
                                                                                <?php foreach($movimiento['productos'] as $producto): ?>
                                                                                    <li>
                                                                                        <?php echo htmlspecialchars($producto['cantidad']); ?> 
                                                                                        unidades de <?php echo htmlspecialchars($producto['nombre']); ?>
                                                                                    </li>
                                                                                <?php endforeach; ?>
                                                                            </ul>
                                                                        </span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php endforeach; ?>
                                                
                                                <?php while($evento = $historial->fetch_assoc()): 
                                                    // Obtener productos solo si es necesario
                                                    $productos_entrega = [];
                                                    $productos_movimiento = [];
                                                    
                                                    if ($evento['id_entrega']) {
                                                        $productos_entrega = getProductosEntrega($conexion, $evento['id_entrega']);
                                                    }
                                                    
                                                    if ($evento['id_mov_inventario']) {
                                                        $productos_movimiento = getProductosMovimiento($conexion, $evento['id_mov_inventario']);
                                                    }
                                                ?>
                                                    <div class="timeline-event">
                                                        <div class="timeline-time">
                                                            <?php echo date('d/m H:i', strtotime($evento['at_time'])); ?>
                                                        </div>
                                                        <div class="timeline-content">
                                                            <div class="d-flex align-items-center">
                                                                <?php if (!empty($evento['foto'])): ?>
                                                                    <img src="uploads/<?php echo htmlspecialchars($evento['foto']); ?>" 
                                                                         class="rounded-circle mr-2" width="30" height="30" alt="Usuario">
                                                                <?php else: ?>
                                                                    <div class="rounded-circle bg-secondary text-white d-flex align-items-center justify-content-center mr-2" 
                                                                         style="width: 30px; height: 30px;">
                                                                        <?php echo strtoupper(substr($evento['usuario'], 0, 1)); ?>
                                                                    </div>
                                                                <?php endif; ?>
                                                                <h5 class="m-0"><?php echo htmlspecialchars($evento['usuario']); ?></h5>
                                                            </div>
                                                            
                                                            <div class="mt-2">
                                                                <strong class="text-<?php echo getEstadoColorClass($evento['estado']); ?>">
                                                                    <?php echo htmlspecialchars($evento['estado']); ?>
                                                                </strong>
                                                                
                                                                <?php if (!empty($evento['comentario'])): ?>
                                                                    <div class="timeline-comment mt-1">
                                                                        <i class="fa fa-comment"></i> <?php echo htmlspecialchars($evento['comentario']); ?>
                                                                    </div>
                                                                <?php endif; ?>
                                                                
                                                                <?php if (!empty($productos_entrega)): ?>
                                                                    <div class="timeline-detail mt-2">
                                                                        <div class="d-flex justify-content-between align-items-center">
                                                                            <div>
                                                                                <i class="fa fa-truck text-success"></i> 
                                                                                <strong>Entrega registrada</strong>
                                                                                <span class="badge badge-light"><?= count($productos_entrega) ?> productos</span>
                                                                            </div>
                                                                            <span class="collapse-toggle" data-target="entrega-<?= $evento['id_historial'] ?>">
                                                                                <i class="fa fa-chevron-down"></i> Ver detalles
                                                                            </span>
                                                                        </div>
                                                                        
                                                                        <div class="collapse-content" id="entrega-<?= $evento['id_historial'] ?>">
                                                                            <ul class="mt-2 mb-0 pl-3">
                                                                                <?php foreach($productos_entrega as $entrega): ?>
                                                                                    <li>
                                                                                        <?php echo htmlspecialchars($entrega['cantidad']); ?> 
                                                                                        unidades de <?php echo htmlspecialchars($entrega['nombre']); ?>
                                                                                    </li>
                                                                                <?php endforeach; ?>
                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                <?php endif; ?>
                                                                
                                                                <?php if (!empty($productos_movimiento)): ?>
                                                                    <div class="timeline-detail mt-2">
                                                                        <div class="d-flex justify-content-between align-items-center">
                                                                            <div>
                                                                                <i class="fa fa-exchange-alt text-info"></i> 
                                                                                <strong>Movimiento de inventario:</strong>
                                                                                <?php
                                                                                $tipo = ($evento['mov_tipo'] == 'E') ? 'ingreso' : 'egreso';
                                                                                $clase = ($evento['mov_tipo'] == 'E') ? 'text-ingreso' : 'text-egreso';
                                                                                ?>
                                                                                <span class="<?= $clase ?>"><?= strtoupper($tipo) ?></span>
                                                                                <span class="badge badge-light"><?= count($productos_movimiento) ?> productos</span>
                                                                            </div>
                                                                            <span class="collapse-toggle" data-target="movimiento-<?= $evento['id_historial'] ?>">
                                                                                <i class="fa fa-chevron-down"></i> Ver detalles
                                                                            </span>
                                                                        </div>
                                                                        
                                                                        <div class="collapse-content" id="movimiento-<?= $evento['id_historial'] ?>">
                                                                            <ul class="mt-2 mb-0 pl-3">
                                                                                <?php foreach($productos_movimiento as $mov): ?>
                                                                                    <li>
                                                                                        <?php echo htmlspecialchars($mov['cantidad']); ?> 
                                                                                        unidades de <?php echo htmlspecialchars($mov['nombre']); ?>
                                                                                    </li>
                                                                                <?php endforeach; ?>
                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php endwhile; ?>
                                            <?php else: ?>
                                                <div class="text-center py-4">
                                                    <i class="fa fa-inbox fa-2x text-muted mb-2"></i>
                                                    <p>No se encontraron movimientos para esta OP</p>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                
                                <?php if ($op['id_status'] != 5): // Si no está finalizada ?>
                                <div class="hr-line-dashed"></div>
                                
                                <div class="panel panel-warning">
                                    <div class="panel-heading">
                                        <i class="fa fa-plus-circle"></i> Agregar Acción
                                    </div>
                                    <div class="panel-body">
                                        <form method="POST" action="accion_op.php">
                                            <input type="hidden" name="id_solicitud" value="<?php echo $id_op; ?>">
                                            
                                            <div class="form-row">
                                                <div class="form-group col-md-4">
                                                    <label>Acción</label>
                                                    <select name="accion" class="form-control" required>
                                                        <option value="">Seleccionar acción...</option>
                                                        <?php if ($_SESSION['is_admin'] || $_SESSION['is_entregador']): ?>
                                                            <option value="aprobar">Aprobar OP</option>
                                                            <option value="rechazar">Rechazar OP</option>
                                                            <option value="entregar">Registrar entrega</option>
                                                            <option value="movimiento">Registrar movimiento</option>
                                                        <?php endif; ?>
                                                        <option value="comentario">Agregar comentario</option>
                                                    </select>
                                                </div>
                                                
                                                <div class="form-group col-md-8">
                                                    <label>Comentario</label>
                                                    <textarea name="comentario" class="form-control" rows="2"></textarea>
                                                </div>
                                            </div>
                                            
                                            <div class="text-right">
                                                <button type="submit" class="btn btn-primary">
                                                    <i class="fa fa-save"></i> Guardar Acción
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <?php footer(); ?>
        </div>
    </div>

    <?php scrips(); ?>

    <!-- Lightbox para imágenes -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>
    
    <script>
        $(document).ready(function() {
            // Inicializar tooltips
            $('[title]').tooltip();
            
            // Controlar visibilidad de campos según acción seleccionada
            $('select[name="accion"]').change(function() {
                var accion = $(this).val();
                if (accion === 'comentario') {
                    $('textarea[name="comentario"]').attr('required', true);
                } else {
                    $('textarea[name="comentario"]').removeAttr('required');
                }
            });
            
            // Toggle para mostrar/ocultar detalles
            $('.collapse-toggle').click(function() {
                const target = $(this).data('target');
                const $content = $('#' + target);
                const $icon = $(this).find('i');
                
                $content.toggleClass('show');
                
                if ($content.hasClass('show')) {
                    $icon.removeClass('fa-chevron-down').addClass('fa-chevron-up');
                    $(this).html('<i class="fa fa-chevron-up"></i> Ocultar detalles');
                } else {
                    $icon.removeClass('fa-chevron-up').addClass('fa-chevron-down');
                    $(this).html('<i class="fa fa-chevron-down"></i> Ver detalles');
                }
            });
        });
    </script>
</body>
</html>

<?php
// Funciones auxiliares
function getPrioridadClass($prioridad) {
    switch(strtolower($prioridad)) {
        case 'critica': return 'danger';
        case 'urgente': return 'warning';
        case 'normal': return 'primary';
        case 'tranquilo': return 'success';
        default: return 'secondary';
    }
}

function getEstadoColorClass($estado) {
    switch(strtolower($estado)) {
        case 'pendiente': return 'warning';
        case 'aprobado': return 'success';
        case 'rechazado': return 'danger';
        case 'en proceso': return 'info';
        case 'finalizado': return 'default';
        default: return 'primary';
    }
}