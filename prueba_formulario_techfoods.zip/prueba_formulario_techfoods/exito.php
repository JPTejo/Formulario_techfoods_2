<?php
session_start();
if (!isset($_SESSION['id_usuario'])) {
    header('Location: index.html');
    exit;
}

$id = $_GET['id'] ?? null;
$tipo = $_GET['tipo'] ?? '';

// Determinar la URL de redirección
$redirect_url = match($tipo) {
    'op' => "detalle_op.php?id=$id",
    default => 'home.php'
};

include("layout.php");
head('Operación Exitosa');
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Operación Exitosa</title>
    <style>
        .modal-backdrop {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1050;
        }
        
        .modal-content {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
            width: 400px;
            max-width: 90%;
            padding: 30px;
            text-align: center;
        }
        
        .success-icon {
            font-size: 60px;
            color: #28a745;
            margin-bottom: 20px;
        }
        
        .btn-continue {
            margin-top: 20px;
            background-color: #2c3e50;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
        }
        
        .btn-continue:hover {
            background-color: #1a252f;
        }
    </style>
</head>
<body>
    <div id="wrapper">
        <?php menu_lateral($_SESSION['id_usuario']); ?>
        
        <div id="page-wrapper" class="gray-bg">
            <?php barra_superior($_SESSION['id_usuario'], 'Operación Exitosa'); ?>
            
            <!-- Modal de Éxito -->
            <div class="modal-backdrop">
                <div class="modal-content">
                    <div class="success-icon">
                        <i class="fa fa-check-circle"></i>
                    </div>
                    <h3>¡Operación Exitosa!</h3>
                    <p>El formulario ha sido procesado correctamente.</p>
                    
                    <button class="btn-continue" onclick="redirigir()">
                        <i class="fa fa-arrow-right"></i> Ver Detalles
                    </button>
                    
                    <div class="mt-3 text-muted small">
                        Serás redirigido automáticamente en <span id="countdown">5</span> segundos
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php scrips(); ?>
    
    <script>
        // Redirección automática después de 5 segundos
        let seconds = 5;
        const countdownElement = document.getElementById('countdown');
        
        function updateCountdown() {
            countdownElement.textContent = seconds;
            seconds--;
            
            if (seconds < 0) {
                redirigir();
            } else {
                setTimeout(updateCountdown, 1000);
            }
        }
        
        function redirigir() {
            window.location.href = "<?= $redirect_url ?>";
        }
        
        // Iniciar cuenta regresiva
        setTimeout(updateCountdown, 1000);
    </script>
</body>
</html>