<?php
session_start();
include("conexion.php");

// Validación básica
if(empty($_POST['nro_op'])) {
    header("Location: planificacion.php?error=El número de OP es requerido");
    exit;
}

$nro_op = $_POST['nro_op'];

// Verificar si la OP ya existe
$sql = "SELECT id_solicitud FROM solicitud WHERE nro_op = ?";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("s", $nro_op);
$stmt->execute();
$result = $stmt->get_result();

if($result->num_rows > 0) {
    header("Location: planificacion.php?error=El número de OP ya existe");
    exit;
}

// 1. Guardar en tabla SOLICITUD (con nro_op)
$sql = "INSERT INTO solicitud (id_usuario, id_prioridad, id_status, nro_op, fecha_prevista, Observacion) 
        VALUES (?, ?, ?, ?, ?, ?)";
$stmt = $conexion->prepare($sql);
$stmt->bind_param(
    "iiisss", 
    $_POST['id_usuario'], 
    $_POST['id_prioridad'], 
    $_POST['id_status'], 
    $nro_op,
    $_POST['fecha_prevista'],
    $_POST['observacion']
);
$stmt->execute();
$id_solicitud = $conexion->insert_id;

// 2. Guardar detalles según acción
switch($accion) {
    case 'solicitar_insumos':
    case 'crear_solicitud':
        $id_insumo = $_POST['id_insumo'];
        $cantidad = $_POST['cantidad_solicitada'];
        
        $sql = "INSERT INTO solicitudes_detalles (id_solicitud, id_insumo, cantidad)
                VALUES (?, ?, ?)";
        $stmt = $conexion->prepare($sql);
        $stmt->bind_param("iii", $id_solicitud, $id_insumo, $cantidad);
        $stmt->execute();
        break;
        
    case 'registrar_entrega':
    case 'registrar_parcial':
        // Guardar en entregas y entregas_solicitud
        $sql = "INSERT INTO entregas (id_usuario, id_solicitud) 
                VALUES (?, ?)";
        $stmt = $conexion->prepare($sql);
        $stmt->bind_param("ii", $id_usuario, $id_solicitud);
        $stmt->execute();
        $id_entrega = $conexion->insert_id;
        
        $id_insumo = $_POST['id_insumo'];
        $cantidad = $_POST['cantidad_entregada'];
        $lote = $_POST['lote'];
        
        $sql = "INSERT INTO entregas_solicitud (id_entrega, id_insumo, cantidad, lote)
                VALUES (?, ?, ?, ?)";
        $stmt = $conexion->prepare($sql);
        $stmt->bind_param("iiis", $id_entrega, $id_insumo, $cantidad, $lote);
        $stmt->execute();
        break;
        
    case 'registrar_movimiento':
        // Guardar en mov_inventario y mov_inventario_detalles
        $tipo_mov = $_POST['tipo_mov'];
        $nota = $_POST['nota'];
        
        $sql = "INSERT INTO mov_inventario (id_usuario, tipo, nota) 
                VALUES (?, ?, ?)";
        $stmt = $conexion->prepare($sql);
        $stmt->bind_param("iss", $id_usuario, $tipo_mov, $nota);
        $stmt->execute();
        $id_mov = $conexion->insert_id;
        
        $id_insumo = $_POST['id_insumo'];
        $cantidad = $_POST['cantidad_solicitada'];
        
        $sql = "INSERT INTO mov_inventario_detalles (id_mov_inventario, id_insumo, cantidad)
                VALUES (?, ?, ?)";
        $stmt = $conexion->prepare($sql);
        $stmt->bind_param("iii", $id_mov, $id_insumo, $cantidad);
        $stmt->execute();
        break;
}

// 3. Guardar historial de estado
$sql = "INSERT INTO historial (id_solicitud, id_status_nuevo, id_usuario)
        VALUES (?, ?, ?)";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("iii", $id_solicitud, $id_status, $id_usuario);
$stmt->execute();

// 4. Guardar comentario si existe
if(!empty($_POST['observacion'])) {
    $comentario = $_POST['observacion'];
    $sql = "INSERT INTO comentario (contenido, id_usuario, id_solicitud)
            VALUES (?, ?, ?)";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("sii", $comentario, $id_usuario, $id_solicitud);
    $stmt->execute();
}

header("Location: planificacion.php?success=1");
exit;
?>