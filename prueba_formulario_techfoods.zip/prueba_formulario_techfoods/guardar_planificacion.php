<?php
session_start();
include("conexion.php");

if (!isset($_SESSION['id_usuario'])) {
    header('Location: index.html');
    exit;
}

// Validar fecha
$fechaRegistro = new DateTime($_POST['fecha_registro']);
$hoy = new DateTime('today');

if ($fechaRegistro < $hoy) {
    header('Location: planificacion.php?error=fecha_invalida');
    exit;
}

// Crear carpeta uploads si no existe
if (!file_exists('uploads')) {
    mkdir('uploads', 0777, true);
}

// Procesar imágenes
$imagenes = [];
if (!empty($_FILES['imagenes']['name'][0])) {
    foreach ($_FILES['imagenes']['tmp_name'] as $key => $tmp_name) {
        if ($_FILES['imagenes']['error'][$key] === UPLOAD_ERR_OK) {
            $nombre_imagen = uniqid() . '_' . basename($_FILES['imagenes']['name'][$key]);
            if (move_uploaded_file($tmp_name, "uploads/$nombre_imagen")) {
                $imagenes[] = $nombre_imagen;
            }
        }
    }
}

// Recoger datos - Convertir vacíos a null
$datos = [
    'id_usuario' => $_POST['id_usuario'],
    'nro_op' => $_POST['nro_op'],
    'fecha_registro' => $_POST['fecha_registro'],
    'accion_realizada' => $_POST['accion_rol'],
    'id_cliente' => !empty($_POST['id_cliente']) ? $_POST['id_cliente'] : null,
    'id_insumo' => !empty($_POST['id_insumo']) ? $_POST['id_insumo'] : null,
    'id_insumo_sustituto' => !empty($_POST['id_insumo_sustituto']) ? $_POST['id_insumo_sustituto'] : null,
    'id_producto' => !empty($_POST['id_producto']) ? $_POST['id_producto'] : null,
    'cantidad_solicitada' => !empty($_POST['cantidad_solicitada']) ? $_POST['cantidad_solicitada'] : null,
    'cantidad_entregada' => !empty($_POST['cantidad_entregada']) ? $_POST['cantidad_entregada'] : null,
    'cantidad_realizada' => !empty($_POST['cantidad_realizada']) ? $_POST['cantidad_realizada'] : null,
    'cantidad_merma' => !empty($_POST['cantidad_merma']) ? $_POST['cantidad_merma'] : null,
    'id_maquina' => !empty($_POST['id_maquina']) ? $_POST['id_maquina'] : null,
    'maquinas_utilizadas' => json_encode([
        $_POST['id_maquina1'] ?? null,
        $_POST['id_maquina2'] ?? null,
        $_POST['id_maquina3'] ?? null,
        $_POST['id_maquina4'] ?? null
    ]),
    'razon' => $_POST['razon'] ?? null,
    'entregado_a' => $_POST['entregado_a'] ?? null,
    'conformidad' => isset($_POST['conformidad']) ? (int)$_POST['conformidad'] : null,
    'observaciones' => $_POST['observacion'] ?? null,
    'imagenes' => !empty($imagenes) ? json_encode($imagenes) : null
];

// Construir consulta segura
$columnas = [];
$valores = [];
$tipos = '';
$params = [];

foreach ($datos as $columna => $valor) {
    $columnas[] = $columna;
    
    if ($valor === null) {
        $valores[] = "NULL";
    } else {
        $valores[] = "?";
        $params[] = $valor;
        $tipos .= 's'; // Todos como string
    }
}

$sql = "INSERT INTO op_movimientos (" . implode(', ', $columnas) . ") 
        VALUES (" . implode(', ', $valores) . ")";

// Ejecutar con consulta preparada
$stmt = $conexion->prepare($sql);
if ($stmt) {
    if (!empty($params)) {
        $stmt->bind_param($tipos, ...$params);
    }
    
    if ($stmt->execute()) {
        // Obtener el ID del movimiento recién insertado
        $id_movimiento = $stmt->insert_id;
        
        // Redirigir a la página de éxito
        header("Location: exito.php?id=$id_movimiento&tipo=op");
        exit;
    } else {
        error_log("Error al insertar: " . $stmt->error);
        header('Location: planificacion.php?error=1');
        exit;
    }
} else {
    error_log("Error en preparación: " . $conexion->error);
    header('Location: planificacion.php?error=1');
    exit;
}
?>