<?php
session_start();
include("conexion.php");

if (!isset($_SESSION['id_usuario'])) {
    header('Location: index.html');
    exit;
}

// Validar fecha en el servidor
$fechaRegistro = new DateTime($_POST['fecha_registro']);
$hoy = new DateTime('today');

if ($fechaRegistro < $hoy) {
    header('Location: planificacion.php?error=fecha_invalida');
    exit;
}

// Recoger datos del formulario
$datos = [
    'id_usuario' => $_POST['id_usuario'],
    'nro_op' => $_POST['nro_op'],
    'fecha_registro' => $_POST['fecha_registro'],
    'accion_realizada' => $_POST['accion_rol'],
    'id_cliente' => $_POST['id_cliente'] ?? null,
    'id_insumo' => $_POST['id_insumo'] ?? null,
    'id_insumo_sustituto' => $_POST['id_insumo_sustituto'] ?? null,
    'id_producto' => $_POST['id_producto'] ?? null,
    'cantidad_solicitada' => $_POST['cantidad_solicitada'] ?? null,
    'cantidad_entregada' => $_POST['cantidad_entregada'] ?? null,
    'cantidad_realizada' => $_POST['cantidad_realizada'] ?? null,
    'cantidad_merma' => $_POST['cantidad_merma'] ?? null,
    'id_maquina' => $_POST['id_maquina'] ?? null,
    'maquinas_utilizadas' => json_encode([
        $_POST['id_maquina1'] ?? null,
        $_POST['id_maquina2'] ?? null,
        $_POST['id_maquina3'] ?? null,
        $_POST['id_maquina4'] ?? null
    ]),
    'razon' => $_POST['razon'] ?? null,
    'entregado_a' => $_POST['entregado_a'] ?? null,
    'conformidad' => $_POST['conformidad'] ?? null,
    'observaciones' => $_POST['observacion'] ?? null
];

// Procesar imágenes
$imagenes = [];
if (!empty($_FILES['imagenes']['name'][0])) {
    foreach ($_FILES['imagenes']['tmp_name'] as $key => $tmp_name) {
        if ($_FILES['imagenes']['error'][$key] === UPLOAD_ERR_OK) {
            $nombre_imagen = uniqid() . '_' . basename($_FILES['imagenes']['name'][$key]);
            move_uploaded_file($tmp_name, "uploads/$nombre_imagen");
            $imagenes[] = $nombre_imagen;
        }
    }
}
$datos['imagenes'] = json_encode($imagenes);

// Insertar en base de datos
$columnas = implode(', ', array_keys($datos));
$valores = "'" . implode("', '", array_values($datos)) . "'";
$sql = "INSERT INTO op_movimientos ($columnas) VALUES ($valores)";

if ($conexion->query($sql)) {
    header('Location: planificacion.php?success=1');
} else {
    header('Location: planificacion.php?error=1');
}
exit;
?>