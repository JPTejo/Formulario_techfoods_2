<?php
	//error_reporting(0);
	session_start();
	include("layout.php");
	$pagina="Planificación";
	head($pagina);
	include("conexion.php");
	
	if (!isset($_SESSION['id_usuario'])) {
        header('Location: index.html');
        exit;
    }

	$id = $_SESSION['id_usuario'];
	$conexion = new mysqli($host_db, $user_db, $pass_db, $db_name);
	
	// Obtener información del usuario
	$sql = "SELECT * FROM usuarios WHERE id_usuario = $id";
	$result = $conexion->query($sql);
	
	if ($result->num_rows > 0) {  
		$row = $result->fetch_array(MYSQLI_ASSOC);
		$cargo = $row['cargo'];
		$nombre_usuario = $row['nombre'];
		
		// Determinar rol basado en los permisos
		if ($row['is_admin']) {
			$rol = 'Administrador';
		} elseif ($row['is_solicitador']) {
			$rol = 'Solicitador';
		} elseif ($row['is_entregador']) {
			$rol = 'Entregador';
		} else {
			$rol = 'Usuario';
		}

		// Obtener insumos (materias primas)
		$insumos = $conexion->query("SELECT id_insumo, nombre FROM insumos WHERE status = 1");
		$insumos_array = [];
		while ($insumo = $insumos->fetch_assoc()) {
			$insumos_array[$insumo['id_insumo']] = $insumo['nombre'];
		}

		// Obtener prioridades
		$prioridades = $conexion->query("SELECT id_prioridad, nombre FROM prioridad");
		$prioridades_array = [];
		while ($prioridad = $prioridades->fetch_assoc()) {
			$prioridades_array[$prioridad['id_prioridad']] = $prioridad['nombre'];
		}

		// Obtener estados
		$estados = $conexion->query("SELECT id_status, nombre FROM status");
		$estados_array = [];
		while ($estado = $estados->fetch_assoc()) {
			$estados_array[$estado['id_status']] = $estado['nombre'];
		}

		// Acciones disponibles según el rol
		$accionesPorRol = [
			'Administrador' => [
				'crear_solicitud' => 'Crear nueva solicitud',
				'modificar_solicitud' => 'Modificar solicitud existente',
				'aprobar_solicitud' => 'Aprobar solicitud',
				'generar_inventario' => 'Generar reporte de inventario'
			],
			'Solicitador' => [
				'solicitar_insumos' => 'Solicitar insumos',
				'seguimiento_solicitud' => 'Seguimiento de solicitudes',
				'modificar_solicitud' => 'Modificar mis solicitudes'
			],
			'Entregador' => [
				'registrar_entrega' => 'Registrar entrega de insumos',
				'registrar_parcial' => 'Registrar entrega parcial',
				'actualizar_inventario' => 'Actualizar inventario',
				'registrar_movimiento' => 'Registrar movimiento de inventario'
			]
		];
		
		$acciones = $accionesPorRol[$rol] ?? [];
		?>

		<div id="wrapper">
			<?php menu_lateral($id); ?>
			<div id="page-wrapper" class="gray-bg">
				<?php barra_superior($id, $pagina); ?>
				
				<div class="row wrapper border-bottom white-bg page-heading">
					<div class="col-lg-10">
						<h2>Planificación</h2>
						<ol class="breadcrumb">
							<li class="breadcrumb-item">
								<a href="home.php">Inicio</a>
							</li>
							<li class="breadcrumb-item active">
								<strong>Planificación</strong>
							</li>
						</ol>
					</div>
				</div>

				<div class="wrapper wrapper-content animated fadeInRight">
					<div class="row">
						<div class="col-lg-12">
							<div class="ibox">
								<div class="ibox-title">
									<h5>Formulario de Planificación</h5>
									<div class="ibox-tools">
										<a class="collapse-link">
											<i class="fa fa-chevron-up"></i>
										</a>
									</div>
								</div>
								<div class="ibox-content">
									<div class="alert alert-info">
										<i class="fa fa-info-circle"></i> Usuario: <strong><?php echo $nombre_usuario; ?></strong> 
										| Cargo: <strong><?php echo $cargo; ?></strong> 
										| Rol: <strong><?php echo $rol; ?></strong>
									</div>
									
									<form id="formularioPlanificacion" method="POST" action="guardar_planificacion.php" enctype="multipart/form-data">
										<input type="hidden" name="usuario_id" value="<?php echo $id; ?>">
										<input type="hidden" name="tipo_movimiento" id="tipo_movimiento" value="">
										
										<div class="row">
											<div class="col-md-6">
												<div class="form-group">
													<label>Número de Solicitud *</label>
													<input type="text" name="numero_solicitud" class="form-control" required>
												</div>
												
												<div class="form-group">
													<label>Acción a realizar *</label>
													<select id="accion_rol" name="accion_rol" class="form-control" required onchange="mostrarCamposPorAccion()">
														<option value="">-- Seleccionar acción --</option>
														<?php foreach ($acciones as $value => $text): ?>
															<option value="<?php echo $value; ?>"><?php echo $text; ?></option>
														<?php endforeach; ?>
													</select>
												</div>
												
												<div class="form-group">
													<label>Prioridad *</label>
													<select name="id_prioridad" class="form-control" required>
														<?php foreach ($prioridades_array as $id_pri => $nombre_pri): ?>
															<option value="<?php echo $id_pri; ?>"><?php echo $nombre_pri; ?></option>
														<?php endforeach; ?>
													</select>
												</div>
												
												<div class="form-group">
													<label>Estado *</label>
													<select name="id_status" class="form-control" required>
														<?php foreach ($estados_array as $id_est => $nombre_est): ?>
															<option value="<?php echo $id_est; ?>"><?php echo $nombre_est; ?></option>
														<?php endforeach; ?>
													</select>
												</div>
												
												<div id="observacion_container" class="form-group">
													<label>Observaciones</label>
													<textarea name="observacion" class="form-control" rows="3"></textarea>
												</div>
												
												<div id="fecha_prevista_container" class="form-group">
													<label>Fecha Prevista</label>
													<input type="datetime-local" name="fecha_prevista" class="form-control">
												</div>
											</div>
											
											<div class="col-md-6">
												<div id="insumo_container" class="form-group">
													<label>Seleccionar Insumo</label>
													<select name="id_insumo" class="form-control">
														<option value="">-- Seleccionar insumo --</option>
														<?php foreach ($insumos_array as $id_ins => $nombre_ins): ?>
															<option value="<?php echo $id_ins; ?>"><?php echo $nombre_ins; ?></option>
														<?php endforeach; ?>
													</select>
												</div>
												
												<div id="cantidad_solicitada_container" class="form-group">
													<label>Cantidad Solicitada</label>
													<input type="number" name="cantidad_solicitada" class="form-control">
												</div>
												
												<div id="cantidad_entregada_container" class="form-group">
													<label>Cantidad Entregada</label>
													<input type="number" name="cantidad_entregada" class="form-control">
												</div>
												
												<div id="lote_container" class="form-group">
													<label>Lote</label>
													<input type="text" name="lote" class="form-control">
												</div>
												
												<div id="clave_container" class="form-group">
													<label>Clave</label>
													<input type="text" name="clave" class="form-control">
												</div>
												
												<div id="tipo_mov_container" class="form-group">
													<label>Tipo de Movimiento</label>
													<select name="tipo_mov" class="form-control">
														<option value="E">Entrada</option>
														<option value="S">Salida</option>
													</select>
												</div>
												
												<div id="nota_container" class="form-group">
													<label>Nota</label>
													<textarea name="nota" class="form-control" rows="3"></textarea>
												</div>
												
												<div id="doc_container" class="form-group">
													<label>Documento</label>
													<input type="text" name="doc" class="form-control">
												</div>
												
												<div id="imagenes_container" class="form-group">
													<label>Imágenes</label>
													<input type="file" name="imagenes[]" multiple class="form-control">
												</div>
											</div>
										</div>
										
										<div class="text-center mt-4">
											<button type="submit" class="btn btn-primary btn-lg">
												<i class="fa fa-save"></i> Guardar Planificación
											</button>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>

				<?php footer(); ?>
			</div>
		</div>
		
		<script>
			// Función para mostrar/ocultar campos según la acción seleccionada
			function mostrarCamposPorAccion() {
				const accion = document.getElementById('accion_rol').value;
				
				// Ocultar todos los campos opcionales primero
				const camposOpcionales = [
					'observacion_container', 'fecha_prevista_container', 'insumo_container',
					'cantidad_solicitada_container', 'cantidad_entregada_container', 'lote_container',
					'clave_container', 'tipo_mov_container', 'nota_container', 'doc_container',
					'imagenes_container'
				];
				
				camposOpcionales.forEach(id => {
					document.getElementById(id).style.display = 'none';
				});
				
				// Mostrar campos específicos según la acción seleccionada
				switch(accion) {
					case 'crear_solicitud':
					case 'modificar_solicitud':
						['observacion_container', 'fecha_prevista_container', 'insumo_container', 
						 'cantidad_solicitada_container', 'imagenes_container'].forEach(id => {
							document.getElementById(id).style.display = 'block';
						});
						break;
						
					case 'solicitar_insumos':
						['insumo_container', 'cantidad_solicitada_container', 'observacion_container',
						 'fecha_prevista_container', 'imagenes_container'].forEach(id => {
							document.getElementById(id).style.display = 'block';
						});
						break;
						
					case 'registrar_entrega':
					case 'registrar_parcial':
						['insumo_container', 'cantidad_entregada_container', 'lote_container', 
						 'clave_container', 'doc_container', 'imagenes_container'].forEach(id => {
							document.getElementById(id).style.display = 'block';
						});
						break;
						
					case 'registrar_movimiento':
						['tipo_mov_container', 'insumo_container', 'cantidad_solicitada_container', 
						 'doc_container', 'nota_container', 'imagenes_container'].forEach(id => {
							document.getElementById(id).style.display = 'block';
						});
						break;
						
					case 'actualizar_inventario':
						['insumo_container', 'cantidad_solicitada_container', 'lote_container', 
						 'clave_container', 'imagenes_container'].forEach(id => {
							document.getElementById(id).style.display = 'block';
						});
						break;
						
					case 'aprobar_solicitud':
						['observacion_container', 'imagenes_container'].forEach(id => {
							document.getElementById(id).style.display = 'block';
						});
						break;
				}
				
				// Establecer tipo de movimiento para acciones específicas
				if (accion === 'registrar_movimiento') {
					document.getElementById('tipo_movimiento').value = 'movimiento';
				} else if (accion === 'actualizar_inventario') {
					document.getElementById('tipo_movimiento').value = 'inventario';
				} else {
					document.getElementById('tipo_movimiento').value = 'solicitud';
				}
			}
			
			// Inicializar el formulario ocultando todos los campos opcionales
			document.addEventListener('DOMContentLoaded', function() {
				mostrarCamposPorAccion();
			});
		</script>
		
		<?php						   
	} else {
		header('Location: index.html');
		exit;
	}
	
	scrips();
?>
</body>
</html>