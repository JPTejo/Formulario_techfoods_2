<?php
//error_reporting(0);
session_start();
include("layout.php");
$pagina="Planificación";
head($pagina);
include("conexion.php");

if (!isset($_SESSION['id_usuario'])) {
    header('Location: index.html');
    exit;
}

$id = $_SESSION['id_usuario'];
$conexion = new mysqli($host_db, $user_db, $pass_db, $db_name);

// Obtener información del usuario
$sql = "SELECT * FROM usuarios WHERE id_usuario = $id";
$result = $conexion->query($sql);

if ($result->num_rows > 0) {  
    $row = $result->fetch_array(MYSQLI_ASSOC);
    $cargo = $row['cargo'];
    $nombre_usuario = $row['nombre'];
    $es_ti = ($cargo == 'TI'); // Verificar si es de TI
    
    // Definir todas las acciones posibles
    $todas_acciones = [
        // Planificación
        'modificar_pedido_mp' => 'Modificación de pedido MP',
        
        // jefe de bodega
        'recepcion_material_terminado' => 'Recepción de material terminado',
        'solicitud_cambio_mp' => 'Solicitud de cambio de materia prima',
        'entrega_mp' => 'Entrega de materia prima',
        
        // Lider
        'recepcion_mp' => 'Recepción materia prima',
        'entrada_proceso' => 'Entrada a proceso',
        'salida_proceso' => 'Salida de proceso',
        
        // Supervisor
        'conformidad_producto' => 'Conformidad de producto',
        
        // control de calidad
        'control_producto' => 'Control de producto',
        
        // DESPACHO
        'despacho' => 'Despacho',
        
        // control de gestion
        'aprobacion_op' => 'Aprobación de OP'
    ];

    // Definir acciones disponibles para cada cargo
    $acciones = [];
    if ($es_ti) {
        // TI tiene acceso a todo
        $acciones = $todas_acciones;
    } else {
        switch ($cargo) {
            case 'Planificacion':
                $acciones = ['modificar_pedido_mp' => 'Modificación de pedido MP'];
                break;
            case 'jefe de bodega':
                $acciones = [
                    'recepcion_material_terminado' => 'Recepción de material terminado',
                    'solicitud_cambio_mp' => 'Solicitud de cambio de materia prima',
                    'entrega_mp' => 'Entrega de materia prima'
                ];
                break;
            case 'Lider':
                $acciones = [
                    'recepcion_mp' => 'Recepción materia prima',
                    'entrada_proceso' => 'Entrada a proceso',
                    'salida_proceso' => 'Salida de proceso'
                ];
                break;
            case 'Supervisor':
                $acciones = [
                    'recepcion_mp' => 'Recepción materia prima',
                    'entrada_proceso' => 'Entrada a proceso',
                    'salida_proceso' => 'Salida de proceso',
                    'conformidad_producto' => 'Conformidad de producto'
                ];
                break;
            case 'control de calidad':
                $acciones = ['control_producto' => 'Control de producto'];
                break;
            case 'DESPACHO':
                $acciones = ['despacho' => 'Despacho'];
                break;
            case 'control de gestion':
                $acciones = ['aprobacion_op' => 'Aprobación de OP'];
                break;
            default:
                $acciones = [];
        }
    }

    // Obtener insumos (materias primas)
    $insumos = $conexion->query("SELECT id_insumo, nombre FROM insumos WHERE status = 1");
    $insumos_array = [];
    while ($insumo = $insumos->fetch_assoc()) {
        $insumos_array[$insumo['id_insumo']] = $insumo['nombre'];
    }

    // Obtener máquinas
    $maquinas = $conexion->query("SELECT id_maquina, nombre FROM maquinas");
    $maquinas_array = [];
    while ($maquina = $maquinas->fetch_assoc()) {
        $maquinas_array[$maquina['id_maquina']] = $maquina['nombre'];
    }

    // Obtener clientes
    $clientes = $conexion->query("SELECT id_cliente, nombre FROM clientes");
    $clientes_array = [];
    while ($cliente = $clientes->fetch_assoc()) {
        $clientes_array[$cliente['id_cliente']] = $cliente['nombre'];
    }

    // Obtener productos
    $productos = $conexion->query("SELECT id_producto, nombre FROM productos");
    $productos_array = [];
    while ($producto = $productos->fetch_assoc()) {
        $productos_array[$producto['id_producto']] = $producto['nombre'];
    }
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Planificación</title>
    <style>
        /* Estilos responsivos adicionales */
        @media (max-width: 767px) {
            .alert-info span {
                display: block;
                margin-bottom: 5px;
            }
            .alert-info .badge {
                margin-top: 10px;
            }
            .ibox-title h5 {
                font-size: 16px;
            }
            .form-group label {
                font-size: 14px;
            }
            .btn-lg {
                padding: 8px 16px;
                font-size: 14px;
            }
            #wrapper {
                padding-top: 50px;
            }
            .btn-block-xs {
                display: block;
                width: 100%;
            }
        }
        @media (min-width: 768px) and (max-width: 991px) {
            .col-md-6 {
                width: 100%;
            }
            .form-group {
                margin-bottom: 15px;
            }
        }
        /* Mejorar visualización de campos en móviles */
        select.form-control, 
        input.form-control, 
        textarea.form-control {
            font-size: 14px;
            padding: 8px 12px;
        }
        /* Estilo para el campo de fecha */
        input[type="date"] {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div id="wrapper">
        <?php menu_lateral($id); ?>
        <div id="page-wrapper" class="gray-bg">
            <?php barra_superior($id, $pagina); ?>
            
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10 col-md-12">
                    <h2>Planificación</h2>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="home.php">Inicio</a>
                        </li>
                        <li class="breadcrumb-item active">
                            <strong>Planificación</strong>
                        </li>
                    </ol>
                </div>
            </div>

            <!-- Formulario de planificación -->
            <div class="wrapper wrapper-content animated fadeInRight">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="ibox">
                            <div class="ibox-title">
                                <h5>Formulario de Planificación</h5>
                                <div class="ibox-tools">
                                </div>
                            </div>
                            <div class="ibox-content">
                                <div class="alert alert-info">
                                    <div class="d-flex flex-wrap">
                                        <span class="mr-3"><i class="fa fa-info-circle"></i> Usuario: <strong><?php echo $nombre_usuario; ?></strong></span>
                                        <span class="mr-3">Cargo: <strong><?php echo $cargo; ?></strong></span>
                                        <?php if ($es_ti): ?>
                                            <span class="badge badge-danger">ACCESO TOTAL (TI)</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <form id="formularioPlanificacion" method="POST" action="guardar_planificacion.php" enctype="multipart/form-data">
                                    <input type="hidden" name="id_usuario" value="<?php echo $id; ?>">
                                    
                                    <div class="row">
                                        <!-- Columna izquierda -->
                                        <div class="col-md-6 col-sm-12">
                                            <div class="form-group">
                                                <label>Número de OP *</label>
                                                <input type="text" name="nro_op" class="form-control" required>
                                            </div>
                                            
                                            <div class="form-group">
                                                <label>Fecha del Registro *</label>
                                                <input type="date" name="fecha_registro" id="fecha_registro" class="form-control" required>
                                            </div>
                                            
                                            <div class="form-group">
                                                <label>Acción a realizar *</label>
                                                <select id="accion_rol" name="accion_rol" class="form-control" required onchange="mostrarCamposPorAccion()">
                                                    <option value="">-- Seleccionar acción --</option>
                                                    <?php foreach ($acciones as $value => $text): ?>
                                                        <option value="<?php echo $value; ?>"><?php echo $text; ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                            
                                            <div id="cliente_container" class="form-group">
                                                <label>Cliente</label>
                                                <select name="id_cliente" class="form-control">
                                                    <option value="">-- Seleccionar cliente --</option>
                                                    <?php foreach ($clientes_array as $id_cli => $nombre_cli): ?>
                                                        <option value="<?php echo $id_cli; ?>"><?php echo $nombre_cli; ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                            
                                            <div id="insumo_container" class="form-group">
                                                <label>Materia Prima</label>
                                                <select name="id_insumo" class="form-control">
                                                    <option value="">-- Seleccionar materia prima --</option>
                                                    <?php foreach ($insumos_array as $id_ins => $nombre_ins): ?>
                                                        <option value="<?php echo $id_ins; ?>"><?php echo $nombre_ins; ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                            
                                            <div id="insumo_sustituto_container" class="form-group">
                                                <label>Materia Prima Sustituta</label>
                                                <select name="id_insumo_sustituto" class="form-control">
                                                    <option value="">-- Seleccionar materia prima sustituta --</option>
                                                    <?php foreach ($insumos_array as $id_ins => $nombre_ins): ?>
                                                        <option value="<?php echo $id_ins; ?>"><?php echo $nombre_ins; ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                            
                                            <div id="producto_container" class="form-group">
                                                <label>Producto</label>
                                                <select name="id_producto" class="form-control">
                                                    <option value="">-- Seleccionar producto --</option>
                                                    <?php foreach ($productos_array as $id_prod => $nombre_prod): ?>
                                                        <option value="<?php echo $id_prod; ?>"><?php echo $nombre_prod; ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                            
                                            <div id="cantidad_solicitada_container" class="form-group">
                                                <label>Cantidad Programada</label>
                                                <input type="number" step="0.01" name="cantidad_solicitada" class="form-control">
                                            </div>
                                            
                                            <div id="cantidad_entregada_container" class="form-group">
                                                <label>Cantidad Entregada</label>
                                                <input type="number" step="0.01" name="cantidad_entregada" class="form-control">
                                            </div>
                                            
                                            <div id="cantidad_realizada_container" class="form-group">
                                                <label>Cantidad Realizada</label>
                                                <input type="number" step="0.01" name="cantidad_realizada" class="form-control">
                                            </div>
                                            
                                            <div id="cantidad_merma_container" class="form-group">
                                                <label>Cantidad de Merma</label>
                                                <input type="number" step="0.01" name="cantidad_merma" class="form-control">
                                            </div>
                                            
                                            <div id="razon_container" class="form-group">
                                                <label>Razón - Solicitud cambio de Materia Prima</label>
                                                <textarea name="razon" class="form-control" rows="3"></textarea>
                                            </div>
                                            
                                            <div id="entregado_a_container" class="form-group">
                                                <label>Entregado a - Entrega de Materia Prima</label>
                                                <input type="text" name="entregado_a" class="form-control">
                                            </div>
                                        </div>
                                        
                                        <!-- Columna derecha -->
                                        <div class="col-md-6 col-sm-12">
                                            <div id="maquina_container" class="form-group">
                                                <label>Máquina Utilizada</label>
                                                <select name="id_maquina" class="form-control">
                                                    <option value="">-- Seleccionar máquina --</option>
                                                    <?php foreach ($maquinas_array as $id_maq => $nombre_maq): ?>
                                                        <option value="<?php echo $id_maq; ?>"><?php echo $nombre_maq; ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                            
                                            <div id="maquinas_multiple_container" class="form-group">
                                                <label>Máquinas Utilizadas</label>
                                                <select name="id_maquina1" class="form-control mb-2">
                                                    <option value="">-- Máquina 1 --</option>
                                                    <?php foreach ($maquinas_array as $id_maq => $nombre_maq): ?>
                                                        <option value="<?php echo $id_maq; ?>"><?php echo $nombre_maq; ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                                <select name="id_maquina2" class="form-control mb-2">
                                                    <option value="">-- Máquina 2 --</option>
                                                    <?php foreach ($maquinas_array as $id_maq => $nombre_maq): ?>
                                                        <option value="<?php echo $id_maq; ?>"><?php echo $nombre_maq; ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                                <select name="id_maquina3" class="form-control mb-2">
                                                    <option value="">-- Máquina 3 --</option>
                                                    <?php foreach ($maquinas_array as $id_maq => $nombre_maq): ?>
                                                        <option value="<?php echo $id_maq; ?>"><?php echo $nombre_maq; ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                                <select name="id_maquina4" class="form-control">
                                                    <option value="">-- Máquina 4 --</option>
                                                    <?php foreach ($maquinas_array as $id_maq => $nombre_maq): ?>
                                                        <option value="<?php echo $id_maq; ?>"><?php echo $nombre_maq; ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                            
                                            <div id="conformidad_container" class="form-group">
                                                <label>Conformidad</label>
                                                <select name="conformidad" class="form-control">
                                                    <option value="1">Sí</option>
                                                    <option value="0">No</option>
                                                </select>
                                            </div>
                                            
                                            <div id="observacion_container" class="form-group">
                                                <label>Comentarios adicionales</label>
                                                <textarea name="observacion" class="form-control" rows="3"></textarea>
                                            </div>
                                            
                                            <div id="imagenes_container" class="form-group">
                                                <label>Imágenes</label>
                                                <input type="file" name="imagenes[]" multiple class="form-control">
                                                <small class="form-text text-muted">Formatos permitidos: JPG, PNG, GIF (Máx. 5MB por archivo)</small>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="text-center mt-4">
                                        <button type="submit" class="btn btn-primary btn-lg btn-block-xs">
                                            <i class="fa fa-save"></i> Guardar Planificación
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php footer(); ?>
        </div>
    </div>
    
    <script>
        // Función para mostrar/ocultar campos según la acción seleccionada
        function mostrarCamposPorAccion() {
            const accion = document.getElementById('accion_rol').value;
            
            // Ocultar todos los campos opcionales primero
            const camposOpcionales = [
                'cliente_container', 'insumo_container', 'insumo_sustituto_container',
                'producto_container', 'cantidad_solicitada_container', 'cantidad_entregada_container',
                'cantidad_realizada_container', 'cantidad_merma_container', 'razon_container',
                'entregado_a_container', 'maquina_container', 'maquinas_multiple_container',
                'conformidad_container', 'observacion_container', 'imagenes_container'
            ];
            
            camposOpcionales.forEach(id => {
                document.getElementById(id).style.display = 'none';
            });
            
            // Mostrar campos específicos según la acción seleccionada
            switch(accion) {
                // Planificacion
                case 'modificar_pedido_mp':
                    ['insumo_sustituto_container', 'cantidad_solicitada_container', 
                     'imagenes_container', 'observacion_container'].forEach(id => {
                        document.getElementById(id).style.display = 'block';
                    });
                    break;
                    
                // jefe de bodega
                case 'recepcion_material_terminado':
                    ['cliente_container', 'insumo_container', 'cantidad_realizada_container', 
                     'imagenes_container', 'observacion_container'].forEach(id => {
                        document.getElementById(id).style.display = 'block';
                    });
                    break;
                    
                case 'solicitud_cambio_mp':
                    ['cliente_container', 'insumo_sustituto_container', 'cantidad_solicitada_container', 
                     'razon_container', 'imagenes_container', 'observacion_container'].forEach(id => {
                        document.getElementById(id).style.display = 'block';
                    });
                    break;
                    
                case 'entrega_mp':
                    ['insumo_container', 'cantidad_entregada_container', 'entregado_a_container', 
                     'imagenes_container', 'observacion_container'].forEach(id => {
                        document.getElementById(id).style.display = 'block';
                    });
                    break;
                    
                // Lider
                case 'recepcion_mp':
                    ['insumo_container', 'cantidad_entregada_container', 
                     'imagenes_container', 'observacion_container'].forEach(id => {
                        document.getElementById(id).style.display = 'block';
                    });
                    break;
                    
                case 'entrada_proceso':
                    ['maquina_container', 'imagenes_container', 'observacion_container'].forEach(id => {
                        document.getElementById(id).style.display = 'block';
                    });
                    break;
                    
                case 'salida_proceso':
                    ['insumo_container', 'cantidad_realizada_container', 'cantidad_merma_container', 
                     'maquina_container', 'imagenes_container', 'observacion_container'].forEach(id => {
                        document.getElementById(id).style.display = 'block';
                    });
                    break;
                    
                // Supervisor
                case 'conformidad_producto':
                    ['cliente_container', 'insumo_container', 'cantidad_realizada_container', 
                     'maquina_container', 'conformidad_container', 'imagenes_container', 'observacion_container'].forEach(id => {
                        document.getElementById(id).style.display = 'block';
                    });
                    break;
                    
                // control de calidad
                case 'control_producto':
                    ['cliente_container', 'insumo_container', 'cantidad_realizada_container', 
                     'conformidad_container', 'imagenes_container', 'observacion_container'].forEach(id => {
                        document.getElementById(id).style.display = 'block';
                    });
                    break;
                    
                // DESPACHO
                case 'despacho':
                    ['cliente_container', 'producto_container', 'insumo_container', 
                     'cantidad_realizada_container', 'imagenes_container', 'observacion_container'].forEach(id => {
                        document.getElementById(id).style.display = 'block';
                    });
                    break;
                    
                // control de gestion
                case 'aprobacion_op':
                    ['cliente_container', 'producto_container', 'insumo_container', 
                     'cantidad_solicitada_container', 'cantidad_realizada_container', 'cantidad_merma_container', 
                     'maquinas_multiple_container', 'conformidad_container', 'imagenes_container', 'observacion_container'].forEach(id => {
                        document.getElementById(id).style.display = 'block';
                    });
                    break;
            }
        }
        
        // Configuración inicial de la fecha
        document.addEventListener('DOMContentLoaded', function() {
            // Establecer fecha actual como valor por defecto
            const today = new Date().toISOString().split('T')[0];
            document.getElementById('fecha_registro').value = today;
            
            // Configurar fecha mínima como hoy
            document.getElementById('fecha_registro').min = today;
            
            // Inicializar campos según acción
            mostrarCamposPorAccion();
            
            // Validar fecha al enviar el formulario
            document.getElementById('formularioPlanificacion').addEventListener('submit', function(e) {
                const fechaInput = document.getElementById('fecha_registro');
                const selectedDate = new Date(fechaInput.value);
                const currentDate = new Date();
                currentDate.setHours(0, 0, 0, 0);
                
                if (selectedDate < currentDate) {
                    e.preventDefault();
                    alert('Error: No se puede seleccionar una fecha anterior al día actual');
                    fechaInput.focus();
                }
            });
            
            // También validar cuando cambia la fecha
            document.getElementById('fecha_registro').addEventListener('change', function() {
                const selectedDate = new Date(this.value);
                const currentDate = new Date();
                currentDate.setHours(0, 0, 0, 0);
                
                if (selectedDate < currentDate) {
                    alert('Error: No se puede seleccionar una fecha pasada');
                    this.value = today;
                }
            });
        });
    </script>
    
    <?php
    } else {
        header('Location: index.html');
        exit;
    }
    
    scrips();
    ?>
</body>
</html>