<?php
//error_reporting(0);
session_start();
include("layout.php");
$pagina="Planificación";
head($pagina);
include("conexion.php");

if (!isset($_SESSION['id_usuario'])) {
    header('Location: index.html');
    exit;
}

$id = $_SESSION['id_usuario'];
$conexion = new mysqli($host_db, $user_db, $pass_db, $db_name);

// Obtener información del usuario
$sql = "SELECT * FROM usuarios WHERE id_usuario = $id";
$result = $conexion->query($sql);

if ($result->num_rows > 0) {  
    $row = $result->fetch_array(MYSQLI_ASSOC);
    $cargo = $row['cargo'];
    $nombre_usuario = $row['nombre'];
    $es_ti = ($cargo == 'TI'); // Verificar si es de TI
    
    // Definir todas las acciones posibles
    $todas_acciones = [
        // Planificación
        'modificar_pedido_mp' => 'Modificación de pedido MP',
        
        // jefe de bodega
        'recepcion_material_terminado' => 'Recepción de material terminado',
        'solicitud_cambio_mp' => 'Solicitud de cambio de materia prima',
        'entrega_mp' => 'Entrega de materia prima',
        
        // Lider
        'recepcion_mp' => 'Recepción materia prima',
        'entrada_proceso' => 'Entrada a proceso',
        'salida_proceso' => 'Salida de proceso',
        
        // Supervisor
        'conformidad_producto' => 'Conformidad de producto',
        
        // control de calidad
        'control_producto' => 'Control de producto',
        
        // DESPACHO
        'despacho' => 'Despacho',
        
        // control de gestion
        'aprobacion_op' => 'Aprobación de OP',

        // operador
        'entrada_proceso' => 'Entrada a proceso',
        'salida_proceso' => 'Salida de proceso',
    ];

    // Definir acciones disponibles para cada cargo
    $acciones = [];
    if ($es_ti) {
        // TI tiene acceso a todo
        $acciones = $todas_acciones;
    } else {
        switch ($cargo) {
            case 'planificacion':
                $acciones = ['modificar_pedido_mp' => 'Modificación de pedido MP'];
                break;
            case 'bodega':
                $acciones = [
                    'recepcion_material_terminado' => 'Recepción de material terminado',
                    'solicitud_cambio_mp' => 'Solicitud de cambio de materia prima',
                    'entrega_mp' => 'Entrega de materia prima'
                ];
                break;
            case 'lider':
                $acciones = [
                    'recepcion_mp' => 'Recepción materia prima',
                    'entrada_proceso' => 'Entrada a proceso',
                    'salida_proceso' => 'Salida de proceso'
                ];
                break;
            case 'supervisor':
                $acciones = [
                    'recepcion_mp' => 'Recepción materia prima',
                    'entrada_proceso' => 'Entrada a proceso',
                    'salida_proceso' => 'Salida de proceso',
                    'conformidad_producto' => 'Conformidad de producto'
                ];
                break;
            case 'operador':
                $acciones = [
                    'entrada_proceso' => 'Entrada a proceso',
                    'salida_proceso' => 'Salida de proceso'
                ];
                break;
            case 'control de calidad':
                $acciones = ['control_producto' => 'Control de producto'];
                break;
            case 'despacho':
                $acciones = ['despacho' => 'Despacho'];
                break;
            case 'control de gestion':
                $acciones = ['aprobacion_op' => 'Aprobación de OP'];
                break;
            default:
                $acciones = [];
        }
    }

    // Obtener insumos (materias primas)
    $insumos = $conexion->query("SELECT id_insumo, nombre FROM insumos WHERE status = 1");
    $insumos_array = [];
    while ($insumo = $insumos->fetch_assoc()) {
        $insumos_array[$insumo['id_insumo']] = $insumo['nombre'];
    }

    // Obtener máquinas
    $maquinas = $conexion->query("SELECT id_maquina, nombre FROM maquinas");
    $maquinas_array = [];
    while ($maquina = $maquinas->fetch_assoc()) {
        $maquinas_array[$maquina['id_maquina']] = $maquina['nombre'];
    }

    // Obtener clientes
    $clientes = $conexion->query("SELECT id_cliente, nombre FROM clientes");
    $clientes_array = [];
    while ($cliente = $clientes->fetch_assoc()) {
        $clientes_array[$cliente['id_cliente']] = $cliente['nombre'];
    }

    // Obtener productos
    $productos = $conexion->query("SELECT id_producto, nombre FROM productos");
    $productos_array = [];
    while ($producto = $productos->fetch_assoc()) {
        $productos_array[$producto['id_producto']] = $producto['nombre'];
    }
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Planificación</title>
    <style>
        /* Estilos responsivos adicionales */
        @media (max-width: 767px) {
            .alert-info span {
                display: block;
                margin-bottom: 5px;
            }
            .alert-info .badge {
                margin-top: 10px;
            }
            .ibox-title h5 {
                font-size: 16px;
            }
            .form-group label {
                font-size: 14px;
            }
            .btn-lg {
                padding: 8px 16px;
                font-size: 14px;
            }
            #wrapper {
                padding-top: 50px;
            }
            .btn-block-xs {
                display: block;
                width: 100%;
            }
        }
        @media (min-width: 768px) and (max-width: 991px) {
            .col-md-6 {
                width: 100%;
            }
            .form-group {
                margin-bottom: 15px;
            }
        }
        /* Mejorar visualización de campos en móviles */
        select.form-control, 
        input.form-control, 
        textarea.form-control {
            font-size: 14px;
            padding: 8px 12px;
        }
        /* Estilo para el campo de fecha */
        input[type="date"] {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
        /* Agregar estilo para mensaje de error */
        .error-message {
            color: #ff0000;
            font-size: 0.85em;
            margin-top: 5px;
            display: none;
        }
        .maquina-info {
            background-color: #f8f9fa;
            border-radius: 4px;
            padding: 8px;
            margin-top: 5px;
            font-size: 14px;
        }
        /* Estilos para el campo de búsqueda */
        .search-container {
            position: relative;
        }
        .search-results {
            position: absolute;
            z-index: 1000;
            width: 100%;
            max-height: 200px;
            overflow-y: auto;
            background-color: white;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: none;
        }
        .search-result-item {
            padding: 8px 12px;
            cursor: pointer;
            border-bottom: 1px solid #eee;
        }
        .search-result-item:hover {
            background-color: #f5f5f5;
        }
        .search-result-item:last-child {
            border-bottom: none;
        }
        .insumo-selected {
            background-color: #e6f7ff;
            border: 1px solid #91d5ff;
            border-radius: 4px;
            padding: 5px;
            margin-top: 5px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .remove-insumo {
            cursor: pointer;
            color: #ff4d4f;
        }
    </style>
</head>
<body>
    <div id="wrapper">
        <?php menu_lateral($id); ?>
        <div id="page-wrapper" class="gray-bg">
            <?php barra_superior($id, $pagina); ?>
            
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10 col-md-12">
                    <h2>Planificación</h2>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="home.php">Inicio</a>
                        </li>
                        <li class="breadcrumb-item active">
                            <strong>Planificación</strong>
                        </li>
                    </ol>
                </div>
            </div>

            <!-- Formulario de planificación -->
            <div class="wrapper wrapper-content animated fadeInRight">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="ibox">
                            <div class="ibox-title">
                                <h5>Formulario de Planificación</h5>
                                <div class="ibox-tools">
                                </div>
                            </div>
                            <div class="ibox-content">
                                <div class="alert alert-info">
                                    <div class="d-flex flex-wrap">
                                        <span class="mr-3"><i class="fa fa-info-circle"></i> Usuario: <strong><?php echo $nombre_usuario; ?></strong></span>
                                        <span class="mr-3">Cargo: <strong><?php echo $cargo; ?></strong></span>
                                        <?php if ($es_ti): ?>
                                            <span class="badge badge-danger">ACCESO TOTAL (TI)</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <form id="formularioPlanificacion" method="POST" action="guardar_planificacion.php" enctype="multipart/form-data">
                                    <input type="hidden" name="id_usuario" value="<?php echo $id; ?>">
                                    <input type="hidden" id="id_maquina_actual" name="id_maquina_actual" value="">
                                    
                                    <div class="row">
                                        <!-- Columna izquierda -->
                                        <div class="col-md-6 col-sm-12">
                                            <div class="form-group">
                                                <label>Número de OP *</label>
                                                <input type="text" name="nro_op" id="nro_op" class="form-control" required>
                                                <div id="op-error" class="error-message">El número de OP no existe</div>
                                            </div>
                                            
                                            <div class="form-group">
                                                <label>Fecha del Registro *</label>
                                                <input type="date" name="fecha_registro" id="fecha_registro" class="form-control" required>
                                            </div>
                                            
                                            <div class="form-group">
                                                <label>Acción a realizar *</label>
                                                <select id="accion_rol" name="accion_rol" class="form-control" required onchange="mostrarCamposPorAccion()">
                                                    <option value="">-- Seleccionar acción --</option>
                                                    <?php foreach ($acciones as $value => $text): ?>
                                                        <option value="<?php echo $value; ?>"><?php echo $text; ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                            
                                            <div id="cliente_container" class="form-group">
                                                <label>Cliente</label>
                                                <input type="text" id="cliente_nombre" class="form-control" readonly>
                                                <input type="hidden" name="id_cliente" id="id_cliente">
                                            </div>
                                            
                                            <div id="insumo_container" class="form-group">
                                                <label>Materia Prima</label>
                                                <div class="search-container">
                                                    <input type="text" id="buscar_insumo" class="form-control" 
                                                           placeholder="Escriba para buscar o seleccione de la lista">
                                                    <div id="resultados_insumo" class="search-results"></div>
                                                </div>
                                                
                                                <!-- Campo oculto para almacenar el ID del insumo seleccionado -->
                                                <input type="hidden" name="id_insumo" id="id_insumo" value="">
                                                
                                                <!-- Área para mostrar los insumos seleccionados -->
                                                <div id="insumos_seleccionados" class="mt-2"></div>
                                            </div>
                                            
                                            <div id="insumo_sustituto_container" class="form-group">
                                                <label>Materia Prima Sustituta</label>
                                                <div class="search-container">
                                                    <input type="text" id="buscar_insumo_sustituto" class="form-control" 
                                                           placeholder="Escriba para buscar o seleccione de la lista">
                                                    <div id="resultados_insumo_sustituto" class="search-results"></div>
                                                </div>
                                                
                                                <!-- Campo oculto para almacenar el ID del insumo sustituto seleccionado -->
                                                <input type="hidden" name="id_insumo_sustituto" id="id_insumo_sustituto" value="">
                                                
                                                <!-- Área para mostrar los insumos sustitutos seleccionados -->
                                                <div id="insumos_sustitutos_seleccionados" class="mt-2"></div>
                                            </div>
                                            
                                            <div id="producto_container" class="form-group">
                                                <label>Producto</label>
                                                <select name="id_producto" class="form-control">
                                                    <option value="">-- Seleccionar producto --</option>
                                                    <?php foreach ($productos_array as $id_prod => $nombre_prod): ?>
                                                        <option value="<?php echo $id_prod; ?>"><?php echo $nombre_prod; ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                            
                                            <div id="cantidad_solicitada_container" class="form-group">
                                                <label>Cantidad Programada</label>
                                                <input type="number" step="0.01" name="cantidad_solicitada" class="form-control">
                                            </div>
                                            
                                            <div id="cantidad_entregada_container" class="form-group">
                                                <label>Cantidad Entregada</label>
                                                <input type="number" step="0.01" name="cantidad_entregada" class="form-control">
                                            </div>
                                            
                                            <div id="cantidad_realizada_container" class="form-group">
                                                <label>Cantidad Realizada</label>
                                                <input type="number" step="0.01" name="cantidad_realizada" class="form-control">
                                            </div>
                                            
                                            <div id="cantidad_merma_container" class="form-group">
                                                <label>Cantidad de Merma</label>
                                                <input type="number" step="0.01" name="cantidad_merma" class="form-control">
                                            </div>
                                            
                                            <div id="razon_container" class="form-group">
                                                <label>Razón - Solicitud cambio de Materia Prima</label>
                                                <textarea name="razon" class="form-control" rows="3"></textarea>
                                            </div>
                                            
                                            <div id="entregado_a_container" class="form-group">
                                                <label>Entregado a - Entrega de Materia Prima</label>
                                                <input type="text" name="entregado_a" class="form-control">
                                            </div>
                                        </div>
                                        
                                        <!-- Columna derecha -->
                                        <div class="col-md-6 col-sm-12">
                                            <div id="maquina_container" class="form-group">
                                                <label>Máquina Utilizada</label>
                                                <select name="id_maquina" id="id_maquina" class="form-control">
                                                    <option value="">-- Seleccionar máquina --</option>
                                                    <?php foreach ($maquinas_array as $id_maq => $nombre_maq): ?>
                                                        <option value="<?php echo $id_maq; ?>"><?php echo $nombre_maq; ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                                <div id="maquina-info" class="maquina-info" style="display:none;">
                                                    Máquina asignada automáticamente para esta OP
                                                </div>
                                            </div>
                                            
                                            <div id="maquinas_multiple_container" class="form-group">
                                                <label>Máquinas Utilizadas</label>
                                                <select name="id_maquina1" class="form-control mb-2">
                                                    <option value="">-- Máquina 1 --</option>
                                                    <?php foreach ($maquinas_array as $id_maq => $nombre_maq): ?>
                                                        <option value="<?php echo $id_maq; ?>"><?php echo $nombre_maq; ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                                <select name="id_maquina2" class="form-control mb-2">
                                                    <option value="">-- Máquina 2 --</option>
                                                    <?php foreach ($maquinas_array as $id_maq => $nombre_maq): ?>
                                                        <option value="<?php echo $id_maq; ?>"><?php echo $nombre_maq; ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                                <select name="id_maquina3" class="form-control mb-2">
                                                    <option value="">-- Máquina 3 --</option>
                                                    <?php foreach ($maquinas_array as $id_maq => $nombre_maq): ?>
                                                        <option value="<?php echo $id_maq; ?>"><?php echo $nombre_maq; ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                                <select name="id_maquina4" class="form-control">
                                                    <option value="">-- Máquina 4 --</option>
                                                    <?php foreach ($maquinas_array as $id_maq => $nombre_maq): ?>
                                                        <option value="<?php echo $id_maq; ?>"><?php echo $nombre_maq; ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                            
                                            <div id="conformidad_container" class="form-group">
                                                <label>Conformidad</label>
                                                <select name="conformidad" class="form-control">
                                                    <option value="1">Sí</option>
                                                    <option value="0">No</option>
                                                </select>
                                            </div>
                                            
                                            <div id="observacion_container" class="form-group">
                                                <label>Comentarios adicionales</label>
                                                <textarea name="observacion" class="form-control" rows="3"></textarea>
                                            </div>
                                            
                                            <div id="imagenes_container" class="form-group">
                                                <label>Imágenes</label>
                                                <input type="file" name="imagenes[]" multiple class="form-control">
                                                <small class="form-text text-muted">Formatos permitidos: JPG, PNG, GIF (Máx. 5MB por archivo)</small>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="text-center mt-4">
                                        <button type="submit" id="btnGuardar" class="btn btn-primary btn-lg btn-block-xs" disabled>
                                            <i class="fa fa-save"></i> Guardar Planificación
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php footer(); ?>
        </div>
    </div>
    
    <script>
        // Función para mostrar/ocultar campos según la acción seleccionada
        function mostrarCamposPorAccion() {
            const accion = document.getElementById('accion_rol').value;
            
            // Ocultar todos los campos opcionales primero
            const camposOpcionales = [
                'cliente_container', 'insumo_container', 'insumo_sustituto_container',
                'producto_container', 'cantidad_solicitada_container', 'cantidad_entregada_container',
                'cantidad_realizada_container', 'cantidad_merma_container', 'razon_container',
                'entregado_a_container', 'maquina_container', 'maquinas_multiple_container',
                'conformidad_container', 'observacion_container', 'imagenes_container'
            ];
            
            camposOpcionales.forEach(id => {
                document.getElementById(id).style.display = 'none';
            });
            
            // Mostrar campos específicos según la acción seleccionada
            switch(accion) {
                // Planificacion
                case 'modificar_pedido_mp':
                    ['insumo_sustituto_container', 'cantidad_solicitada_container', 
                     'imagenes_container', 'observacion_container'].forEach(id => {
                        document.getElementById(id).style.display = 'block';
                    });
                    break;
                    
                // jefe de bodega
                case 'recepcion_material_terminado':
                    ['cliente_container', 'insumo_container', 'cantidad_realizada_container', 
                     'imagenes_container', 'observacion_container'].forEach(id => {
                        document.getElementById(id).style.display = 'block';
                    });
                    break;
                    
                case 'solicitud_cambio_mp':
                    ['cliente_container', 'insumo_sustituto_container', 'cantidad_solicitada_container', 
                     'razon_container', 'imagenes_container', 'observacion_container'].forEach(id => {
                        document.getElementById(id).style.display = 'block';
                    });
                    break;
                    
                case 'entrega_mp':
                    ['insumo_container', 'cantidad_entregada_container', 'entregado_a_container', 
                     'imagenes_container', 'observacion_container'].forEach(id => {
                        document.getElementById(id).style.display = 'block';
                    });
                    break;
                    
                // Lider
                case 'recepcion_mp':
                    ['insumo_container', 'cantidad_entregada_container', 
                     'imagenes_container', 'observacion_container'].forEach(id => {
                        document.getElementById(id).style.display = 'block';
                    });
                    break;
                    
                case 'entrada_proceso':
                    ['maquina_container', 'imagenes_container', 'observacion_container'].forEach(id => {
                        document.getElementById(id).style.display = 'block';
                    });
                    break;
                    
                case 'salida_proceso':
                    ['insumo_container', 'cantidad_realizada_container', 'cantidad_merma_container', 
                     'maquina_container', 'imagenes_container', 'observacion_container'].forEach(id => {
                        document.getElementById(id).style.display = 'block';
                    });
                    
                    // Autocompletar máquina si existe una asignada
                    const idMaquina = document.getElementById('id_maquina_actual').value;
                    const selectMaquina = document.getElementById('id_maquina');
                    const maquinaInfo = document.getElementById('maquina-info');
                    
                    if (idMaquina) {
                        selectMaquina.value = idMaquina;
                        selectMaquina.disabled = true;
                        maquinaInfo.style.display = 'block';
                    } else {
                        selectMaquina.disabled = false;
                        maquinaInfo.style.display = 'none';
                    }
                    break;
                    
                // Supervisor
                case 'conformidad_producto':
                    ['cliente_container', 'insumo_container', 'cantidad_realizada_container', 
                     'maquina_container', 'conformidad_container', 'imagenes_container', 'observacion_container'].forEach(id => {
                        document.getElementById(id).style.display = 'block';
                    });
                    break;
                    
                // control de calidad
                case 'control_producto':
                    ['cliente_container', 'insumo_container', 'cantidad_realizada_container', 
                     'conformidad_container', 'imagenes_container', 'observacion_container'].forEach(id => {
                        document.getElementById(id).style.display = 'block';
                    });
                    break;
                    
                // DESPACHO
                case 'despacho':
                    ['cliente_container', 'producto_container', 'insumo_container', 
                     'cantidad_realizada_container', 'imagenes_container', 'observacion_container'].forEach(id => {
                        document.getElementById(id).style.display = 'block';
                    });
                    break;
                    
                // control de gestion
                case 'aprobacion_op':
                    ['cliente_container', 'producto_container', 'insumo_container', 
                     'cantidad_solicitada_container', 'cantidad_realizada_container', 'cantidad_merma_container', 
                     'maquinas_multiple_container', 'conformidad_container', 'imagenes_container', 'observacion_container'].forEach(id => {
                        document.getElementById(id).style.display = 'block';
                    });
                    break;
            }
        }
        
        // Función para verificar la existencia de la OP
        function verificarOP() {
            const nroOp = document.getElementById('nro_op').value;
            const errorDiv = document.getElementById('op-error');
            const btnGuardar = document.getElementById('btnGuardar');
            const clienteNombre = document.getElementById('cliente_nombre');
            const idCliente = document.getElementById('id_cliente');
            const idMaquinaActual = document.getElementById('id_maquina_actual');
            const selectMaquina = document.getElementById('id_maquina');
            const maquinaInfo = document.getElementById('maquina-info');
            
            if (!nroOp) {
                errorDiv.style.display = 'none';
                btnGuardar.disabled = true;
                clienteNombre.value = '';
                idCliente.value = '';
                idMaquinaActual.value = '';
                selectMaquina.disabled = false;
                maquinaInfo.style.display = 'none';
                return;
            }
            
            // Realizar petición AJAX
            const xhr = new XMLHttpRequest();
            xhr.open('POST', 'verificar_op.php', true);
            xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            
            xhr.onload = function() {
                try {
                    const respuesta = JSON.parse(this.responseText);
                    
                    if (respuesta.error) {
                        errorDiv.textContent = 'Error: ' + respuesta.error;
                        errorDiv.style.display = 'block';
                        btnGuardar.disabled = true;
                        return;
                    }
                    
                    if (respuesta.existe) {
                        errorDiv.style.display = 'none';
                        
                        // Cliente
                        if (respuesta.nombre_cliente) {
                            clienteNombre.value = respuesta.nombre_cliente;
                            idCliente.value = respuesta.id_cliente;
                        } else {
                            clienteNombre.value = 'Cliente no asignado';
                            idCliente.value = '';
                        }
                        
                        // Máquina actual
                        if (respuesta.id_maquina) {
                            idMaquinaActual.value = respuesta.id_maquina;
                        } else {
                            idMaquinaActual.value = '';
                        }
                        
                        btnGuardar.disabled = false;
                        
                        // Actualizar campos según acción seleccionada
                        mostrarCamposPorAccion();
                    } else {
                        errorDiv.textContent = 'El número de OP no existe';
                        errorDiv.style.display = 'block';
                        clienteNombre.value = '';
                        idCliente.value = '';
                        idMaquinaActual.value = '';
                        btnGuardar.disabled = true;
                    }
                } catch (e) {
                    console.error('Error parsing JSON:', e, 'Response:', this.responseText);
                    errorDiv.textContent = 'Error en formato de respuesta';
                    errorDiv.style.display = 'block';
                    btnGuardar.disabled = true;
                }
            };
            
            xhr.onerror = function() {
                console.error('Error de conexión');
                errorDiv.textContent = 'Error de conexión con el servidor';
                errorDiv.style.display = 'block';
                btnGuardar.disabled = true;
            };
            
            xhr.send('nro_op=' + encodeURIComponent(nroOp));
        }
        
        // Función para buscar insumos mientras se escribe
        function buscarInsumos(termino, campoResultados, tipo) {
            const resultados = document.getElementById(campoResultados);
            resultados.innerHTML = '';
            
            if (termino.length < 2) {
                resultados.style.display = 'none';
                return;
            }
            
            // Filtrar insumos que coincidan con el término de búsqueda
            const insumosFiltrados = Object.entries(<?php echo json_encode($insumos_array); ?>)
                .filter(([id, nombre]) => 
                    nombre.toLowerCase().includes(termino.toLowerCase())
                );
            
            if (insumosFiltrados.length > 0) {
                insumosFiltrados.forEach(([id, nombre]) => {
                    const item = document.createElement('div');
                    item.className = 'search-result-item';
                    item.textContent = nombre;
                    item.dataset.id = id;
                    item.dataset.nombre = nombre;
                    
                    item.addEventListener('click', function() {
                        agregarInsumo(id, nombre, tipo);
                        document.getElementById('buscar_insumo').value = '';
                        resultados.style.display = 'none';
                    });
                    
                    resultados.appendChild(item);
                });
                resultados.style.display = 'block';
            } else {
                resultados.style.display = 'none';
            }
        }
        
        // Función para agregar un insumo seleccionado
        function agregarInsumo(id, nombre, tipo) {
            const campoId = tipo === 'insumo' ? 'id_insumo' : 'id_insumo_sustituto';
            const campoSeleccionados = tipo === 'insumo' ? 'insumos_seleccionados' : 'insumos_sustitutos_seleccionados';
            const campoBusqueda = tipo === 'insumo' ? 'buscar_insumo' : 'buscar_insumo_sustituto';
            
            // Limpiar selección previa
            document.getElementById(campoSeleccionados).innerHTML = '';
            document.getElementById(campoId).value = id;
            
            // Crear elemento para mostrar el insumo seleccionado
            const div = document.createElement('div');
            div.className = 'insumo-selected';
            div.innerHTML = `
                <span>${nombre}</span>
                <span class="remove-insumo" onclick="eliminarInsumo('${tipo}')">
                    <i class="fa fa-times"></i> Quitar
                </span>
            `;
            
            document.getElementById(campoSeleccionados).appendChild(div);
            document.getElementById(campoBusqueda).value = '';
        }
        
        // Función para eliminar la selección de insumo
        function eliminarInsumo(tipo) {
            const campoId = tipo === 'insumo' ? 'id_insumo' : 'id_insumo_sustituto';
            const campoSeleccionados = tipo === 'insumo' ? 'insumos_seleccionados' : 'insumos_sustitutos_seleccionados';
            const campoBusqueda = tipo === 'insumo' ? 'buscar_insumo' : 'buscar_insumo_sustituto';
            
            document.getElementById(campoSeleccionados).innerHTML = '';
            document.getElementById(campoId).value = '';
            document.getElementById(campoBusqueda).value = '';
        }
        
        // Configuración inicial
        document.addEventListener('DOMContentLoaded', function() {
            // Establecer fecha actual como valor por defecto
            const today = new Date().toISOString().split('T')[0];
            const fechaInput = document.getElementById('fecha_registro');
            fechaInput.value = today;
            
            // Configurar fecha máxima como hoy (solo fechas pasadas y hoy)
            fechaInput.max = today;
            
            // Inicializar campos según acción
            mostrarCamposPorAccion();
            
            // Validar fecha al enviar el formulario
            document.getElementById('formularioPlanificacion').addEventListener('submit', function(e) {
                const fechaInput = document.getElementById('fecha_registro');
                const selectedDate = new Date(fechaInput.value);
                const currentDate = new Date();
                currentDate.setHours(0, 0, 0, 0);
                
                if (selectedDate > currentDate) {
                    e.preventDefault();
                    alert('Error: No se puede seleccionar una fecha futura');
                    fechaInput.focus();
                }
            });
            
            // También validar cuando cambia la fecha
            document.getElementById('fecha_registro').addEventListener('change', function() {
                const selectedDate = new Date(this.value);
                const currentDate = new Date();
                currentDate.setHours(0, 0, 0, 0);
                
                if (selectedDate > currentDate) {
                    alert('Error: No se puede seleccionar una fecha futura');
                    this.value = today;
                }
            });
            
            // Agregar evento al campo OP
            document.getElementById('nro_op').addEventListener('blur', verificarOP);
            document.getElementById('nro_op').addEventListener('input', function() {
                if (!this.value) {
                    document.getElementById('btnGuardar').disabled = true;
                    document.getElementById('op-error').style.display = 'none';
                    document.getElementById('cliente_nombre').value = '';
                    document.getElementById('id_cliente').value = '';
                    document.getElementById('id_maquina_actual').value = '';
                    document.getElementById('id_maquina').disabled = false;
                    document.getElementById('maquina-info').style.display = 'none';
                }
            });
            
            // Evento para el campo de búsqueda de materia prima
            document.getElementById('buscar_insumo').addEventListener('input', function() {
                buscarInsumos(this.value, 'resultados_insumo', 'insumo');
            });
            
            // Evento para el campo de búsqueda de materia prima sustituta
            document.getElementById('buscar_insumo_sustituto').addEventListener('input', function() {
                buscarInsumos(this.value, 'resultados_insumo_sustituto', 'sustituto');
            });
            
            // Evento para cerrar los resultados al hacer clic fuera
            document.addEventListener('click', function(e) {
                if (!e.target.closest('.search-container')) {
                    document.getElementById('resultados_insumo').style.display = 'none';
                    document.getElementById('resultados_insumo_sustituto').style.display = 'none';
                }
            });
        });
    </script>
    
    <?php
    } else {
        header('Location: index.html');
        exit;
    }
    
    scrips();
    ?>
</body>
</html>