<?php
	//error_reporting(0);
	session_start();
	include("layout.php");
	$pagina="Planificación";
	head($pagina);
	include("conexion.php");
	
	if (!isset($_SESSION['id_usuario'])) {
        header('Location: index.html');
        exit;
    }

	$id = $_SESSION['id_usuario'];
	$conexion = new mysqli($host_db, $user_db, $pass_db, $db_name);
	
	// Obtener información del usuario
	$sql = "SELECT * FROM usuarios WHERE id_usuario = $id";
	$result = $conexion->query($sql);
	
	if ($result->num_rows > 0) {  
		$row = $result->fetch_array(MYSQLI_ASSOC);
		$cargo = $row['cargo'];
		$nombre_usuario = $row['nombre'];
		
		// Determinar rol basado en los permisos
		if ($row['is_admin']) {
			$rol = 'Administrador';
		} elseif ($row['is_solicitador']) {
			$rol = 'Solicitador';
		} elseif ($row['is_entregador']) {
			$rol = 'Entregador';
		} else {
			$rol = 'Usuario';
		}

		// Obtener insumos (materias primas)
		$insumos = $conexion->query("SELECT id_insumo, nombre FROM insumos WHERE status = 1");
		$insumos_array = [];
		while ($insumo = $insumos->fetch_assoc()) {
			$insumos_array[$insumo['id_insumo']] = $insumo['nombre'];
		}

		// Obtener prioridades
		$prioridades = $conexion->query("SELECT id_prioridad, nombre FROM prioridad");
		$prioridades_array = [];
		while ($prioridad = $prioridades->fetch_assoc()) {
			$prioridades_array[$prioridad['id_prioridad']] = $prioridad['nombre'];
		}

		// Obtener estados
		$estados = $conexion->query("SELECT id_status, nombre FROM status");
		$estados_array = [];
		while ($estado = $estados->fetch_assoc()) {
			$estados_array[$estado['id_status']] = $estado['nombre'];
		}

		// Definir acciones disponibles para cada rol
		$accionesSolicitador = [
			'solicitar_insumos' => 'Solicitar insumos',
			'seguimiento_solicitud' => 'Seguimiento de solicitudes',
			'modificar_solicitud' => 'Modificar mis solicitudes'
		];
		
		$accionesEntregador = [
			'registrar_entrega' => 'Registrar entrega de insumos',
			'registrar_parcial' => 'Registrar entrega parcial',
			'actualizar_inventario' => 'Actualizar inventario',
			'registrar_movimiento' => 'Registrar movimiento de inventario'
		];
		
		$accionesAdministrador = [
			'crear_solicitud' => 'Crear nueva solicitud',
			'modificar_solicitud' => 'Modificar solicitud existente',
			'aprobar_solicitud' => 'Aprobar solicitud',
			'generar_inventario' => 'Generar reporte de inventario'
		];
		
		// Combinar todas las acciones para el administrador
		if ($rol === 'Administrador') {
			$acciones = array_merge($accionesSolicitador, $accionesEntregador, $accionesAdministrador);
		} elseif ($rol === 'Solicitador') {
			$acciones = $accionesSolicitador;
		} elseif ($rol === 'Entregador') {
			$acciones = $accionesEntregador;
		} else {
			$acciones = [];
		}
		?>

		<!-- Añadir meta viewport para responsive -->
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
		
		<style>
			/* Estilos responsivos adicionales */
			@media (max-width: 767px) {
				.alert-info span {
					display: block;
					margin-bottom: 5px;
				}
				.alert-info .badge {
					margin-top: 10px;
				}
				.ibox-title h5 {
					font-size: 16px;
				}
				.form-group label {
					font-size: 14px;
				}
				.btn-lg {
					padding: 8px 16px;
					font-size: 14px;
				}
				#wrapper {
					padding-top: 50px;
				}
			}
			@media (max-width: 767px) {
    .btn-block-xs {
        display: block;
        width: 100%;
    }
}
			@media (min-width: 768px) and (max-width: 991px) {
				/* Estilos para tablets */
				.col-md-6 {
					width: 100%;
				}
				.form-group {
					margin-bottom: 15px;
				}
			}
			/* Mejorar visualización de campos en móviles */
			select.form-control, 
			input.form-control, 
			textarea.form-control {
				font-size: 14px;
				padding: 8px 12px;
			}
		</style>
		
		<div id="wrapper">
			<?php menu_lateral($id); ?>
			<div id="page-wrapper" class="gray-bg">
				<?php barra_superior($id, $pagina); ?>
				
				<div class="row wrapper border-bottom white-bg page-heading">
					<div class="col-lg-10 col-md-12">
						<h2>Planificación</h2>
						<ol class="breadcrumb">
							<li class="breadcrumb-item">
								<a href="home.php">Inicio</a>
							</li>
							<li class="breadcrumb-item active">
								<strong>Planificación</strong>
							</li>
						</ol>
					</div>
				</div>


				
				<div class="wrapper wrapper-content animated fadeInRight">
					<div class="row">
						<div class="col-lg-12">
							<div class="ibox">
								<div class="ibox-title">
									<h5>Formulario de Planificación</h5>
									<div class="ibox-tools">
									</div>
								</div>
								<div class="ibox-content">
									<div class="alert alert-info">
										<div class="d-flex flex-wrap">
											<span class="mr-3"><i class="fa fa-info-circle"></i> Usuario: <strong><?php echo $nombre_usuario; ?></strong></span>
											<span class="mr-3">Cargo: <strong><?php echo $cargo; ?></strong></span>
											<span class="mr-3">Rol: <strong><?php echo $rol; ?></strong></span>
											<?php if ($rol === 'Administrador'): ?>
												<span class="badge badge-success">Acceso Total</span>
											<?php endif; ?>
										</div>
									</div>
									
									<form id="formularioPlanificacion" method="POST" action="guardar_planificacion.php" enctype="multipart/form-data">
										<input type="hidden" name="id_usuario" value="<?php echo $id; ?>">
										<input type="text" name="nro_op" class="form-control" required>
										<input type="hidden" name="tipo_movimiento" id="tipo_movimiento" value="">
										
										<div class="row">
											<!-- Columna izquierda - ajustada para responsividad -->
											<div class="col-md-6 col-sm-12">
												<div class="form-group">
													<label>Número de Solicitud *</label>
													<input type="text" name="numero_solicitud" class="form-control" required>
												</div>
												
												<div class="form-group">
													<label>Acción a realizar *</label>
													<select id="accion_rol" name="accion_rol" class="form-control" required onchange="mostrarCamposPorAccion()">
														<option value="">-- Seleccionar acción --</option>
														<?php foreach ($acciones as $value => $text): ?>
															<option value="<?php echo $value; ?>"><?php echo $text; ?></option>
														<?php endforeach; ?>
													</select>
												</div>
												
												<div class="form-group">
													<label>Prioridad *</label>
													<select name="id_prioridad" class="form-control" required>
														<?php foreach ($prioridades_array as $id_pri => $nombre_pri): ?>
															<option value="<?php echo $id_pri; ?>"><?php echo $nombre_pri; ?></option>
														<?php endforeach; ?>
													</select>
												</div>
												
												<div class="form-group">
													<label>Estado *</label>
													<select name="id_status" class="form-control" required>
														<?php foreach ($estados_array as $id_est => $nombre_est): ?>
															<option value="<?php echo $id_est; ?>"><?php echo $nombre_est; ?></option>
														<?php endforeach; ?>
													</select>
												</div>
												
												<div id="observacion_container" class="form-group">
													<label>Observaciones</label>
													<textarea name="observacion" class="form-control" rows="3"></textarea>
												</div>
												
												<div id="fecha_prevista_container" class="form-group">
													<label>Fecha Prevista</label>
													<input type="datetime-local" name="fecha_prevista" class="form-control">
												</div>
											</div>
											
											<!-- Columna derecha - ajustada para responsividad -->
											<div class="col-md-6 col-sm-12">
												<div id="insumo_container" class="form-group">
													<label>Seleccionar Insumo</label>
													<select name="id_insumo" class="form-control">
														<option value="">-- Seleccionar insumo --</option>
														<?php foreach ($insumos_array as $id_ins => $nombre_ins): ?>
															<option value="<?php echo $id_ins; ?>"><?php echo $nombre_ins; ?></option>
														<?php endforeach; ?>
													</select>
												</div>
												
												<div id="cantidad_solicitada_container" class="form-group">
													<label>Cantidad Solicitada</label>
													<input type="number" name="cantidad_solicitada" class="form-control">
												</div>
												
												<div id="cantidad_entregada_container" class="form-group">
													<label>Cantidad Entregada</label>
													<input type="number" name="cantidad_entregada" class="form-control">
												</div>
												
												<div id="lote_container" class="form-group">
													<label>Lote</label>
													<input type="text" name="lote" class="form-control">
												</div>
												
												<div id="clave_container" class="form-group">
													<label>Clave</label>
													<input type="text" name="clave" class="form-control">
												</div>
												
												<div id="tipo_mov_container" class="form-group">
													<label>Tipo de Movimiento</label>
													<select name="tipo_mov" class="form-control">
														<option value="E">Entrada</option>
														<option value="S">Salida</option>
													</select>
												</div>
												
												<div id="nota_container" class="form-group">
													<label>Nota</label>
													<textarea name="nota" class="form-control" rows="3"></textarea>
												</div>
												
												<div id="doc_container" class="form-group">
													<label>Documento</label>
													<input type="text" name="doc" class="form-control">
												</div>
												
												<div id="imagenes_container" class="form-group">
													<label>Imágenes</label>
													<input type="file" name="imagenes[]" multiple class="form-control">
													<small class="form-text text-muted">Formatos permitidos: JPG, PNG, GIF (Máx. 5MB por archivo)</small>
												</div>
											</div>
										</div>
										
										<div class="text-center mt-4">
											<button type="submit" class="btn btn-primary btn-lg btn-block-xs">
												<i class="fa fa-save"></i> Guardar Planificación
											</button>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>

				<?php footer(); ?>
			</div>
		</div>
		
		<script>
			// Función para mostrar/ocultar campos según la acción seleccionada
			function mostrarCamposPorAccion() {
				const accion = document.getElementById('accion_rol').value;
				
				// Ocultar todos los campos opcionales primero
				const camposOpcionales = [
					'observacion_container', 'fecha_prevista_container', 'insumo_container',
					'cantidad_solicitada_container', 'cantidad_entregada_container', 'lote_container',
					'clave_container', 'tipo_mov_container', 'nota_container', 'doc_container',
					'imagenes_container'
				];
				
				camposOpcionales.forEach(id => {
					document.getElementById(id).style.display = 'none';
				});
				
				// Mostrar campos específicos según la acción seleccionada
				switch(accion) {
					// Acciones de administrador/solicitador
					case 'crear_solicitud':
					case 'modificar_solicitud':
					case 'solicitar_insumos':
						['observacion_container', 'fecha_prevista_container', 'insumo_container', 
						 'cantidad_solicitada_container', 'imagenes_container'].forEach(id => {
							document.getElementById(id).style.display = 'block';
						});
						break;
						
					// Acciones de administrador/entregador
					case 'registrar_entrega':
					case 'registrar_parcial':
						['insumo_container', 'cantidad_entregada_container', 'lote_container', 
						 'clave_container', 'doc_container', 'imagenes_container'].forEach(id => {
							document.getElementById(id).style.display = 'block';
						});
						break;
						
					// Acciones de administrador/entregador
					case 'registrar_movimiento':
						['tipo_mov_container', 'insumo_container', 'cantidad_solicitada_container', 
						 'doc_container', 'nota_container', 'imagenes_container'].forEach(id => {
							document.getElementById(id).style.display = 'block';
						});
						break;
						
					// Acciones de administrador/entregador
					case 'actualizar_inventario':
						['insumo_container', 'cantidad_solicitada_container', 'lote_container', 
						 'clave_container', 'imagenes_container'].forEach(id => {
							document.getElementById(id).style.display = 'block';
						});
						break;
						
					// Acción específica de administrador
					case 'aprobar_solicitud':
						['observacion_container', 'imagenes_container'].forEach(id => {
							document.getElementById(id).style.display = 'block';
						});
						break;
						
					// Acción de seguimiento (solicitador)
					case 'seguimiento_solicitud':
						['observacion_container', 'imagenes_container'].forEach(id => {
							document.getElementById(id).style.display = 'block';
						});
						break;
				}
				
				// Establecer tipo de movimiento para acciones específicas
				if (accion === 'registrar_movimiento') {
					document.getElementById('tipo_movimiento').value = 'movimiento';
				} else if (accion === 'actualizar_inventario') {
					document.getElementById('tipo_movimiento').value = 'inventario';
				} else {
					document.getElementById('tipo_movimiento').value = 'solicitud';
				}
			}
			
			// Inicializar el formulario ocultando todos los campos opcionales
			document.addEventListener('DOMContentLoaded', function() {
				mostrarCamposPorAccion();
				
				// Ajustar para dispositivos móviles
				if (window.innerWidth < 768) {
					// Ocultar menú lateral por defecto en móviles
					document.body.classList.add('mini-navbar');
				}
			});
			
			// Manejar cambios de tamaño de pantalla
			window.addEventListener('resize', function() {
				if (window.innerWidth < 768) {
					document.body.classList.add('mini-navbar');
				} else {
					document.body.classList.remove('mini-navbar');
				}
			});
		</script>
		
		<?php						   
	} else {
		header('Location: index.html');
		exit;
	}
	
	scrips();
?>
</body>
</html>