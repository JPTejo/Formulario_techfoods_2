<?php

	function head ($pagina)
	{
		echo("<!DOCTYPE html>
			  <html>
			  	<head>
					<meta http-equiv='Content-type' content='text/html'; charset='iso-8859-1' />
    				<title>TFSolicitudes | $pagina</title>
					<link rel='icon' href='img/fav.ico' type='image/x-icon'>");
		if ($pagina=="Home" or $pagina="Detalle")
		{
			echo("  <link href='css/bootstrap.min.css' rel='stylesheet'>
    			    <link href='font-awesome/css/font-awesome.css' rel='stylesheet'>
					<!-- Toastr style -->
					<link href='css/plugins/toastr/toastr.min.css' rel='stylesheet'>
					<link href='css/animate.css' rel='stylesheet'>
					<link href='css/style.css' rel='stylesheet'>
					
				</head>
				<body>");
		}
		if ($pagina=="Nuevo Usuario" or $pagina=="Nuevo Insumo")
		{
			echo("  <link href='css/bootstrap.min.css' rel='stylesheet'>
    			    <link href='font-awesome/css/font-awesome.css' rel='stylesheet'>
					<!-- Toastr style -->
					<link href='css/plugins/toastr/toastr.min.css' rel='stylesheet'>
					<link href='css/animate.css' rel='stylesheet'>
					<link href='css/style.css' rel='stylesheet'>
					
    				<link href='css/plugins/iCheck/custom.css' rel='stylesheet'>
    				<link href='css/plugins/steps/jquery.steps.css' rel='stylesheet'>
		
				</head>
				<body>");
		}
		if ($pagina=="Solicitud de Muestra")
		{
        	echo("	<meta name='viewport' content='width=device-width, initial-scale=1.0'>
					<link href='css/bootstrap.min.css' rel='stylesheet'>
    				<link href='font-awesome/css/font-awesome.css' rel='stylesheet'>
					<link href='css/plugins/iCheck/custom.css' rel='stylesheet'>
					<link href='css/plugins/steps/jquery.steps.css' rel='stylesheet'>
					<link href='css/animate.css' rel='stylesheet'>
					<link href='css/style.css' rel='stylesheet'>
				</head
				<body>");
		}
		if ($pagina=="Lista de Usuarios" or $pagina="Busqueda" )
		{
			echo("  <link href='css/bootstrap.min.css' rel='stylesheet'>
    				<link href='font-awesome/css/font-awesome.css' rel='stylesheet'>
    				<!-- FooTable -->
    				<link href='css/plugins/footable/footable.core.css' rel='stylesheet'>
    				<link href='css/animate.css' rel='stylesheet'>
    				<link href='css/style.css' rel='stylesheet'>
				</head>
				<body>");
		}
		if ($pagina=='Perfil' or $pagina='Editar Usuario')
		{
			echo("	<link href='css/bootstrap.min.css' rel='stylesheet'>
    				<link href='font-awesome/css/font-awesome.css' rel='stylesheet'>
					<link href='css/plugins/summernote/summernote-bs4.css' rel='stylesheet'>
					<link href='css/plugins/datapicker/datepicker3.css' rel='stylesheet'>
					<link href='css/animate.css' rel='stylesheet'>
					<link href='css/style.css' rel='stylesheet'>
				</head>
				<body>");
		}
		if ($pagina=="Llenado de Informe de Maquina")
		{
			echo("  <link href='css/bootstrap.min.css' rel='stylesheet'>
    			    <link href='font-awesome/css/font-awesome.css' rel='stylesheet'>
					<!-- Toastr style -->
					<link href='css/plugins/toastr/toastr.min.css' rel='stylesheet'>
					<link href='css/animate.css' rel='stylesheet'>
					<link href='css/style.css' rel='stylesheet'>
					
				</head>
				<body>");
		}
	}

	function menu_lateral ($id)
	{
		include("conexion.php");
		mysqli_query($conexion,"SET NAMES 'utf8'");
		$bfoto=mysqli_query($conexion,"SELECT foto,cargo FROM `usuarios` WHERE `id_usuario`=$id");
		while ($foto = $bfoto->fetch_row()) 
		{
        	$foto_perfil=$foto[0];
			$cargo=$foto[1];
    	}
		if ($foto_perfil=="")
		{
			$foto_perfil='img/avatar/default_avatar.jpg';
		}
		$nombre=$_SESSION['nombre'];
		echo("
				<nav class='navbar-default navbar-static-side' role='navigation'>
					<div class='sidebar-collapse'>
						<ul class='nav metismenu' id='side-menu'>
							<li class='nav-header'>
								<div align='center' class='dropdown profile-element'>
									<img alt='image' class='rounded-circle' src='$foto_perfil' width='150px' height='170px'/>
									<a data-toggle='dropdown' class='dropdown-toggle' href='#'>
										<span class='block m-t-xs font-bold'>$nombre</span>
										<span class='text-muted text-xs block'>$cargo <b class='caret'></b></span>
									</a>
									<ul class='dropdown-menu animated fadeInRight m-t-xs'>
										<li><a class='dropdown-item' href='perfil.php'>perfil</a></li>
										<li class='dropdown-divider'></li>
										<li><a class='dropdown-item' href='logout.php'>Cerrar sesion</a></li>
									</ul>
								</div>
								<div class='logo-element'>
									TF+
								</div>
							</li>
							
				");
					if ($_SESSION['is_admin']=='1')
					{
						echo("
								<li>
										<li>
											<a href='#'><i class='fa fa-address-book-o'></i> <span class='nav-label'>Gestion Usuarios</span><span class='fa arrow'></span></a>
											<ul class='nav nav-second-level collapse'>
												<li><a href='nuevo_usuario.php'>Nuevo Usuario</a></li>
												<li><a href='lista_usuarios.php'>Ver usuarios</a></li>
												<li><a href='lista_usuarios_co.php'>Inactivar Usuario</a></li>
											</ul>
										</li>
								</li>
						");
					}
						echo("
								<li>
									<a href='#'><i class='fa fa-cubes'></i> <span class='nav-label'>Solicitudes</span><span class='fa arrow'></span></a>
									<ul class='nav nav-second-level collapse'>");
					if ($_SESSION['is_solicitador']=='1' or $_SESSION['is_admin']=='1')
					{
					
									echo("<li><a href='solicitudes.php'>Nueva solicitud</a></li>");
					}
										echo("<li><a href='mis_solicitudes.php'>Mis Solicitudes Pendientes</a></li>
										<li><a href='mi_historial.php'>Mi Historial</a></li>
										<li><a href='home.php'>Ver Cartelera</a></li>
										<li><a href='archivado.php'>Archivadas</a></li>
									</ul>
								</li>
								<li>
									<a href='#'><i class='fa fa-cubes'></i> <span class='nav-label'>Stock´s</span><span class='fa arrow'></span></a>
									<ul class='nav nav-second-level collapse'>
										<li><a href='stocks.php'>Control de existencia</a></li>
									</ul>
									<ul class='nav nav-second-level collapse'>
										<li><a href='promedios.php'>Promedio Consumos</a></li>
									</ul>
									<ul class='nav nav-second-level collapse'>
										<li><a href='promedio_tintas.php'>Promedio Consumos Tintas Detallado</a></li>
									</ul>
									<ul class='nav nav-second-level collapse'>
										<li><a href='promedio_general_tintas.php'>Promedio Consumos General Tintas</a></li>
									</ul>
								</li>
							</ul>
						</div>
					</nav>
				");
	}

	function barra_superior ($id,$pagina)
	{
		$nombre = $_SESSION['nombre']; 
		$nombre_incompleto = explode(' ',trim($nombre)); 
		$id=$_SESSION['id_usuario']; 
		echo("<div class='row border-bottom'>
        		<nav class='navbar navbar-static-top' role='navigation' style='margin-bottom: 0'>
        			<div class='navbar-header'>
            			<a class='navbar-minimalize minimalize-styl-2 btn btn-primary ' href='#'><i class='fa fa-bars'></i> </a>");
		if ($pagina=='Home')
		{
			echo("<form role='search' class='navbar-form-custom' action='search_results.html'>
              
            </form>");
		}
		echo("		</div>
					<ul class='nav navbar-top-links navbar-right'>
						<li>
							<span class='m-r-sm text-muted welcome-message'>Bienvenido $nombre_incompleto[0] ($id) 
							</span>
						</li>
						<li class='dropdown'>
							<a class='dropdown-toggle count-info' data-toggle='dropdown' href='#'>
								<i class='fa fa-bell'></i>  <span class='label label-primary'>0</span>
							</a>
							<ul class='dropdown-menu dropdown-alerts'>
								<li>
									<a href='mailbox.html' class='dropdown-item'>
										<div>
											<i class='fa fa-envelope fa-fw'></i> Pedido 6 (Falta Informe)
											<span class='float-right text-muted small'>Hace 4 Horas</span>
										</div>
									</a>
								</li>
								<li class='dropdown-divider'></li>
								<li>
									<a href='mailbox.html' class='dropdown-item'>
										<div>
											<i class='fa fa-envelope fa-fw'></i> Pedido 7 (Falta Informe)
											<span class='float-right text-muted small'>Hace 4 Horas</span>
										</div>
									</a>
								</li>                     
								<li class='dropdown-divider'></li>
								<li>
									<div class='text-center link-block'>
										<a href='notifications.html' class='dropdown-item'>
											<strong>Ver todas las notificaciones</strong>
											<i class='fa fa-angle-right'></i>
										</a>
									</div>
								</li>
							</ul>
						</li>
						<li>
							<a href='logout.php'>
								<i class='fa fa-sign-out'></i> Cerrar Sesion
							</a>
						</li>
					</ul>
        		</nav>
        	</div>");
	}
	
	function footer ()
	{
		echo("<div class='footer'>
            <div class='float-right'>
                <strong>JP2025 </strong>
            </div>
            <div>
                <strong>Copyright</strong> TF &copy; 2025
            </div>
        </div>");
	}

	function scrips()
	{
		//home
		echo("<!-- Mainly scripts -->
				<script src='js/jquery-3.1.1.min.js'></script>
				<script src='js/popper.min.js'></script>
				<script src='js/bootstrap.js'></script>
				<script src='js/plugins/metisMenu/jquery.metisMenu.js'></script>
				<script src='js/plugins/slimscroll/jquery.slimscroll.min.js'></script>
			  <!-- jquery UI -->
				<script src='js/plugins/jquery-ui/jquery-ui.min.js'></script>
				<!-- Touch Punch - Touch Event Support for jQuery UI -->
				<script src='js/plugins/touchpunch/jquery.ui.touch-punch.min.js'></script>
				<!-- Custom and plugin javascript -->
				<script src='js/inspinia.js'></script>
				<script src='js/plugins/pace/pace.min.js'></script>
				<script src='js/plugins/footable/footable.all.min.js'></script>
				<script>
        			$(document).ready(function()
					{
            			$('#todo, #inprogress, #completed').sortable(
						{
                			connectWith: '.connectList',
                			update: function( event, ui ) 
							{
                    			var todo = $( '#todo' ).sortable( 'toArray' );
                    			var inprogress = $( '#inprogress' ).sortable( 'toArray' );
                    			var completed = $( '#completed' ).sortable( 'toArray' );
                    			$('.output').html('ToDo: ' + window.JSON.stringify(todo) + '<br/>' + 'In Progress: ' + window.JSON.stringify(inprogress) + '<br/>' + 'Completed: ' + window.JSON.stringify(completed));
                			}
            			}).disableSelection();

        			});
    			</script>");
		//nuevo usuario
		echo("<!-- Steps -->
    			<script src='js/plugins/steps/jquery.steps.min.js'></script>
			  <!-- Jquery Validate -->
				<script src='js/plugins/validate/jquery.validate.min.js'></script>
			    <script>
					$(document).ready(function(){
						$('#wizard').steps();
						$('#form').steps({
							bodyTag: 'fieldset',
							onStepChanging: function (event, currentIndex, newIndex)
							{
								// Always allow going backward even if the current step contains invalid fields!
								if (currentIndex > newIndex)
								{
									return true;
								}

								// Forbid suppressing 'Warning' step if the user is to young
								if (newIndex === 3 && Number($('#age').val()) < 18)
								{
									return false;
								}

								var form = $(this);

								// Clean up if user went backward before
								if (currentIndex < newIndex)
								{
									// To remove error styles
									$('.body:eq(' + newIndex + ') label.error', form).remove();
									$('.body:eq(' + newIndex + ') .error', form).removeClass('error');
								}

								// Disable validation on fields that are disabled or hidden.
								form.validate().settings.ignore = ':disabled,:hidden';

								// Start validation; Prevent going forward if false
								return form.valid();
							},
							onStepChanged: function (event, currentIndex, priorIndex)
							{
								// Suppress (skip) 'Warning' step if the user is old enough.
								if (currentIndex === 2 && Number($('#age').val()) >= 18)
								{
									$(this).steps('next');
								}

								// Suppress (skip) 'Warning' step if the user is old enough and wants to the previous step.
								if (currentIndex === 2 && priorIndex === 3)
								{
									$(this).steps('previous');
								}
							},
							onFinishing: function (event, currentIndex)
							{
								var form = $(this);

								// Disable validation on fields that are disabled.
								// At this point it's recommended to do an overall check (mean ignoring only disabled fields)
								form.validate().settings.ignore = ':disabled';

								// Start validation; Prevent form submission if false
								return form.valid();
							},
							onFinished: function (event, currentIndex)
							{
								var form = $(this);

								// Submit form input
								form.submit();
							}
						}).validate({
									errorPlacement: function (error, element)
									{
										element.before(error);
									},
									rules: {
										confirm: {
											equalTo: '#password'
										}
									}
								});
				   });
				</script>");
	}

?>
