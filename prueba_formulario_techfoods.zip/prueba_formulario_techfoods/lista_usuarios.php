<?php
	include("layout.php");
	$pagina="Lista de Usuarios";
	head($pagina);
	include("conexion.php");
	session_start();
	if (!isset($_SESSION['id_usuario']))
    {
        echo("No existe");
    }
	else
	{
		$id=$_SESSION['id_usuario'];
		$conexion = new mysqli($host_db, $user_db, $pass_db, $db_name);
		$sql= "SELECT * FROM `usuarios` WHERE `id_usuario`=$id";
		$result = $conexion->query($sql);
		$row = $result->fetch_array(MYSQLI_ASSOC);
	}
	if ($result->num_rows > 0) 
	{  	 
?>
    <div id="wrapper">
    	<?php
	 		menu_lateral($row['id_usuario']);
	 	?>
        <div id="page-wrapper" class="gray-bg">
        	<?php
				barra_superior($row['id_usuario'],$pagina);
			?>
        	<div class="row border-bottom"></div>
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>Lista de Usuario</h2>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="home.php">Inicio</a>
                        </li>
                        <li  class="breadcrumb-item active">
                            <strong>Lista de Usuario</strong>
                        </li>
                    </ol>
                </div>
            </div>
        	<div class="wrapper wrapper-content animated fadeInRight ecommerce">
            	<div class="ibox-content m-b-sm border-bottom">
					<div class="row">
						<div class="col-sm-4">
							<div class="form-group">
								<label class="col-form-label" for="nombre_completo">Nombre y Apellido</label>
								<input type="text" id="nombre_completo" name="nombre_completo" value="" placeholder="Nombre a buscar..." class="form-control">
							</div>
						</div>
						<div class="col-sm-2">
							<div class="form-group">
								<label class="col-form-label" for="email">Email</label>
								<input type="text" id="email" name="email" value="" placeholder="Email a buscar..." class="form-control">
							</div>
						</div>
						<div class="col-sm-2">
							<div class="form-group">
								<label class="col-form-label" for="cargo">cargo</label>
								<input type="text" id="cargo" name="cargo" value="" placeholder="Cargo a buscar..." class="form-control">
							</div>
						</div>
						<div class="col-sm-4">
							<div class="form-group">
								<label class="col-form-label" for="status">Status</label>
								<select name="status" id="status" onChange="status()" class="form-control">
									<option value="3"></option>
									<option value="1">Activo</option>
									<option value="2">Inactivo</option>
								</select>
							</div>
						</div>
					</div>
           			<div id="resultado" class="col-sm-12"></div>
            	</div>
				<div class="row">
					<div class="col-lg-12">
						<div class="ibox">
							<div class="ibox-content">
								<table class="footable table  toggle-arrow-tiny" data-page-size="15">
									<thead>
										<tr>
											<th>Foto</th>
											<th>Nombre y Apellido</th>
											<th>Email</th>
											<th>Cargo</th>
											<th>Status</th>
											<th>Tipo de Usuario</th>
											<th align="center" class="text-right" data-sort-ignore="true">Action</th>
										</tr>
									</thead>
									<tbody>
										<tr>
											<?php
												mysqli_query($conexion,"SET NAMES 'utf8'");
												$buscar_usuarios=mysqli_query($conexion,"SELECT * FROM `usuarios`");
												while ($usuario = $buscar_usuarios->fetch_row()) 
												{
													$id=$usuario[0];
													$nombre=$usuario[1];
													$email=$usuario[2];
													$cargo=$usuario[3];
													$foto_perfil=$usuario[4];
													if ($foto_perfil=='')
													{
														$foto_perfil='img/avatar/default_avatar.jpg';
													}
													$status=$usuario[6];
													if ($status==1)
													{
														$status='Activo';
													}
													else
													{
														$status='Inactivo';
													}
													$admin=$usuario[9];
													if ($admin==1)
													{
														$admin='Administrador';
													}
													else
													{
														$admin='Usuario';
														if ($usuario[7]==1)
														{
															$admin='Usuario';
															$tipo='Solicita';
														}
														if ($usuario[8]==1)
														{
															$admin='Usuario';
															$tipo='Entrega';
														}
														
													}
												
											?>
											<td>
											   <a href=""><img alt="image" class="rounded-circle" src="<?php echo($foto_perfil); ?>" height="50px" width="50px"></a>
											</td>
											<td style="vertical-align:middle;">
												<?php echo($nombre); ?>
											</td>
											<td style="vertical-align:middle;">
												<?php echo($email); ?>
											</td>
											<td style="vertical-align:middle;">
												<?php echo($cargo); ?>
											</td>
											<?php
												if ($status=='Activo')
												{
													echo("	<td style='vertical-align:middle;'>
																<span class='label label-primary'>$status</span>
															</td>
														 ");
												}
												else
												{
													echo("	<td style='vertical-align:middle;'>
																<span class='label label-warning'>$status</span>
															</td>
														 ");
												}
											?>
											<td style="vertical-align:middle;">
												<span class="label label-primary"><?php echo($admin); ?></span>
												<?php
													if ($usuario[7]==1 or $usuario[8]==1)
													{
														?>
														<span class="label label-primary"><?php echo($tipo); ?></span>
														<?php
													}
												?>
											</td>
											<td class="text-right" style="vertical-align:middle;" align="center">
												<div class="btn-group">
													<button onClick="window.location.href='editar_usuario.php?id_usuario=<?php echo($id); ?>';" class="btn-warning btn btn-xs">Editar</button>
												</div>
											</td>
										</tr>
										<?php
												}
											?>
									</tbody>
									<tfoot>
										<tr>
											<td colspan="6">
												<ul class="pagination float-right"></ul>
											</td>
										</tr>
									</tfoot>
								</table>
							</div>
						</div>
                	</div>
            	</div>
        	</div>
			<?php
				footer();
			?>
        </div>
 	</div>
	<?php						   }
		else
		{
			header('Location: index.html');//redirecciona a la pagina del usuario
		}
		scrips();
	?>
    <!-- Page-Level Scripts -->
    <script>
        $(document).ready(function() 
		{
			$('.footable').footable();
        });
    </script> 
    <script>
		$(document).ready(function(){
			var consulta;
			//hacemos focus al campo de búsqueda
			$("#nombre_completo").focus();

			//comprobamos si se pulsa una tecla
			$("#nombre_completo").keyup(function(e){

				  //obtenemos el texto introducido en el campo de búsqueda
				  consulta = $("#nombre_completo").val();
				  //hace la búsqueda                                                                                  
				  $.ajax({
						type: "POST",
						url: "buscar_nombre.php",
						data: "b="+consulta,
						dataType: "html",
						beforeSend: function(){
						//imagen de carga
						$("#resultado").html("<p align='center'><img src='ajax-loader.gif' /></p>");
						},
						error: function(){
						alert("error petición ajax");
						},
						success: function(data){                                                    
						$("#resultado").empty();
						$("#resultado").append(data);                                                             
						}
				  });                                                                         
			});                                                     
		});             
	</script>
	<script>
		$(document).ready(function(){
			var consulta;
			//hacemos focus al campo de búsqueda
			$("#email").focus();

			//comprobamos si se pulsa una tecla
			$("#email").keyup(function(e){

				  //obtenemos el texto introducido en el campo de búsqueda
				  consulta = $("#email").val();
				  //hace la búsqueda                                                                                  
				  $.ajax({
						type: "POST",
						url: "buscar_correo.php",
						data: "b="+consulta,
						dataType: "html",
						beforeSend: function(){
						//imagen de carga
						$("#resultado").html("<p align='center'><img src='ajax-loader.gif' /></p>");
						},
						error: function(){
						alert("error petición ajax");
						},
						success: function(data){                                                    
						$("#resultado").empty();
						$("#resultado").append(data);                                                             
						}
				  });                                                                         
			});                                                     
		});             
 	</script>
 	<script>
		$(document).ready(function(){
			var consulta;
			//hacemos focus al campo de búsqueda
			$("#cargo").focus();

			//comprobamos si se pulsa una tecla
			$("#cargo").keyup(function(e){

				  //obtenemos el texto introducido en el campo de búsqueda
				  consulta = $("#cargo").val();
				  //hace la búsqueda                                                                                  
				  $.ajax({
						type: "POST",
						url: "buscar_cargo.php",
						data: "b="+consulta,
						dataType: "html",
						beforeSend: function(){
						//imagen de carga
						$("#resultado").html("<p align='center'><img src='ajax-loader.gif' /></p>");
						},
						error: function(){
						alert("error petición ajax");
						},
						success: function(data){                                                    
						$("#resultado").empty();
						$("#resultado").append(data);                                                             
						}
				  });                                                                         
			});                                                     
		});             
 	</script>
 	<script>
		function status(){
			var valor = document.getElementById("status").value;
			//alert(valor);
			if (valor!='')
			{
				  $.ajax({
						type: "POST",
						url: "buscar_status.php",
						data: "b="+valor,
						dataType: "html",
						beforeSend: function(){
						//imagen de carga
						$("#resultado").html("<p align='center'><img src='ajax-loader.gif' /></p>");
						},
						error: function(){
						alert("error petición ajax");
						},
						success: function(data){                                                    
						$("#resultado").empty();
						$("#resultado").append(data);                                                             
						}
				  }); 
			}
		}
 	</script>
</body>
</html>
        



  


