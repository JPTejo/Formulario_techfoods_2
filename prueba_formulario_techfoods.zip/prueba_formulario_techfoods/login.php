<?php
	session_start();
	echo (session_id());
	echo("<br>");
?>
<?php
	include 'conexion.php';
	$username = $_POST['email'];
	$password = $_POST['pass'];
	$sql = "SELECT * FROM $tbl_name WHERE email = '$username'";
	mysqli_set_charset($conexion,'utf8');
	$result = $conexion->query($sql);
	if ($result->num_rows > 0) {    }
	
 
  	$row = $result->fetch_array(MYSQLI_ASSOC);

 	// if (password_verify($password, $row['password'])) { 
	if ($password==$row['pass'] and $row['status']==1) { 

 	$nombre=$row['nombre'];
	$id_usuario=$row['id_usuario'];
    $_SESSION['loggedin'] = true;
    $_SESSION['email'] = $username;
	$_SESSION['nombre'] = $nombre;
	$_SESSION['id_usuario'] = $id_usuario;
	$_SESSION['is_admin'] = $row['is_admin'];
	$_SESSION['is_solicitador'] = $row['is_solicitador'];
	$_SESSION['is_entregador']=$row['is_entregador'];
    $_SESSION['start'] = time();
    //$_SESSION['expire'] = $_SESSION['start'] + (5 * 60);
	$nombre=mysqli_fetch_row($result);	
    echo "Bienvenido! " . $_SESSION['email'];
	echo("<br>");
	echo "Bienvenido! " . $_SESSION['nombre'];
		
    //echo "<br><br><a href=panel-control.php>Panel de Control</a>"; 
    header('Location: home.php');//redirecciona a la pagina del usuario

 	} 
	else { 
   echo "Username o Password estan incorrectos.";

   echo "<br><a href='index.html'>Volver a Intentarlo</a>";
 	}
	mysqli_close($conexion); 
 	?>
