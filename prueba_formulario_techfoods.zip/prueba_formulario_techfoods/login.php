<?php
session_start();
include 'conexion.php';

// Verificar si se enviaron los datos
if (!isset($_POST['email']) || !isset($_POST['pass'])) {
    die("Datos incompletos");
}

$username = $_POST['email'];
$password = $_POST['pass'];

// Usar prepared statements para evitar SQL injection
$sql = "SELECT id_usuario, nombre, email, pass, status, is_admin, is_solicitador, is_entregador FROM usuarios WHERE email = ?";
$stmt = $conexion->prepare($sql);

if (!$stmt) {
    die("Error en la preparación de la consulta: " . $conexion->error);
}

$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

// Verificar si se encontró el usuario
if ($result->num_rows === 0) {
    die("Username o Password están incorrectos.<br><a href='index.html'>Volver a Intentarlo</a>");
}

$row = $result->fetch_assoc();

// VERIFICACIÓN MODIFICADA - COMPARACIÓN DIRECTA EN TEXTO PLANO
if ($password === $row['pass'] && $row['status'] == 1) {
    // Configurar sesión
    $_SESSION['loggedin'] = true;
    $_SESSION['email'] = $row['email'];
    $_SESSION['nombre'] = $row['nombre'];
    $_SESSION['id_usuario'] = $row['id_usuario'];
    $_SESSION['is_admin'] = $row['is_admin'];
    $_SESSION['is_solicitador'] = $row['is_solicitador'];
    $_SESSION['is_entregador'] = $row['is_entregador'];
    $_SESSION['start'] = time();
    
    // Redireccionar sin salida previa
    header('Location: home.php');
    exit();
} else {
    echo "Username o Password están incorrectos o la cuenta está inactiva.";
    echo "<br><a href='index.html'>Volver a Intentarlo</a>";
}

$stmt->close();
$conexion->close();
?>