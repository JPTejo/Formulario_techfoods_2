<?php
session_start();
include("layout.php");
$pagina = "Máquinas";
head($pagina);
include("conexion.php");

if (!isset($_SESSION['id_usuario'])) {
    header('Location: index.html');
    exit;
}

$conexion = new mysqli($host_db, $user_db, $pass_db, $db_name);

// Obtener todas las máquinas
$maquinas = $conexion->query("SELECT * FROM maquinas");

// Obtener máquinas ocupadas con información de OP y usuario
$sql_ocupadas = "SELECT mov.id_maquina, mov.nro_op, u.nombre as nombre_usuario,
                mov.fecha_registro as fecha_entrada
                FROM op_movimientos mov
                JOIN usuarios u ON mov.id_usuario = u.id_usuario
                WHERE mov.accion_realizada = 'entrada_proceso'
                AND NOT EXISTS (
                    SELECT 1 
                    FROM op_movimientos mov2
                    WHERE mov2.nro_op = mov.nro_op
                    AND mov2.id_maquina = mov.id_maquina
                    AND mov2.accion_realizada = 'salida_proceso'
                )";
$result_ocupadas = $conexion->query($sql_ocupadas);
$ocupadas = [];
while ($row = $result_ocupadas->fetch_assoc()) {
    $ocupadas[$row['id_maquina']] = $row;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pagina; ?></title>
    <style>
        .maquina-card {
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            height: 100%;
            position: relative;
            margin-bottom: 20px;
        }
        .maquina-disponible {
            border-left: 4px solid #1ab394;
        }
        .maquina-ocupada {
            border-left: 4px solid #ed5565;
        }
        .status-badge {
            position: absolute;
            top: 10px;
            right: 10px;
            padding: 5px 10px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 600;
        }
        .badge-success {
            background-color: #1ab394;
            color: white;
        }
        .badge-danger {
            background-color: #ed5565;
            color: white;
        }
        .maquina-icon {
            font-size: 40px;
            margin-bottom: 15px;
            color: #676a6c;
        }
        .search-container {
            margin-bottom: 25px;
        }
        .filter-container {
            margin-bottom: 20px;
        }
        .ocupada-info {
            background-color: #f8f9fa;
            border-radius: 5px;
            padding: 10px;
            margin-top: 10px;
            font-size: 14px;
        }
        .table-responsive {
            overflow-x: auto;
        }
        .btn-filter {
            margin-right: 5px;
            margin-bottom: 5px;
        }
        .btn-filter.active {
            background-color: #1ab394;
            color: white;
            border-color: #1ab394;
        }
    </style>
</head>
<body>
    <div id="wrapper">
        <?php menu_lateral($_SESSION['id_usuario']); ?>
        <div id="page-wrapper" class="gray-bg">
            <?php barra_superior($_SESSION['id_usuario'], $pagina); ?>
            
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10 col-md-12">
                    <h2><?php echo $pagina; ?></h2>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="home.php">Inicio</a>
                        </li>
                        <li class="breadcrumb-item active">
                            <strong><?php echo $pagina; ?></strong>
                        </li>
                    </ol>
                </div>
            </div>

            <div class="wrapper wrapper-content animated fadeInRight">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="ibox">
                            <div class="ibox-title">
                                <h5>Estado de las Máquinas</h5>
                            </div>
                            <div class="ibox-content">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="alert alert-info">
                                            <i class="fa fa-info-circle"></i> Estado actual de las máquinas del sistema
                                        </div>
                                    </div>
                                    <div class="col-md-6 text-right">
                                        <div class="btn-group">
                                            <button class="btn btn-white btn-sm btn-filter active" data-filter="all">Todas</button>
                                            <button class="btn btn-white btn-sm btn-filter" data-filter="disponible">Disponibles</button>
                                            <button class="btn btn-white btn-sm btn-filter" data-filter="ocupada">Ocupadas</button>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="filter-container">
                                    <div class="input-group">
                                        <input type="text" class="form-control" id="search-maquina" placeholder="Buscar máquina...">
                                        <span class="input-group-append">
                                            <button type="button" class="btn btn-primary" id="btn-buscar">
                                                <i class="fa fa-search"></i>
                                            </button>
                                        </span>
                                    </div>
                                </div>
                                
                                <!-- Vista de tarjetas -->
                                <div class="row" id="maquinas-container">
                                    <?php while ($maquina = $maquinas->fetch_assoc()): 
                                        $ocupada = isset($ocupadas[$maquina['id_maquina']]);
                                        $info_ocupada = $ocupada ? $ocupadas[$maquina['id_maquina']] : null;
                                    ?>
                                    <div class="col-md-4 col-sm-6 mb-4 maquina-item" 
                                        data-status="<?php echo $ocupada ? 'ocupada' : 'disponible'; ?>"
                                        data-name="<?php echo strtolower($maquina['nombre']); ?>">
                                        <div class="maquina-card <?php echo $ocupada ? 'maquina-ocupada' : 'maquina-disponible'; ?>">
                                            <div class="card-body p-3 position-relative">
                                                <span class="status-badge badge-<?php echo $ocupada ? 'danger' : 'success'; ?>">
                                                    <?php echo $ocupada ? 'OCUPADA' : 'DISPONIBLE'; ?>
                                                </span>
                                                
                                                <div class="d-flex align-items-center">
                                                    <div class="maquina-icon mr-3">
                                                        <i class="fa fa-cogs"></i>
                                                    </div>
                                                    <div>
                                                        <h4 class="mb-1"><?php echo $maquina['nombre']; ?></h4>
                                                        <p class="text-muted mb-0">ID: <?php echo $maquina['id_maquina']; ?></p>
                                                    </div>
                                                </div>
                                                
                                                <?php if ($ocupada): ?>
                                                <div class="ocupada-info mt-3">
                                                    <div class="d-flex justify-content-between">
                                                        <div>
                                                            <strong>OP:</strong> <?php echo $info_ocupada['nro_op']; ?>
                                                        </div>
                                                        <div>
                                                            <i class="fa fa-clock-o"></i> 
                                                            <?php echo date('d/m/Y H:i', strtotime($info_ocupada['fecha_entrada'])); ?>
                                                        </div>
                                                    </div>
                                                    <div class="mt-2">
                                                        <strong>Operador:</strong> <?php echo $info_ocupada['nombre_usuario']; ?>
                                                    </div>
                                                </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endwhile; ?>
                                </div>
                                
                                <!-- Vista de tabla -->
                                <div class="table-responsive mt-4">
                                    <table class="table table-striped" id="tabla-maquinas">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Nombre</th>
                                                <th>Estado</th>
                                                <th>OP Actual</th>
                                                <th>Operador</th>
                                                <th>Desde</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php 
                                            $maquinas->data_seek(0); // Reiniciar puntero
                                            while ($maquina = $maquinas->fetch_assoc()): 
                                                $ocupada = isset($ocupadas[$maquina['id_maquina']]);
                                                $info_ocupada = $ocupada ? $ocupadas[$maquina['id_maquina']] : null;
                                            ?>
                                            <tr data-status="<?php echo $ocupada ? 'ocupada' : 'disponible'; ?>" 
                                                data-name="<?php echo strtolower($maquina['nombre']); ?>">
                                                <td><?php echo $maquina['id_maquina']; ?></td>
                                                <td><?php echo $maquina['nombre']; ?></td>
                                                <td>
                                                    <span class="badge badge-<?php echo $ocupada ? 'danger' : 'success'; ?>">
                                                        <?php echo $ocupada ? 'OCUPADA' : 'DISPONIBLE'; ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <?php if ($ocupada): ?>
                                                    <?php echo $info_ocupada['nro_op']; ?>
                                                    <?php else: ?>
                                                    -
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if ($ocupada): ?>
                                                    <?php echo $info_ocupada['nombre_usuario']; ?>
                                                    <?php else: ?>
                                                    -
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if ($ocupada): ?>
                                                    <?php echo date('d/m/Y H:i', strtotime($info_ocupada['fecha_entrada'])); ?>
                                                    <?php else: ?>
                                                    -
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                            <?php endwhile; ?>
                                        </tbody>
                                    </table>
                                </div>
                                
                                <div class="alert alert-warning mt-4">
                                    <i class="fa fa-exclamation-circle"></i> 
                                    Las máquinas marcadas como "OCUPADAS" están actualmente en proceso de producción. 
                                    Se liberarán cuando se registre la acción de "Salida de proceso" para el trabajo correspondiente.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php footer(); ?>
        </div>
    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Filtros
            const filterButtons = document.querySelectorAll('.btn-filter');
            filterButtons.forEach(button => {
                button.addEventListener('click', function() {
                    // Remover clase activa de todos los botones
                    filterButtons.forEach(btn => btn.classList.remove('active'));
                    // Agregar clase activa al botón clickeado
                    this.classList.add('active');
                    
                    const filter = this.getAttribute('data-filter');
                    
                    // Filtrar tarjetas
                    const cards = document.querySelectorAll('.maquina-item');
                    cards.forEach(card => {
                        const status = card.getAttribute('data-status');
                        if (filter === 'all') {
                            card.style.display = 'block';
                        } else {
                            card.style.display = status === filter ? 'block' : 'none';
                        }
                    });
                    
                    // Filtrar tabla
                    const rows = document.querySelectorAll('#tabla-maquinas tbody tr');
                    rows.forEach(row => {
                        const status = row.getAttribute('data-status');
                        if (filter === 'all') {
                            row.style.display = '';
                        } else {
                            row.style.display = status === filter ? '' : 'none';
                        }
                    });
                });
            });
            
            // Búsqueda
            const searchInput = document.getElementById('search-maquina');
            const searchButton = document.getElementById('btn-buscar');
            
            function performSearch() {
                const searchTerm = searchInput.value.toLowerCase();
                
                // Filtrar tarjetas
                const cards = document.querySelectorAll('.maquina-item');
                cards.forEach(card => {
                    const name = card.getAttribute('data-name');
                    if (name.includes(searchTerm)) {
                        card.style.display = 'block';
                    } else {
                        card.style.display = 'none';
                    }
                });
                
                // Filtrar tabla
                const rows = document.querySelectorAll('#tabla-maquinas tbody tr');
                rows.forEach(row => {
                    const name = row.getAttribute('data-name');
                    if (name.includes(searchTerm)) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                });
            }
            
            searchInput.addEventListener('keyup', performSearch);
            searchButton.addEventListener('click', performSearch);
        });
    </script>
    
    <?php scrips(); ?>
</body>
</html>