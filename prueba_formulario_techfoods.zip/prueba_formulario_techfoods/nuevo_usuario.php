<?php
	include("layout.php");
	$pagina="Nuevo Usuario";
	//head($pagina);
	include("conexion.php");
	session_start();
	if (!isset($_SESSION['id_usuario']))
    {
        echo("No existe");
    }
	else
	{
		$id=$_SESSION['id_usuario'];
		$conexion = new mysqli($host_db, $user_db, $pass_db, $db_name);
		$sql= "SELECT * FROM `usuarios` WHERE `id_usuario`=$id";
		$result = $conexion->query($sql);
		$row = $result->fetch_array(MYSQLI_ASSOC);
	}
	if ($result->num_rows > 0) 
	{  	 
?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>TFSolicitudes | Nuevo Usuario</title>
	<link rel='icon' href='img/fav.ico' type='image/x-icon'>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="css/plugins/steps/jquery.steps.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

</head>
	<div id="wrapper">
    	<?php
	 		menu_lateral($row['id_usuario']);
	 	?>
        <div id="page-wrapper" class="gray-bg">
        	<?php
					barra_superior($row['id_usuario'],$pagina);
				?>
        	<div class="row border-bottom">
        		
        	</div>
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>Añadir Nuevo Usuario</h2>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="home.php">Inicio</a>
                        </li>
                        <li  class="breadcrumb-item active">
                            <strong>Añadir Nuevo Usuario</strong>
                        </li>
                    </ol>
                </div>
            </div>
        	<div class="wrapper wrapper-content  animated fadeInRight">
                <div class="row">
                	<div class="col-lg-12">
                    	<div class="ibox">
                        	<div class="ibox-content">
								<h2>
									Formulario Nuevo Usuario
								</h2>
								<p>
									Por favor llene todos los campos del formulario, el mismo consta de 3 partes, todas necesarias para la correcta creacion del usuario.
								</p>
                            	<form enctype="multipart/form-data" method="get" id="form" action="procesar_nuevo_usuario.php" class="wizard-big">
                                	<h1>Cuenta</h1>
                                	<fieldset>
                                    	<h2>Informacion de la cuenta</h2>
										<div class="row">
											<div class="col-lg-8">
												<div class="form-group">
													<label>Email *</label>
													<input id="email" name="email" type="email" onblur="ver();" class="form-control required">
												</div>
												<div class="form-group">
													<label>Contraseña *</label>
													<input id="password" name="password" type="password" class="form-control required">
												</div>
												<div class="form-group">
													<label>Confirme contraseña *</label>
													<input id="confirm" name="confirm" type="password" class="form-control required">
												</div>
											</div>
											<div class="col-lg-4">
												<div class="text-center">
													<div style="margin-top: 20px">
														<i class="fa fa-sign-in" style="font-size: 180px;color: #e5e5e5 "></i>
													</div>
												</div>
											</div>
										</div>
                                	</fieldset>
                                	<h1>Perfil</h1>
                                	<fieldset>
                                    	<h2>Informacion para el perfil</h2>
										<div class="row">
											<div class="col-lg-6">
												<div class="form-group">
													<label>Nombre *</label>
													<input id="nombre" name="nombre" type="text" class="form-control required">
												</div>
												<div class="form-group">
													<label>Apellido *</label>
													<input id="apellido" name="apellido" type="text" class="form-control required">
												</div>
											</div>
											<div class="col-lg-6">
												<div class="form-group">
													<label>Cargo *</label>
													<select name="cargo" class="form-control" required>
														<option value="">-- Seleccionar cargo --</option>
														<option value="Planificacion">Planificacion</option>
														<option value="bodega">Bodega</option>
														<option value="lider">Lider</option>
														<option value="supervisor">Supervisor</option>
														<option value="operador">Operador</option>
														<option value="control de calidad">Control de calidad</option>
														<option value="Despacho">Despacho</option>
														<option value="control de gestion">Control de gestion</option>
													</select>
												</div>
											</div>
										</div>
                                	</fieldset> 
                                	<?php
										
									?>                            	
                                	<h1>Foto</h1>
									<fieldset>
										<div class="col-lg-12">
											<h4><small>Tu imagen temporal...</small></h4>
											<div align="center" class="form-group">
												<img src="img/avatar/default_avatar.jpg" width="200px" height="200px">
											</div>
										</div>
									</fieldset>
                            	</form>	
                        	</div>
                    	</div>
                    </div>
                </div>
        	</div>
			<?php
				footer();
			?>
		</div>
 	</div>
	<?php						   }
		else
		{
			header('Location: index.html');//redirecciona a la pagina del usuario
		}
		scrips();
	?>
<script>
		function ver()
		{
			var email = $("#email").val();
			if(email) {
				$.ajax({
					type: "POST",
					url: "buscar_email.php", // Corregido el nombre del archivo
					data: { email: email },
					dataType: "json",
					beforeSend: function(){
						$("#resultado").html("<p align='center'><img src='ajax-loader.gif' /></p>");
					},
					success: function(response){
						if(response.existe) {
							alert("El correo ya existe en la base de datos");
							$("#email").val('');
							$("#email").focus();
						}
					},
					error: function(jqXHR, textStatus, errorThrown) {
						console.error("Error en la petición AJAX:", textStatus, errorThrown);
						alert("Error al verificar el correo. Por favor intente nuevamente.");
					}
				});
			}         
		}          
	</script>
    
</body>

</html>