<?php
	session_start();
	include("layout.php");
	$pagina="Perfil";
	head($pagina);
	include("conexion.php");
	if (!isset($_SESSION['id_usuario']))
    {
        echo("No existe");
    }
	else
	{
		$id=$_SESSION['id_usuario'];
		$sql= "SELECT * FROM `usuarios` WHERE `id_usuario`=$id";
		mysqli_query($conexion,"SET NAMES 'utf8'");
		$result = $conexion->query($sql);
		$row = $result->fetch_array(MYSQLI_ASSOC);
	}
	if ($result->num_rows > 0) {  
		$nombre_incompleto = explode(' ',trim($row['nombre']));
?>
 <div id="wrapper">
		<?php
			menu_lateral($_SESSION['id_usuario'])
		?>
        <div id="page-wrapper" class="gray-bg">
         	<?php
				barra_superior($_SESSION['id_usuario'],$pagina)
			?>
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>Perfil</h2>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="home.php">Inicio</a>
                        </li>
                        <li  class="breadcrumb-item active">
                            <strong>Perfil</strong>
                        </li>
                    </ol>
                </div>
            </div>
			<div class="wrapper wrapper-content animated fadeInRight ecommerce">
				<div class="row">
					<div class="col-lg-12">
						<div class="tabs-container">
								<ul class="nav nav-tabs">
									<li><a class="nav-link active" data-toggle="tab" href="#tab-1"> Informacion de cuenta</a></li>
									<li><a class="nav-link" data-toggle="tab" href="#tab-2"> Datos Personales</a></li>
									<li><a class="nav-link" data-toggle="tab" href="#tab-3"> Foto</a></li>
								</ul>
								<div class="tab-content">
									<div id="tab-1" class="tab-pane active">
										<div class="panel-body">
											<fieldset>
											
												<div class="form-group row">
													<label class="col-sm-2 col-form-label">Correo:</label>
													<div class="col-sm-10">
														<input id="correo" name="correo" type="text" class="form-control" value="<?php echo($row['email']);?>" readonly>
													</div>
												</div>
												<div class="form-group row">
													<label class="col-sm-2 col-form-label">Contaseña:</label>
													<div class="col-sm-10">
														<input id="pass" name="pass" type="password" class="form-control" value="<?php echo($row['pass']);?>" required>
													</div>
												</div>
												<div class="form-group row">
													<label class="col-sm-2 col-form-label">Repita contraseña:</label>
													<div class="col-sm-10">
														<input id="rpass" name="rpass" type="password" class="form-control" value="<?php echo($row['pass']);?>" required>
													</div>
												</div>
												<div align="center">
													<button onClick="javaScript:icuenta()" class="btn btn-primary">Guardar</button>
												</div>
												
											</fieldset>
										</div>
									</div>
									<div id="tab-2" class="tab-pane">
										<div class="panel-body">
											<fieldset>
												<div class="form-group row">
													<label class="col-sm-2 col-form-label">ID:</label>
													<div class="col-sm-10">
														<input type="text" id="id" name="id" class="form-control" value="<?php echo($row['id_usuario']);?>" readonly>
													</div>
												</div>
												<div class="form-group row">
													<label class="col-sm-2 col-form-label">Nombre:</label>
													<div class="col-sm-10">
														<input type="text" id="nombre" name="nombre" class="form-control" value="<?php echo($nombre_incompleto[0]);?>">
													</div>
												</div>
												<div class="form-group row">
													<label class="col-sm-2 col-form-label">Apellido:</label>
													<div class="col-sm-10">
														<input type="text" id="apellido" name="apellido" class="form-control" value="<?php echo($nombre_incompleto[1]);?>">
													</div>
												</div>
												<div class="form-group row">
													<label class="col-sm-2 col-form-label">Cargo:</label>
													<div class="col-sm-10">
														<input type="text" id="cargo" name="cargo" class="form-control" value="<?php echo($row['cargo']);?>">
													</div>
												</div>
												<div align="center">
													<button onClick="javaScript:dpersonal()" class="btn btn-primary">Guardar</button>
												</div>
											</fieldset>
										</div>
									</div>
									<div id="tab-3" class="tab-pane">
										<div class="panel-body">
											<fieldset>
											<form id="imagen" action="editar_usuario3.php" method="post" enctype="multipart/form-data">
											<div class="table-responsive">
												<table class="table table-bordered table-stripped">
													<thead>
													<tr>
														<th>
															Imagen
														</th>
														<th>
															Ruta
														</th>
														<th>
															Id Usuario
														</th>
													</tr>
													</thead>
													<tbody>
													<tr>
														<td align="center">
															<?php
																if ($row['foto']=='')
																{
																	$imagen="img/avatar/default_avatar.jpg";
																}
																else
																{
																	
																	$imagen=$row['foto'];
																}
															?>
															<img src="<?php echo($imagen); ?>" width="150px" height="150px">
														</td>
														<td>
															<input type="file" class="form-control" id="image" name="image" multiple>
														</td>
														<td>
															<input type="text" id="id_usuario" name="id_usuario" class="form-control" value="<?php echo($id); ?>" readonly>
														</td>
													</tr>
													</tbody>
												</table>
											</div>
											<div align="center">
													<button name="submit" class="btn btn-primary">Guardar</button>
												</div>
												</form>
											</fieldset>
										</div>
									</div>
								</div>
						</div>
					</div>
				</div>
			</div>
			<?php
				footer();
			?>
	 </div>
	
	<?php						   
		}
		else
		{
			header('Location: index.html');//redirecciona a la pagina del usuario
		}
	    //scrips();
	?>
	<!-- Mainly scripts -->
	<script src="js/jquery-3.1.1.min.js"></script>
	<script src="js/popper.min.js"></script>
    <script src="js/bootstrap.js"></script>
	<script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
	<script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

	<!-- Custom and plugin javascript -->
	<script src="js/inspinia.js"></script>
	<script src="js/plugins/pace/pace.min.js"></script>

	<!-- SUMMERNOTE -->
	<script src="js/plugins/summernote/summernote-bs4.js"></script>

	<!-- Data picker -->
	<script src="js/plugins/datapicker/bootstrap-datepicker.js"></script>

	<script>
		$(document).ready(function(){

			$('.summernote').summernote();

			$('.input-group.date').datepicker({
				todayBtn: "linked",
				keyboardNavigation: false,
				forceParse: false,
				calendarWeeks: true,
				autoclose: true
			});

		});
	</script>
	<script>
		function icuenta()
		{
			var id_user = '<?php echo($id); ?>';
			var p1 = document.getElementById("pass").value;
			var p2 = document.getElementById("rpass").value;
			var correo= document.getElementById("correo").value
			if (p1 != p2) 
			{
				alert("Las passwords deben de coincidir");	
			} 
			else 
			{
				$.post("editar_usuario1.php", { id: id_user,correo: correo, pass: p1,} );
				location.reload();
				alert("Los datos fueron actualizados");
			}
		}
	</script>
	<script>
		function dpersonal()
		{
			var id_user = '<?php echo($id); ?>';
			var nombre = document.getElementById("nombre").value;
			var apellido = document.getElementById("apellido").value;
			var cargo= document.getElementById("cargo").value
			$.post("editar_usuario2.php", { id: id_user, nombre: nombre, apellido: apellido, cargo: cargo,} );
			location.reload();
			alert("Los datos fueron actualizados");
		}
	</script>
</body>
</html>