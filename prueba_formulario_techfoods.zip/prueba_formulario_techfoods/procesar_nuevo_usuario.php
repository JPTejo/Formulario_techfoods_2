<?php
 	$email=$_REQUEST['email'];
 	$pass=$_REQUEST['password'];
 	$nombre=$_REQUEST['nombre'];
 	$apellido=$_REQUEST['apellido'];
 	$cargo=$_REQUEST['cargo'];
	include("conexion.php");
    $nombrecompleto=$nombre." ".$apellido;
 	//echo($email." ".$pass." ".$nombre." ".$apellido." ".$cargo);
	  // Insertamos en la base de datos.
	  $sql_bus_max_id_usuario=mysqli_query($conexion,"SELECT MAX(`id_usuario`) FROM `usuarios`");
	  while ($row_max_id_usuario=mysqli_fetch_array($sql_bus_max_id_usuario))
	  {
		  $max_id=$row_max_id_usuario[0];
		  if ($max_id=='' or $max_id==0)
		  {
			  $max_id=1;
		  }
		  else
		  {
			  $max_id=$max_id+1;
		  }
	  }
    $resultado = mysqli_query($conexion,"INSERT INTO `usuarios`(`id_usuario`, `nombre`, `email`, `cargo`,`pass`) VALUES ('$max_id','$nombrecompleto','$email','$cargo','$pass')");
    if ($resultado)
    {
		//echo "Ok, Guardado";
    	$guardo='si';
		//header('Location: verificacion.php?guardo=si');//redirecciona a la pagina del usuario
    }
   	else
   	{
		//echo "Ocurrió algun error al copiar el archivo.";
    	$guardo='no';
		//header('Location: verificacion.php?guardo=no');//redirecciona a la pagina del usuario
 	}
?>
   <script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
<!DOCTYPE html>
<html>

<head>
	<meta http-equiv="Content-type" content="text/html"; charset="utf-8" />
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
   <script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
<?php
		if(isset($guardo))
		{
			$resultado=$guardo;
			if($resultado=='si')
			{
				?>
					<script>
      					$(document).ready(function()
					  	{
							$("#mostrarmodal").modal("show");
					  	});
					</script>
				<?php
			}
			if($resultado=='no')
			{
				?>
					<script>
      					$(document).ready(function()
					  	{
							$("#mostrarmoda2").modal("show");
					  	});
					</script>
				<?php
			}
		}
		else
		{
			?>
				<script>
      					$(document).ready(function()
					  	{
							$("#mostrarmoda3").modal("show");
					  	});
				</script>
			<?php
		}
	?>
   	<div class="modal fade" id="mostrarmodal" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
    	<div class="modal-dialog">
        	<div class="modal-content">
           		<div class="modal-header">
              		<h3>Resultado Del Ingreso</h3>
           		</div>
           		<div class="modal-body">
              		<h4>Exitoso!</h4>
              		Los datos del nuevo usuario se ingresaron correctamente a la base de datos.
       			</div>
           		<div class="modal-footer">
          			<a href="nuevo_usuario.php" onclick="location.href='nuevo_usuario.php'" data-dismiss="modal"  class="btn btn-success">Cerrar</a>
           		</div>
      		</div>
   		</div>
	</div>
	<div class="modal fade" id="mostrarmoda2" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
    	<div class="modal-dialog">
        	<div class="modal-content">
           		<div class="modal-header">
              		<h3>Resultado Del Ingreso</h3>
           		</div>
           		<div class="modal-body">
              		<h4>Fallo!</h4>
              		Los datos del nuevo usuario no fueron ingresaron a la base de datos.
       			</div>
           		<div class="modal-footer">
          			<a href="nuevo_usuario.php" onclick="location.href='nuevo_usuario.php'" data-dismiss="modal" class="btn btn-success">Cerrar</a>
           		</div>
      		</div>
   		</div>
	</div>
	<div class="modal fade" id="mostrarmoda3" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
    	<div class="modal-dialog">
        	<div class="modal-content">
           		<div class="modal-header">
              		<h3>No Existen Datos Para Almacenar</h3>
           		</div>
           		<div class="modal-body">
              		<h4>Fallo!</h4>
              		No se detectaron datos en el envio, intentelo de nuevo, si sucede nuevamente por favor cunsulte el problema al administrador del sistema .
       			</div>
           		<div class="modal-footer">
          			<a href="nuevo_usuario.php" onclick="location.href='nuevo_usuario.php'" data-dismiss="modal" class="btn btn-success">Cerrar</a>
           		</div>
      		</div>
   		</div>
	</div>
</body>
</html>
