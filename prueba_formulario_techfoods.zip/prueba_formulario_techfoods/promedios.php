<?php
session_start();
include("layout.php");
$pagina = "Promedios";
head($pagina);
include("conexion.php");

if (!isset($_SESSION['id_usuario'])) {
    header('Location: index.html');
    exit;
}

$id = $_SESSION['id_usuario'];
$conexion = new mysqli($host_db, $user_db, $pass_db, $db_name);
if ($conexion->connect_error) {
    die("Error en conexión: " . $conexion->connect_error);
}

// Obtener info usuario y rol
$sql = "SELECT * FROM usuarios WHERE id_usuario = $id";
$result = $conexion->query($sql);
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $nombre_usuario = $row['nombre'];
    if ($row['is_admin']) {
        $rol = 'Administrador';
    } elseif ($row['is_solicitador']) {
        $rol = 'Solicitador';
    } elseif ($row['is_entregador']) {
        $rol = 'Entregador';
    } else {
        $rol = 'Usuario';
    }
} else {
    header('Location: index.html');
    exit;
}

// Query para salidas basado en solicitudes con status 'completo'
$sql_salidas = "
    SELECT 
        i.nombre AS insumo,
        SUM(es.cantidad) AS total_salida,
        COUNT(DISTINCT DATE(e.at_time)) AS dias_activos,
        ROUND(SUM(es.cantidad) / COUNT(DISTINCT DATE(e.at_time)), 2) AS promedio_diario_salida
    FROM entregas_solicitud es
    INNER JOIN entregas e ON es.id_entrega = e.id_entrega
    INNER JOIN insumos i ON es.id_insumo = i.id_insumo
    INNER JOIN status s ON e.id_status = s.id_status
    WHERE s.nombre = 'completo'
    GROUP BY es.id_insumo
    ORDER BY promedio_diario_salida DESC
    LIMIT 10
";

// Query para entradas (dejamos igual, basado en mov_inventario tipo 'E')
$sql_entradas = "
    SELECT 
        i.nombre AS insumo,
        SUM(mid.cantidad) AS total_entrada,
        COUNT(DISTINCT DATE(mi.fecha)) AS dias_activos,
        ROUND(SUM(mid.cantidad) / COUNT(DISTINCT DATE(mi.fecha)), 2) AS promedio_diario_entrada
    FROM mov_inventario mi
    INNER JOIN mov_inventario_detalles mid ON mi.id_mov_inventario = mid.id_mov_inventario
    INNER JOIN insumos i ON mid.id_insumo = i.id_insumo
    WHERE mi.tipo = 'E' 
    GROUP BY mid.id_insumo
    ORDER BY promedio_diario_entrada DESC
    LIMIT 10
";

$res_salidas = $conexion->query($sql_salidas);
$res_entradas = $conexion->query($sql_entradas);

$salidas_nombres = [];
$salidas_promedios = [];
if ($res_salidas) {
    while ($row = $res_salidas->fetch_assoc()) {
        $salidas_nombres[] = $row['insumo'];
        $salidas_promedios[] = (float)$row['promedio_diario_salida'];
    }
}

$entradas_nombres = [];
$entradas_promedios = [];
if ($res_entradas) {
    while ($row = $res_entradas->fetch_assoc()) {
        $entradas_nombres[] = $row['insumo'];
        $entradas_promedios[] = (float)$row['promedio_diario_entrada'];
    }
}

?>

<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<style>
    table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 2rem;
    }
    th, td {
        padding: 8px 12px;
        border: 1px solid #ccc;
        text-align: left;
    }
    th {
        background: #f5f5f5;
    }
    .chart-container {
        width: 100%;
        max-width: 900px;
        margin-bottom: 3rem;
    }
</style>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<div id="wrapper">
    <?php menu_lateral($id); ?>
    <div id="page-wrapper" class="gray-bg">
        <?php barra_superior($id, $pagina); ?>

        <div class="row wrapper border-bottom white-bg page-heading">
            <div class="col-lg-10 col-md-12">
                <h2>Consumos Promedios</h2>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="home.php">Inicio</a></li>
                    <li class="breadcrumb-item active"><strong>Promedios</strong></li>
                </ol>
            </div>
        </div>

        <div class="wrapper wrapper-content animated fadeInRight">
            <div class="alert alert-info">
                <i class="fa fa-info-circle"></i>
                Usuario: <strong><?php echo htmlspecialchars($nombre_usuario); ?></strong> | 
                Rol: <strong><?php echo htmlspecialchars($rol); ?></strong>
            </div>

            <!-- Gráfico de salidas -->
            <div class="chart-container">
                <h3>Promedio Diario de Salidas (Top 10 Insumos)</h3>
                <canvas id="graficoSalidas"></canvas>
            </div>

            <!-- Tabla resumida de salidas -->
            <table>
                <thead>
                    <tr>
                        <th>Insumo</th>
                        <th>Promedio Diario Salida</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($salidas_nombres) {
                        foreach ($salidas_nombres as $i => $nombre) {
                            echo "<tr><td>".htmlspecialchars($nombre)."</td><td>".$salidas_promedios[$i]."</td></tr>";
                        }
                    } else {
                        echo "<tr><td colspan='2' style='text-align:center;'>No hay datos de salidas disponibles</td></tr>";
                    }
                    ?>
                </tbody>
            </table>

            <!-- Gráfico de entradas -->
            <div class="chart-container">
                <h3>Promedio Diario de Entradas (Top 10 Insumos)</h3>
                <canvas id="graficoEntradas"></canvas>
            </div>

            <!-- Tabla resumida de entradas -->
            <table>
                <thead>
                    <tr>
                        <th>Insumo</th>
                        <th>Promedio Diario Entrada</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($entradas_nombres) {
                        foreach ($entradas_nombres as $i => $nombre) {
                            echo "<tr><td>".htmlspecialchars($nombre)."</td><td>".$entradas_promedios[$i]."</td></tr>";
                        }
                    } else {
                        echo "<tr><td colspan='2' style='text-align:center;'>No hay datos de entradas disponibles</td></tr>";
                    }
                    ?>
                </tbody>
            </table>

        </div>

        <?php footer(); ?>
    </div>
</div>

<script>
const ctxSalidas = document.getElementById('graficoSalidas').getContext('2d');
const graficoSalidas = new Chart(ctxSalidas, {
    type: 'bar',
    data: {
        labels: <?php echo json_encode($salidas_nombres); ?>,
        datasets: [{
            label: 'Promedio Diario de Salidas',
            data: <?php echo json_encode($salidas_promedios); ?>,
            backgroundColor: 'rgba(217, 83, 79, 0.7)', // rojo
            borderColor: 'rgba(217, 83, 79, 1)',
            borderWidth: 1
        }]
    },
    options: {
        responsive:true,
        scales: {
            y: { beginAtZero: true }
        }
    }
});

const ctxEntradas = document.getElementById('graficoEntradas').getContext('2d');
const graficoEntradas = new Chart(ctxEntradas, {
    type: 'bar',
    data: {
        labels: <?php echo json_encode($entradas_nombres); ?>,
        datasets: [{
            label: 'Promedio Diario de Entradas',
            data: <?php echo json_encode($entradas_promedios); ?>,
            backgroundColor: 'rgba(92, 184, 92, 0.7)', // verde
            borderColor: 'rgba(92, 184, 92, 1)',
            borderWidth: 1
        }]
    },
    options: {
        responsive:true,
        scales: {
            y: { beginAtZero: true }
        }
    }
});
</script>

<?php
scrips();
?>
</body>
</html>
