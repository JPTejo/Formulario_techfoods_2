<?php
session_start();
include("layout.php");
$pagina = "Stock Actual";
head($pagina);
include("conexion.php");

if (!isset($_SESSION['id_usuario'])) {
    header('Location: index.html');
    exit;
}

$id = $_SESSION['id_usuario'];
$conexion = new mysqli($host_db, $user_db, $pass_db, $db_name);

// Obtener información del usuario
$sql = "SELECT * FROM usuarios WHERE id_usuario = $id";
$result = $conexion->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_array(MYSQLI_ASSOC);
    $cargo = $row['cargo'];
    $nombre_usuario = $row['nombre'];

    // Rol
    if ($row['is_admin']) {
        $rol = 'Administrador';
    } elseif ($row['is_solicitador']) {
        $rol = 'Solicitador';
    } elseif ($row['is_entregador']) {
        $rol = 'Entregador';
    } else {
        $rol = 'Usuario';
    }

    // Filtros de búsqueda
    $busqueda = isset($_GET['buscar']) ? $conexion->real_escape_string($_GET['buscar']) : '';
    $estado_stock = $_GET['estado'] ?? '';

    $filtros = "WHERE i.status = 1";

    if ($busqueda !== '') {
        $filtros .= " AND (i.nombre LIKE '%$busqueda%' OR i.codigo LIKE '%$busqueda%')";
    }

    // Aplicar filtros por estado
    if ($estado_stock == 'sin') {
        $filtros .= " AND i.stock = 0";
    } elseif ($estado_stock == 'bajo') {
        $filtros .= " AND i.stock > 0 AND i.stock < i.stock_minimo";
    } elseif ($estado_stock == 'ok') {
        $filtros .= " AND i.stock >= i.stock_minimo";
    }

    // Consulta principal
    $consulta = "SELECT i.id_insumo, i.nombre, i.codigo, i.stock, i.stock_minimo, u.abreviatura 
                 FROM insumos i 
                 LEFT JOIN unidades u ON i.id_unidad = u.id_unidad 
                 $filtros
                 ORDER BY i.nombre ASC";

    $insumos = $conexion->query($consulta);
?>

<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<style>
    .etiqueta {
        padding: 5px 10px;
        border-radius: 4px;
        font-size: 12px;
        color: #fff;
        font-weight: bold;
    }
    .sin-stock {
        background-color: #d9534f;
    }
    .bajo-stock {
        background-color: #f0ad4e;
        color: #fff;
    }
    .stock-ok {
        background-color: #5cb85c;
    }
    .tabla-stock th, .tabla-stock td {
        vertical-align: middle !important;
    }
</style>

<div id="wrapper">
    <?php menu_lateral($id); ?>
    <div id="page-wrapper" class="gray-bg">
        <?php barra_superior($id, $pagina); ?>

        <div class="row wrapper border-bottom white-bg page-heading">
            <div class="col-lg-10 col-md-12">
                <h2>Stock de Insumos</h2>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="home.php">Inicio</a></li>
                    <li class="breadcrumb-item active"><strong>Stock</strong></li>
                </ol>
            </div>
        </div>

        <div class="wrapper wrapper-content animated fadeInRight">
            <div class="alert alert-info">
                <i class="fa fa-info-circle"></i>
                Usuario: <strong><?php echo $nombre_usuario; ?></strong> | 
                Cargo: <strong><?php echo $cargo; ?></strong> | 
                Rol: <strong><?php echo $rol; ?></strong>
            </div>

            <!-- Buscador y Filtros -->
            <form method="GET" class="mb-3">
                <div class="row">
                    <div class="col-md-4">
                        <input type="text" name="buscar" class="form-control" placeholder="Buscar por nombre o código..." value="<?php echo htmlspecialchars($busqueda); ?>">
                    </div>
                    <div class="col-md-3">
                        <select name="estado" class="form-control">
                            <option value="">Todos los estados</option>
                            <option value="sin" <?php if ($estado_stock == 'sin') echo 'selected'; ?>>Sin stock</option>
                            <option value="bajo" <?php if ($estado_stock == 'bajo') echo 'selected'; ?>>Bajo stock</option>
                            <option value="ok" <?php if ($estado_stock == 'ok') echo 'selected'; ?>>Stock OK</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary">🔍 Buscar</button>
                    </div>
                </div>
            </form>

            <!-- Tabla de stock -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="ibox">
                        <div class="ibox-title">
                            <h5>Listado de Stock Actual</h5>
                        </div>
                        <div class="ibox-content">
                            <div class="table-responsive">
                                <table class="table table-striped tabla-stock">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Código</th>
                                            <th>Insumo</th>
                                            <th>Stock</th>
                                            <th>Unidad</th>
                                            <th>Estado</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if ($insumos->num_rows > 0): ?>
                                            <?php while ($insumo = $insumos->fetch_assoc()): ?>
                                                <?php
                                                    $etiqueta = '';
                                                    $clase = '';
                                                    if ($insumo['stock'] == 0) {
                                                        $etiqueta = 'SIN STOCK';
                                                        $clase = 'sin-stock';
                                                    } elseif ($insumo['stock'] < $insumo['stock_minimo']) {
                                                        $etiqueta = 'BAJO STOCK';
                                                        $clase = 'bajo-stock';
                                                    } else {
                                                        $etiqueta = 'Stock OK';
                                                        $clase = 'stock-ok';
                                                    }
                                                ?>
                                                <tr>
                                                    <td><?php echo $insumo['id_insumo']; ?></td>
                                                    <td><?php echo $insumo['codigo']; ?></td>
                                                    <td><?php echo $insumo['nombre']; ?></td>
                                                    <td><?php echo $insumo['stock']; ?></td>
                                                    <td><?php echo $insumo['abreviatura'] ?? '-'; ?></td>
                                                    <td><span class="etiqueta <?php echo $clase; ?>"><?php echo $etiqueta; ?></span></td>
                                                </tr>
                                            <?php endwhile; ?>
                                        <?php else: ?>
                                            <tr><td colspan="6" class="text-center">No se encontraron resultados.</td></tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php footer(); ?>
    </div>
</div>

<?php
} else {
    header('Location: index.html');
    exit;
}

scrips();
?>
</body>
</html>
