<?php
session_start();
include("conexion.php");
include("layout.php");

// Verificar autenticación
if (!isset($_SESSION['id_usuario'])) {
    header('Location: index.html');
    exit;
}

$pagina = "Seguimiento de Órdenes de Producción";
head($pagina);

// Filtros
$filtro_estado = isset($_GET['estado']) ? intval($_GET['estado']) : '';
$filtro_busqueda = isset($_GET['busqueda']) ? $_GET['busqueda'] : '';

// Configuración de paginación
$por_pagina = isset($_GET['por_pagina']) ? intval($_GET['por_pagina']) : 25;
$pagina_actual = isset($_GET['pagina']) ? max(1, intval($_GET['pagina'])) : 1;
$offset = ($pagina_actual - 1) * $por_pagina;

// Consulta para obtener los registros con filtros
$sql = "SELECT s.id_solicitud, s.nro_op, s.at_time, s.fecha_prevista, 
               st.nombre as estado, st.id_status,
               u.nombre as solicitante, p.nombre as prioridad
        FROM solicitud s
        JOIN usuarios u ON s.id_usuario = u.id_usuario
        JOIN status st ON s.id_status = st.id_status
        LEFT JOIN prioridad p ON s.id_prioridad = p.id_prioridad
        WHERE 1=1"; // CLAVE: Añadir esta condición base

// Aplicar filtros
$conditions = [];
$params = [];

if(!empty($filtro_estado)) {
    $conditions[] = "s.id_status = ?";
    $params[] = $filtro_estado;
}

if(!empty($filtro_busqueda)) {
    $conditions[] = "(s.nro_op LIKE ? OR u.nombre LIKE ?)";
    $params[] = "%$filtro_busqueda%";
    $params[] = "%$filtro_busqueda%";
}

// Combinar condiciones
if (!empty($conditions)) {
    $sql .= " AND " . implode(" AND ", $conditions);
}

$sql .= " ORDER BY s.fecha_prevista DESC LIMIT $offset, $por_pagina";

// Preparar consulta segura
$stmt = $conexion->prepare($sql);
if ($stmt) {
    if (!empty($params)) {
        $types = str_repeat('s', count($params));
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    die("Error en la consulta: " . $conexion->error);
}

// Consulta para el total de registros
$total_sql = "SELECT COUNT(*) as total FROM solicitud s
              JOIN usuarios u ON s.id_usuario = u.id_usuario
              JOIN status st ON s.id_status = st.id_status
              JOIN prioridad p ON s.id_prioridad = p.id_prioridad
              WHERE 1=1";

if(!empty($filtro_estado)) {
    $total_sql .= " AND s.id_status = $filtro_estado";
}

if(!empty($filtro_busqueda)) {
    $total_sql .= " AND (s.nro_op LIKE '%$filtro_busqueda%' OR u.nombre LIKE '%$filtro_busqueda%')";
}

$total_result = $conexion->query($total_sql);
$total_registros = $total_result->fetch_assoc()['total'];
$total_paginas = ceil($total_registros / $por_pagina);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pagina; ?></title>
    <style>
        /* Estilo tipo Excel */
        .excel-table {
            border-collapse: collapse;
            width: 100%;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-size: 14px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        
        .excel-table th {
            background-color: #f2f2f2;
            border: 1px solid #ddd;
            padding: 8px 12px;
            text-align: left;
            font-weight: 600;
            position: sticky;
            top: 0;
            z-index: 10;
        }
        
        .excel-table td {
            border: 1px solid #ddd;
            padding: 8px 12px;
            background-color: white;
        }
        
        .excel-table tr:nth-child(even) td {
            background-color: #f9f9f9;
        }
        
        .excel-table tr:hover td {
            background-color: #f1f7ff;
        }
        
        .excel-header {
            background-color: #2c3e50;
            color: white;
            padding: 8px 15px;
            font-weight: bold;
        }
        
        .frozen-column {
            position: sticky;
            left: 0;
            z-index: 5;
            background-color: white;
            box-shadow: 2px 0 3px rgba(0,0,0,0.1);
        }
        
        .frozen-header {
            z-index: 15 !important;
            background-color: #f2f2f2;
        }
        
        .table-container {
            overflow: auto;
            max-height: 70vh;
            border: 1px solid #ddd;
            background-color: white;
        }
        
        .filter-container {
            background-color: #f8f9fa;
            padding: 15px;
            border: 1px solid #ddd;
            border-bottom: none;
            margin-bottom: 0;
        }
        
        .status-badge {
            padding: 4px 8px;
            border-radius: 3px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .badge-pendiente { background-color: #ffc107; color: #212529; }
        .badge-aprobado { background-color: #28a745; color: white; }
        .badge-rechazado { background-color: #dc3545; color: white; }
        .badge-proceso { background-color: #007bff; color: white; }
        .badge-completado { background-color: #6c757d; color: white; }
        
        /* Paginación */
        .pagination {
            margin: 0;
        }
        
        .page-item.active .page-link {
            background-color: #2c3e50;
            border-color: #2c3e50;
        }
        
        .page-link {
            color: #2c3e50;
            min-width: 36px;
            text-align: center;
        }
        
        .page-item.disabled .page-link {
            color: #6c757d;
        }
        
        .page-link:hover {
            color: #1a252f;
            background-color: #e9ecef;
        }
        
        @media (max-width: 768px) {
            .table-container {
                max-height: 60vh;
            }
            
            .excel-table th, 
            .excel-table td {
                padding: 6px 8px;
                font-size: 13px;
            }
        }
    </style>
</head>
<body>
    <div id="wrapper">
        <?php menu_lateral($_SESSION['id_usuario']); ?>
        
        <div id="page-wrapper" class="gray-bg">
            <?php barra_superior($_SESSION['id_usuario'], $pagina); ?>
            
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>Seguimiento de Órdenes de Producción</h2>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="home.php">Inicio</a>
                        </li>
                        <li class="breadcrumb-item active">
                            <strong>Órdenes de Producción</strong>
                        </li>
                    </ol>
                </div>
            </div>

            <div class="wrapper wrapper-content animated fadeInRight">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="ibox">
                            <div class="ibox-title">
                                <h5>Listado de Órdenes de Producción (OPs)</h5>
                                <div class="ibox-tools">
                                    <a href="planificacion.php" class="btn btn-primary btn-xs">
                                        <i class="fa fa-plus"></i> Nueva OP
                                    </a>
                                </div>
                            </div>
                            
                            <div class="ibox-content">
                                <div class="filter-container">
                                    <form method="get" class="form-inline">
                                        <div class="form-group mr-3 mb-2">
                                            <label class="mr-2">Estado:</label>
                                            <select name="estado" class="form-control form-control-sm">
                                                <option value="">Todos los estados</option>
                                                <?php
                                                $estados = $conexion->query("SELECT * FROM status");
                                                while($estado = $estados->fetch_assoc()):
                                                    $selected = ($filtro_estado == $estado['id_status']) ? 'selected' : '';
                                                ?>
                                                    <option value="<?= $estado['id_status'] ?>" <?= $selected ?>>
                                                        <?= htmlspecialchars($estado['nombre']) ?>
                                                    </option>
                                                <?php endwhile; ?>
                                            </select>
                                        </div>
                                        
                                        <div class="form-group mr-3 mb-2">
                                            <label class="mr-2">Buscar:</label>
                                            <input type="text" name="busqueda" class="form-control form-control-sm" 
                                                   placeholder="OP o solicitante" value="<?= htmlspecialchars($filtro_busqueda) ?>">
                                        </div>
                                        
                                        <div class="form-group mr-3 mb-2">
                                            <label class="mr-2">Registros por página:</label>
                                            <select name="por_pagina" class="form-control form-control-sm">
                                                <option value="25" <?= $por_pagina == 25 ? 'selected' : '' ?>>25</option>
                                                <option value="50" <?= $por_pagina == 50 ? 'selected' : '' ?>>50</option>
                                                <option value="100" <?= $por_pagina == 100 ? 'selected' : '' ?>>100</option>
                                                <option value="200" <?= $por_pagina == 200 ? 'selected' : '' ?>>200</option>
                                            </select>
                                        </div>
                                        
                                        <button type="submit" class="btn btn-sm btn-primary mb-2">
                                            <i class="fa fa-filter"></i> Aplicar filtro
                                        </button>
                                    </form>
                                </div>
                                
                                <div class="table-container">
                                    <table class="excel-table">
                                        <thead>
                                            <tr>
                                                <th class="frozen-column frozen-header">OP</th>
                                                <th>Solicitante</th>
                                                <th>Fecha Creación</th>
                                                <th>Fecha Prevista</th>
                                                <th>Prioridad</th>
                                                <th>Estado</th>
                                                <th>Acciones</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if ($result->num_rows > 0): ?>
                                                <?php while($op = $result->fetch_assoc()):
                                                    $estado_class = str_replace(' ', '-', strtolower($op['estado']));
                                                ?>
                                                <tr>
                                                    <td class="frozen-column">
                                                        <strong>OP-<?= htmlspecialchars($op['nro_op']) ?></strong>
                                                    </td>
                                                    <td><?= htmlspecialchars($op['solicitante']) ?></td>
                                                    <td><?= date('d/m/Y', strtotime($op['at_time'])) ?></td>
                                                    <td><?= date('d/m/Y', strtotime($op['fecha_prevista'])) ?></td>
                                                    <td><?= htmlspecialchars($op['prioridad']) ?></td>
                                                    <td>
                                                        <span class="status-badge badge-<?= $estado_class ?>">
                                                            <?= htmlspecialchars($op['estado']) ?>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <a href="detalle_op.php?id=<?= $op['id_solicitud'] ?>" 
                                                           class="btn btn-xs btn-info" 
                                                           title="Ver detalles">
                                                            <i class="fa fa-eye"></i>
                                                        </a>
                                                        
                                                        <?php if ($op['id_status'] != 5): // Si no está finalizada ?>
                                                        <a href="editar_op.php?id=<?= $op['id_solicitud'] ?>" 
                                                           class="btn btn-xs btn-warning" 
                                                           title="Editar">
                                                            <i class="fa fa-edit"></i>
                                                        </a>
                                                        <?php endif; ?>
                                                        
                                                        <a href="reporte_op.php?id=<?= $op['id_solicitud'] ?>" 
                                                           class="btn btn-xs btn-secondary" 
                                                           title="Descargar reporte">
                                                            <i class="fa fa-download"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                                <?php endwhile; ?>
                                            <?php else: ?>
                                                <tr>
                                                    <td colspan="7" class="text-center py-4">
                                                        <i class="fa fa-inbox fa-2x text-muted mb-2"></i>
                                                        <h5>No se encontraron órdenes de producción</h5>
                                                        <p class="text-muted">Intenta cambiar los filtros o crear una nueva OP</p>
                                                    </td>
                                                </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                                
                                <div class="mt-3 d-flex justify-content-between align-items-center">
                                    <div>
                                        <span class="text-muted">
                                            Mostrando <?= min($offset + 1, $total_registros) ?> a <?= min($offset + $por_pagina, $total_registros) ?> de <?= $total_registros ?> registros
                                        </span>
                                    </div>
                                    <div>
                                        <nav aria-label="Paginación">
                                            <ul class="pagination pagination-sm mb-0">
                                                <!-- Botón Anterior -->
                                                <li class="page-item <?= $pagina_actual <= 1 ? 'disabled' : '' ?>">
                                                    <a class="page-link" 
                                                       href="?<?= http_build_query(array_merge($_GET, ['pagina' => $pagina_actual - 1])) ?>">
                                                        <i class="fa fa-chevron-left"></i>
                                                    </a>
                                                </li>
                                                
                                                <!-- Números de página -->
                                                <?php
                                                $max_paginas_visibles = 5;
                                                $inicio = max(1, $pagina_actual - floor($max_paginas_visibles / 2));
                                                $fin = min($total_paginas, $inicio + $max_paginas_visibles - 1);
                                                
                                                // Ajustar si el rango es menor que el máximo
                                                if ($fin - $inicio < $max_paginas_visibles - 1) {
                                                    $inicio = max(1, $fin - $max_paginas_visibles + 1);
                                                }
                                                
                                                if ($inicio > 1) {
                                                    echo '<li class="page-item"><a class="page-link" href="?' . http_build_query(array_merge($_GET, ['pagina' => 1])) . '">1</a></li>';
                                                    if ($inicio > 2) {
                                                        echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                                                    }
                                                }
                                                
                                                for ($i = $inicio; $i <= $fin; $i++):
                                                ?>
                                                    <li class="page-item <?= $i == $pagina_actual ? 'active' : '' ?>">
                                                        <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['pagina' => $i])) ?>">
                                                            <?= $i ?>
                                                        </a>
                                                    </li>
                                                <?php endfor;
                                                
                                                if ($fin < $total_paginas) {
                                                    if ($fin < $total_paginas - 1) {
                                                        echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                                                    }
                                                    echo '<li class="page-item"><a class="page-link" href="?' . http_build_query(array_merge($_GET, ['pagina' => $total_paginas])) . '">' . $total_paginas . '</a></li>';
                                                }
                                                ?>
                                                
                                                <!-- Botón Siguiente -->
                                                <li class="page-item <?= $pagina_actual >= $total_paginas ? 'disabled' : '' ?>">
                                                    <a class="page-link" 
                                                       href="?<?= http_build_query(array_merge($_GET, ['pagina' => $pagina_actual + 1])) ?>">
                                                        <i class="fa fa-chevron-right"></i>
                                                    </a>
                                                </li>
                                            </ul>
                                        </nav>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <?php footer(); ?>
        </div>
    </div>

    <?php scrips(); ?>
    
    <script>
        $(document).ready(function() {
            // Hacer la tabla más interactiva
            $('.excel-table').on('mouseenter', 'td', function() {
                $(this).parent().addClass('table-active');
            }).on('mouseleave', 'td', function() {
                $(this).parent().removeClass('table-active');
            });
            
            // Tooltips para acciones
            $('[title]').tooltip();
            
            // Botón de exportación a Excel
            $('#export-excel').click(function() {
                alert('La exportación a Excel estará disponible pronto!');
                // Aquí iría el código real para exportar a Excel
            });
        });
    </script>
</body>
</html>