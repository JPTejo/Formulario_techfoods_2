<?php
header('Content-Type: application/json');

include("conexion.php");

// Verificar conexión
if ($conexion->connect_error) {
    die(json_encode(['error' => 'Conexión fallida: ' . $conexion->connect_error]));
}

// Verificar parámetro
if (!isset($_POST['nro_op'])) {
    echo json_encode(['error' => 'No se recibió nro_op']);
    exit;
}

$nro_op = $_POST['nro_op'];

// Consulta SQL modificada para obtener máquina actual
$sql = "SELECT 
            c.id_cliente, 
            c.nombre AS nombre_cliente,
            mov.id_maquina,
            maq.nombre AS nombre_maquina
        FROM solicitud s
        LEFT JOIN productos p ON s.nro_op = p.id_producto
        LEFT JOIN clientes c ON p.id_cliente = c.id_cliente
        LEFT JOIN (
            SELECT mov1.nro_op, mov1.id_maquina
            FROM op_movimientos mov1
            WHERE mov1.accion_realizada = 'entrada_proceso'
            AND NOT EXISTS (
                SELECT 1 
                FROM op_movimientos mov2
                WHERE mov2.nro_op = mov1.nro_op
                AND mov2.id_maquina = mov1.id_maquina
                AND mov2.accion_realizada = 'salida_proceso'
            )
        ) mov ON s.nro_op = mov.nro_op
        LEFT JOIN maquinas maq ON mov.id_maquina = maq.id_maquina
        WHERE s.nro_op = ?";

$stmt = $conexion->prepare($sql);
if (!$stmt) {
    echo json_encode(['error' => 'Error en preparación: ' . $conexion->error]);
    exit;
}

$stmt->bind_param("s", $nro_op);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $response = [
        'existe' => true,
        'id_cliente' => $row['id_cliente'],
        'nombre_cliente' => $row['nombre_cliente'],
        'id_maquina' => $row['id_maquina'],
        'nombre_maquina' => $row['nombre_maquina']
    ];
} else {
    $response = [
        'existe' => false
    ];
}

$stmt->close();
$conexion->close();

echo json_encode($response);
?>